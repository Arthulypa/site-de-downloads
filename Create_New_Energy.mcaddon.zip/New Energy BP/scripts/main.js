import { world, system, ItemStack } from "@minecraft/server";

/**
 * New Energy - Simple RF Energy System
 * Solar Panel → Electrical Pipe / Electrical Connector (wire) → Electrical Crusher / Energiser
 *
 * Solar Panel generates RF during daytime.
 * Electrical Pipe transports energy between machines (connects in all 6 directions).
 * Electrical Connector is a node that can be linked to another connector via Copper Wire,
 *   spawning a wire_entity as a visible cable between the two points.
 * Electrical Crusher consumes RF to crush cobblestone into gravel.
 * Energiser (Basic / Advanced / Reinforced) energises iron/gold/diamond into Overcharged variants.
 */

// ============================================================
// In-memory energy network
// Key: "x,y,z,dimensionId" → { type: string, energy: number }
// ============================================================
const energyNetwork = new Map();

// ============================================================
// Wire connections between Electrical Connectors
// Key: "x,y,z,dimensionId" → Set<"x,y,z,dimensionId">
// Bidirectional: if A→B, then B→A also stored
// ============================================================
const wireConnections = new Map();

// ============================================================
// Pending wire state
// Maps player name → { key, dimId } (first connector waiting for second click)
// ============================================================
const pendingWire = new Map();

// ============================================================
// Connector entity tracking
// Key: "x,y,z,dimensionId" → entity (ne:electrical_connector_entity)
// ============================================================
const connectorEntities = new Map();

// ============================================================
// Wire entity tracking
// Key: "keyA|keyB" (sorted) → entity (ne:wire_entity)
// ============================================================
const wireEntities = new Map();

// ============================================================
// Energiser entity tracking
// Key: "x,y,z,dimensionId" → entity (ne:energiser_entity)
// ============================================================
const energiserEntities = new Map();

// ============================================================
// Crusher entity tracking
// Key: "x,y,z,dimensionId" → entity (ne:electrical_crusher_entity)
// ============================================================
const crusherEntities = new Map();

// ============================================================
// Energiser processing timers
// Key: "x,y,z,dimensionId" → { itemType: string, elapsed: number }
// elapsed counts how many 1-second intervals have passed
// ============================================================
const energiserTimers = new Map();

// ============================================================
// Generator Coil entity tracking
// Key: "x,y,z,dimensionId" → entity (ne:generator_coil_entity)
// ============================================================
const generatorCoilEntities = new Map();

// ============================================================
// Carbon Brushes entity tracking
// Key: "x,y,z,dimensionId" → entity (ne:carbon_brushes_entity)
// ============================================================
const carbonBrushesEntities = new Map();

function getWirePairKey(keyA, keyB) {
    return keyA < keyB ? `${keyA}|${keyB}` : `${keyB}|${keyA}`;
}

// ============================================================
// Persistence — save/load state via Dynamic Properties
// Fixes machines stopping after leaving and re-entering a world
// ============================================================
const PROP_NETWORK     = "ne_energyNetwork";
const PROP_WIRE_CONN   = "ne_wireConnections";
const PROP_WIRE_PAIRS  = "ne_wirePairs";
const PERSIST_DIMS     = ["overworld", "nether", "the_end"];

// CRITICAL: must be true before saveState() is allowed to write,
// otherwise it overwrites good data with an empty network on startup.
let isInitialized = false;

// Save energy network, wire connections and wire entity pair keys to the world
function saveState() {
    if (!isInitialized) return; // never overwrite saved data before we've loaded it
    try {
        const networkArr = [...energyNetwork.entries()].map(([k, v]) => [k, { type: v.type, energy: v.energy }]);
        const networkStr = JSON.stringify(networkArr);
        if (networkStr.length <= 32000) world.setDynamicProperty(PROP_NETWORK, networkStr);
    } catch(e) {}

    try {
        const wConnArr = [...wireConnections.entries()].map(([k, v]) => [k, [...v]]);
        const wConnStr = JSON.stringify(wConnArr);
        if (wConnStr.length <= 32000) world.setDynamicProperty(PROP_WIRE_CONN, wConnStr);
    } catch(e) {}

    try {
        const wirePairsArr = [];
        for (const [pairKey, ent] of wireEntities) {
            try { wirePairsArr.push([pairKey, ent.typeId]); } catch(e) {}
        }
        const wirePairsStr = JSON.stringify(wirePairsArr);
        if (wirePairsStr.length <= 32000) world.setDynamicProperty(PROP_WIRE_PAIRS, wirePairsStr);
    } catch(e) {}
}

// Restore energy network and wire connections from saved Dynamic Properties
function loadState() {
    try {
        const raw = world.getDynamicProperty(PROP_NETWORK);
        if (raw) {
            const arr = JSON.parse(raw);
            for (const [k, v] of arr) {
                if (!energyNetwork.has(k)) energyNetwork.set(k, v);
            }
        }
    } catch(e) {}

    try {
        const raw = world.getDynamicProperty(PROP_WIRE_CONN);
        if (raw) {
            const arr = JSON.parse(raw);
            for (const [k, v] of arr) {
                if (!wireConnections.has(k)) wireConnections.set(k, new Set(v));
            }
        }
    } catch(e) {}
}

// Rescan entities that survived the world reload and re-populate tracking Maps
function rescanEntities() {
    // Load saved wire pairs to re-link wire entities
    let savedWirePairs = [];
    try {
        const raw = world.getDynamicProperty(PROP_WIRE_PAIRS);
        if (raw) savedWirePairs = JSON.parse(raw);
    } catch(e) {}

    for (const dimId of PERSIST_DIMS) {
        let dim;
        try { dim = world.getDimension(dimId); } catch(e) { continue; }

        // Generator Coil
        try {
            for (const ent of dim.getEntities({ type: "ne:generator_coil_entity" })) {
                const key = getKey({ x: Math.floor(ent.location.x), y: Math.floor(ent.location.y), z: Math.floor(ent.location.z) }, dimId);
                if (!generatorCoilEntities.has(key)) generatorCoilEntities.set(key, ent);
            }
        } catch(e) {}

        // Carbon Brushes
        try {
            for (const ent of dim.getEntities({ type: "ne:carbon_brushes_entity" })) {
                const key = getKey({ x: Math.floor(ent.location.x), y: Math.floor(ent.location.y), z: Math.floor(ent.location.z) }, dimId);
                if (!carbonBrushesEntities.has(key)) carbonBrushesEntities.set(key, ent);
            }
        } catch(e) {}

        // Energiser
        try {
            for (const ent of dim.getEntities({ type: "ne:energiser_entity" })) {
                const key = getKey({ x: Math.floor(ent.location.x), y: Math.floor(ent.location.y), z: Math.floor(ent.location.z) }, dimId);
                if (!energiserEntities.has(key)) energiserEntities.set(key, ent);
            }
        } catch(e) {}

        // Electrical Crusher
        try {
            for (const ent of dim.getEntities({ type: "ne:electrical_crusher_entity" })) {
                const key = getKey({ x: Math.floor(ent.location.x), y: Math.floor(ent.location.y), z: Math.floor(ent.location.z) }, dimId);
                if (!crusherEntities.has(key)) crusherEntities.set(key, ent);
            }
        } catch(e) {}

        // Electrical Connector
        try {
            for (const ent of dim.getEntities({ type: "ne:electrical_connector_entity" })) {
                const key = getKey({ x: Math.floor(ent.location.x), y: Math.floor(ent.location.y), z: Math.floor(ent.location.z) }, dimId);
                if (!connectorEntities.has(key)) connectorEntities.set(key, ent);
            }
        } catch(e) {}

        // Wire entities — re-link using saved pair keys
        const wireEntityTypes = Object.values(WIRE_TYPES).map(w => w.entity);
        for (const entityType of wireEntityTypes) {
            try {
                const ents = dim.getEntities({ type: entityType });
                const matchingPairs = savedWirePairs.filter(([, et]) => et === entityType);
                for (let i = 0; i < ents.length && i < matchingPairs.length; i++) {
                    const pairKey = matchingPairs[i][0];
                    if (!wireEntities.has(pairKey)) wireEntities.set(pairKey, ents[i]);
                }
            } catch(e) {}
        }
    }
}

// Run 2 seconds after script initialises (gives the world time to fully load chunks)
// After this runs we set isInitialized=true so saveState() can begin persisting.
system.runTimeout(() => {
    loadState();
    rescanEntities();
    isInitialized = true;
}, 40);

// ============================================================
// Constants
// ============================================================
const TICK_RATE = 20;
const SOLAR_RF_GEN = 10;
const MAX_ENERGY = 100;
const CRUSHER_COST = 5;

// Energiser
const ENERGISER_IDS = ["ne:basic_energiser", "ne:advanced_energiser", "ne:reinforced_energiser"];
const ENERGISER_COST = 3;          // RF consumed per processing second
const ENERGISER_PROCESS_TICKS = {
    "ne:basic_energiser": 7,
    "ne:advanced_energiser": 5,
    "ne:reinforced_energiser": 3
};

// Valid recipes the Energiser can process
const ENERGISER_RECIPES = [
    { inputs: { "minecraft:iron_ingot": 1 }, output: { typeId: "ne:overcharged_iron", count: 1 } },
    { inputs: { "minecraft:gold_ingot": 1 }, output: { typeId: "ne:overcharged_gold", count: 1 } },
    { inputs: { "minecraft:diamond": 1 }, output: { typeId: "ne:overcharged_diamond", count: 1 } },
    { inputs: { "ne:thorium_ingot": 1 }, output: { typeId: "ne:overcharged_thorium", count: 1 } },
    { inputs: { "minecraft:charcoal": 1 }, output: { typeId: "minecraft:coal", count: 1 } },
    { inputs: { "minecraft:cobblestone": 9 }, output: { typeId: "minecraft:tuff", count: 1 } },
    { inputs: { "minecraft:coal_block": 9 }, output: { typeId: "minecraft:diamond", count: 1 } },
    { inputs: { "minecraft:gravel": 1, "minecraft:bone_meal": 1 }, output: { typeId: "minecraft:calcite", count: 1 } },
    { inputs: { "minecraft:blaze_powder": 6 }, output: { typeId: "minecraft:blaze_rod", count: 1 } },
    { inputs: { "minecraft:poppy": 1 }, output: { typeId: "minecraft:wither_rose", count: 1 } },
    { inputs: { "minecraft:spider_eye": 1 }, output: { typeId: "minecraft:fermented_spider_eye", count: 1 } },
    { inputs: { "minecraft:apple": 1 }, output: { typeId: "minecraft:chorus_fruit", count: 1 } },
    { inputs: { "minecraft:packed_ice": 9 }, output: { typeId: "minecraft:blue_ice", count: 1 } },
    { inputs: { "minecraft:magma_cream": 1 }, output: { typeId: "minecraft:slime_ball", count: 1 } },
    { inputs: { "minecraft:netherrack": 1, "minecraft:flint": 1 }, output: { typeId: "minecraft:redstone", count: 1 } },
    { inputs: { "minecraft:calcite": 1 }, output: { typeId: "minecraft:lapis_lazuli", count: 1 } },
    { inputs: { "minecraft:coal": 1, "minecraft:blaze_powder": 1 }, output: { typeId: "minecraft:gunpowder", count: 1 } },
    { inputs: { "minecraft:dirt": 1 }, output: { typeId: "minecraft:soul_soil", count: 1 } }
];

// Wire types: item id → { entity type, color code, display name }
const WIRE_TYPES = {
    "ne:copper_wire":           { entity: "ne:wire_entity",                   color: "§e", name: "Copper Wire" },
    "ne:overcharged_iron_wire": { entity: "ne:wire_overcharged_iron_entity",   color: "§7", name: "Overcharged Iron Wire" },
    "ne:overcharged_gold_wire": { entity: "ne:wire_overcharged_gold_entity",   color: "§6", name: "Overcharged Gold Wire" },
    "ne:overcharged_diamond_wire": { entity: "ne:wire_overcharged_diamond_entity", color: "§b", name: "Overcharged Diamond Wire" },
};

// Generator Coil
const GENERATOR_COIL_MAX_ENERGY = 5000; // RF capacity of the generator
// RF generated per second per magnet block type (with 12 blocks max)
const GENERATOR_COIL_RF_PER_MAGNET = {
    "ne:magnetite_block": 37.5,   // 12 × 37.5 = 450 RF/s
    "ne:layered_magnet":  50.0,   // 12 × 50.0 = 600 RF/s
    "ne:netherite_magnet": 100.0  // 12 × 100.0 = 1200 RF/s
};
const GENERATOR_COIL_MAGNET_IDS = ["ne:magnetite_block", "ne:layered_magnet", "ne:netherite_magnet"];
const GENERATOR_COIL_SCAN_RADIUS = 12;
const GENERATOR_COIL_MAX_MAGNETS = 12;

// ============================================================
// Helpers
// ============================================================

function updateThoriumCasingConnections(block) {
    if (!block || block.typeId !== "ne:thorium_casing") return;
    
    let connections = {
        "ne:east": false, "ne:west": false,
        "ne:up": false, "ne:down": false,
        "ne:south": false, "ne:north": false
    };

    for (const dir of DIRECTIONS) {
        try {
            const neighbor = block.dimension.getBlock({x: block.location.x + dir.x, y: block.location.y + dir.y, z: block.location.z + dir.z});
            if (neighbor && neighbor.typeId === "ne:thorium_casing") {
                if (dir.x === 1) connections["ne:east"] = true;
                else if (dir.x === -1) connections["ne:west"] = true;
                else if (dir.y === 1) connections["ne:up"] = true;
                else if (dir.y === -1) connections["ne:down"] = true;
                else if (dir.z === 1) connections["ne:south"] = true;
                else if (dir.z === -1) connections["ne:north"] = true;
            }
        } catch(e) {}
    }

    try {
        let perm = block.permutation;
        for (const [state, value] of Object.entries(connections)) {
            perm = perm.withState(state, value);
        }
        block.setPermutation(perm);
    } catch(e) {}
}

function updateLampPostSegment(block) {
    if (!block || block.typeId !== "ne:lamp_post") return;
    try {
        const dim = block.dimension;
        const above = dim.getBlock({x: block.location.x, y: block.location.y + 1, z: block.location.z});
        const below = dim.getBlock({x: block.location.x, y: block.location.y - 1, z: block.location.z});
        const hasAbove = above && above.typeId === "ne:lamp_post";
        const hasBelow = below && below.typeId === "ne:lamp_post";

        let seg = "solo";
        if (hasAbove && hasBelow) seg = "middle";
        else if (hasAbove && !hasBelow) seg = "base";
        else if (!hasAbove && hasBelow) seg = "top";
        
        block.setPermutation(block.permutation.withState("ne:lamp_post_segment", seg));
    } catch(e) {}
}

function getKey(loc, dimId) {
    return `${Math.floor(loc.x)},${Math.floor(loc.y)},${Math.floor(loc.z)},${dimId}`;
}

const DIRECTIONS = [
    { x: 1, y: 0, z: 0 },
    { x: -1, y: 0, z: 0 },
    { x: 0, y: 1, z: 0 },
    { x: 0, y: -1, z: 0 },
    { x: 0, y: 0, z: 1 },
    { x: 0, y: 0, z: -1 },
];

// ============================================================
// Wire connection helpers
// ============================================================

function addWireConnection(keyA, keyB) {
    if (!wireConnections.has(keyA)) wireConnections.set(keyA, new Set());
    if (!wireConnections.has(keyB)) wireConnections.set(keyB, new Set());
    wireConnections.get(keyA).add(keyB);
    wireConnections.get(keyB).add(keyA);
}

function removeWireConnectionsFor(key) {
    const neighbors = wireConnections.get(key);
    if (neighbors) {
        for (const nKey of neighbors) {
            const pairKey = getWirePairKey(key, nKey);
            const wireEnt = wireEntities.get(pairKey);
            if (wireEnt) {
                try { wireEnt.remove(); } catch (e) {}
                wireEntities.delete(pairKey);
            }
            const nSet = wireConnections.get(nKey);
            if (nSet) nSet.delete(key);
        }
        wireConnections.delete(key);
    }
}

function getConnectorTip(world, dimId, key) {
    const [x, y, z] = key.split(",");
    const cx = parseInt(x) + 0.5;
    const cy = parseInt(y) + 0.5;
    const cz = parseInt(z) + 0.5;
    let tip = { x: cx, y: cy, z: cz };
    try {
        const dim = world.getDimension(dimId);
        const block = dim.getBlock({ x: parseInt(x), y: parseInt(y), z: parseInt(z) });
        if (block) {
            if (block.typeId === "ne:electrical_connector") {
                const face = block.permutation.getState("minecraft:block_face");
                if (face === "up") tip.y = parseInt(y) + 0.625;
                else if (face === "down") tip.y = parseInt(y) + 0.375;
                else if (face === "north") { tip.y = parseInt(y) + 0.5; tip.z = parseInt(z) + 0.375; }
                else if (face === "south") { tip.y = parseInt(y) + 0.5; tip.z = parseInt(z) + 0.625; }
                else if (face === "west")  { tip.y = parseInt(y) + 0.5; tip.x = parseInt(x) + 0.375; }
                else if (face === "east")  { tip.y = parseInt(y) + 0.5; tip.x = parseInt(x) + 0.625; }
            } else if (block.typeId === "ne:street_light") {
                // Street light connects at the bottom
                tip.y = parseInt(y);
            }
        }
    } catch(e) {}
    return tip;
}

function spawnWireEntity(world, dimId, keyA, keyB, wireEntityType) {
    try {
        const dim = world.getDimension(dimId);

        const tipA = getConnectorTip(world, dimId, keyA);
        const tipB = getConnectorTip(world, dimId, keyB);

        const mx = (tipA.x + tipB.x) / 2;
        const my = (tipA.y + tipB.y) / 2;
        const mz = (tipA.z + tipB.z) / 2;

        const dx = tipB.x - tipA.x;
        const dy = tipB.y - tipA.y;
        const dz = tipB.z - tipA.z;

        const xzDist = Math.sqrt(dx*dx + dz*dz);
        const yaw   = Math.atan2(-dx, dz);
        const pitch = Math.atan2(-dy, xzDist);

        const yawDeg   = yaw   * (180 / Math.PI);
        const pitchDeg = pitch * (180 / Math.PI);
        const dist     = Math.sqrt(dx*dx + dy*dy + dz*dz);

        const entityType = wireEntityType || "ne:wire_entity";
        const entity = dim.spawnEntity(entityType, { x: mx, y: my, z: mz });
        const pairKey = getWirePairKey(keyA, keyB);
        wireEntities.set(pairKey, entity);

        entity.setProperty("ne:wire_length", dist);
        entity.setProperty("ne:pitch", pitchDeg);
        entity.setProperty("ne:yaw", yawDeg);

        return entity;
    } catch (e) {
        return null;
    }
}

// ============================================================
// Block Registration
// ============================================================

world.afterEvents.playerPlaceBlock.subscribe((ev) => {
    const id  = ev.block.typeId;
    const key = getKey(ev.block.location, ev.block.dimension.id);

    if (
        id === "ne:solar_panel" ||
        id === "ne:electrical_pipe" ||
        id === "ne:electrical_crusher" ||
        id === "ne:electrical_connector" ||
        id === "ne:street_light"
    ) {
        energyNetwork.set(key, { type: id, energy: 0 });
    }

    // ── Register magnet blocks in network so energy can flow ──
    if (GENERATOR_COIL_MAGNET_IDS.includes(id)) {
        energyNetwork.set(key, { type: id, energy: 0 });
    }

    // ── Electrical Crusher — spawn persistent animated entity ──
    if (id === "ne:electrical_crusher") {
        const crushLoc = { x: ev.block.location.x, y: ev.block.location.y, z: ev.block.location.z };
        const crushDim = ev.block.dimension;
        system.run(() => {
            try {
                const ent = crushDim.spawnEntity("ne:electrical_crusher_entity", {
                    x: crushLoc.x + 0.5, y: crushLoc.y, z: crushLoc.z + 0.5,
                });
                try { ent.setProperty("ne:active", false); } catch(e) {}
                crusherEntities.set(key, ent);
            } catch (e) {}
        });
    }

    // ── Lamp Post — stack segment logic ──
    if (id === "ne:lamp_post") {
        const postLoc = { x: ev.block.location.x, y: ev.block.location.y, z: ev.block.location.z };
        const postDim = ev.block.dimension;
        system.run(() => {
            try {
                const base = postDim.getBlock(postLoc);
                updateLampPostSegment(base);
                const below = postDim.getBlock({x: postLoc.x, y: postLoc.y - 1, z: postLoc.z});
                updateLampPostSegment(below);
                const above = postDim.getBlock({x: postLoc.x, y: postLoc.y + 1, z: postLoc.z});
                updateLampPostSegment(above);
            } catch (e) {}
        });
    }

    // ── Thorium Casing ──
    if (id === "ne:thorium_casing") {
        const casingLoc = { x: ev.block.location.x, y: ev.block.location.y, z: ev.block.location.z };
        const casingDim = ev.block.dimension;
        system.run(() => {
            try {
                const freshBlock = casingDim.getBlock(casingLoc);
                if (freshBlock) updateThoriumCasingConnections(freshBlock);
                for (const dir of DIRECTIONS) {
                    const neighbor = casingDim.getBlock({
                        x: casingLoc.x + dir.x,
                        y: casingLoc.y + dir.y,
                        z: casingLoc.z + dir.z
                    });
                    if (neighbor && neighbor.typeId === "ne:thorium_casing") {
                        updateThoriumCasingConnections(neighbor);
                    }
                }
            } catch(e) {}
        });
    }

    // ── Register Generator Coil ──
    if (id === "ne:generator_coil") {
        energyNetwork.set(key, { type: "ne:generator_coil", energy: 0 });


        const loc = ev.block.location;
        const dim = ev.block.dimension;
        const face = ev.block.permutation.getState("minecraft:cardinal_direction");

        try {
            const ent = dim.spawnEntity("ne:generator_coil_entity", {
                x: loc.x + 0.5,
                y: loc.y,
                z: loc.z + 0.5,
            });
            let rot = 0;
            if (face === "north") rot = 180;
            else if (face === "west") rot = 90;
            else if (face === "east") rot = -90;
            ent.setRotation({ x: 0, y: rot });
            
            try { ent.setProperty("ne:active", false); } catch (e) {}
            generatorCoilEntities.set(key, ent);
        } catch (e) {}
    }

    // ── Register Carbon Brushes ──
    if (id === "ne:carbon_brushes") {
        energyNetwork.set(key, { type: "ne:carbon_brushes", energy: 0 });

        const loc = ev.block.location;
        const dim = ev.block.dimension;
        const cbFace = ev.block.permutation.getState("minecraft:cardinal_direction");

        try {
            const ent = dim.spawnEntity("ne:carbon_brushes_entity", {
                x: loc.x + 0.5,
                y: loc.y,
                z: loc.z + 0.5,
            });
            // Rotate entity to match block direction
            let cbFaceInt = 1;
            if (cbFace === "north") cbFaceInt = 2;
            else if (cbFace === "south") cbFaceInt = 3;
            else if (cbFace === "west") cbFaceInt = 4;
            else if (cbFace === "east") cbFaceInt = 5;
            ent.setProperty("ne:facing", cbFaceInt);
            try { ent.setProperty("ne:active", false); } catch (e) {}
            carbonBrushesEntities.set(key, ent);
        } catch (e) {}
    }

    // ── Register all Energiser variants ──
    if (ENERGISER_IDS.includes(id)) {
        energyNetwork.set(key, { type: "ne:energiser", energy: 0 });

        const loc = ev.block.location;
        const dim = ev.block.dimension;

        // Visual entity overlay on the block face
        try {
            const ent = dim.spawnEntity("ne:energiser_entity", {
                x: loc.x + 0.5,
                y: loc.y,
                z: loc.z + 0.5,
            });
            try { ent.setProperty("ne:active", false); } catch (e) {}
            energiserEntities.set(key, ent);
        } catch (e) {}
    }

    // ── Spawn visual entity for electrical_connector ──
    if (id === "ne:electrical_connector") {
        try {
            const loc  = ev.block.location;
            const dim  = ev.block.dimension;
            const face = ev.block.permutation.getState("minecraft:block_face");

            // Model: cube origin [-2,9,-2] size [4,1,4], pivot [0,8,0]
            // In "up" state: tip is at +10/16 above entity origin → entity at y=loc.y makes tip at loc.y+0.625
            // For side faces: rotate X±90° around pivot y=8. After rotation, the tip maps to ±z offset.
            // To make tip flush with the block face we offset the spawn position.
            let faceInt = 1; // up
            if (face === "down")  { faceInt = 0; }
            else if (face === "north") { faceInt = 2; }
            else if (face === "south") { faceInt = 3; }
            else if (face === "west")  { faceInt = 4; }
            else if (face === "east")  { faceInt = 5; }

            const entity = dim.spawnEntity("ne:electrical_connector_entity", {
                x: loc.x + 0.5, y: loc.y, z: loc.z + 0.5,
            });
            entity.setProperty("ne:facing", faceInt);
            connectorEntities.set(key, entity);
        } catch (e) {}
    }
});

// When a player breaks one of our blocks, remove it from the network
world.afterEvents.playerBreakBlock.subscribe((ev) => {
    const brokenId = ev.brokenBlockPermutation.type.id;
    const brokenLoc = { x: ev.block.location.x, y: ev.block.location.y, z: ev.block.location.z };
    const brokenDim = ev.dimension;
    const key = getKey(brokenLoc, brokenDim.id);

    // ── Thorium Casing: update neighbors ──
    if (brokenId === "ne:thorium_casing") {
        system.run(() => {
            for (const dir of DIRECTIONS) {
                try {
                    const neighbor = brokenDim.getBlock({
                        x: brokenLoc.x + dir.x,
                        y: brokenLoc.y + dir.y,
                        z: brokenLoc.z + dir.z
                    });
                    if (neighbor && neighbor.typeId === "ne:thorium_casing") {
                        updateThoriumCasingConnections(neighbor);
                    }
                } catch(e) {}
            }
        });
    }

    // ── Lamp Post: update neighbour segments when broken ──
    if (brokenId === "ne:lamp_post") {
        system.run(() => {
            try {
                const below = brokenDim.getBlock({x: brokenLoc.x, y: brokenLoc.y - 1, z: brokenLoc.z});
                updateLampPostSegment(below);
                const above = brokenDim.getBlock({x: brokenLoc.x, y: brokenLoc.y + 1, z: brokenLoc.z});
                updateLampPostSegment(above);
            } catch(e) {}
        });
    }

    // ── Remove all machine entities at this location (map lookup + spatial sweep) ──
    // We do BOTH to handle the case where the tracking Map lost its reference after a reload.
    const ALL_MACHINE_ENTITY_TYPES = [
        "ne:electrical_crusher_entity",
        "ne:electrical_connector_entity",
        "ne:energiser_entity",
        "ne:generator_coil_entity",
        "ne:carbon_brushes_entity"
    ];

    // 1) Remove via tracking Maps (fast path)
    const trackedEnts = [
        crusherEntities.get(key),
        connectorEntities.get(key),
        energiserEntities.get(key),
        generatorCoilEntities.get(key),
        carbonBrushesEntities.get(key)
    ];
    for (const ent of trackedEnts) {
        if (ent) try { ent.remove(); } catch(e) {}
    }

    // 2) Spatial sweep — catches orphaned entities after world reloads.
    // Entities are spawned at (x+0.5, y, z+0.5) so we search at both y and y+0.5.
    // maxDistance MUST stay <= 0.5 so we don't accidentally hit entities on adjacent blocks (distance = 1.0).
    for (const searchY of [brokenLoc.y, brokenLoc.y + 0.5]) {
        try {
            const ents = brokenDim.getEntities({
                location: { x: brokenLoc.x + 0.5, y: searchY, z: brokenLoc.z + 0.5 },
                maxDistance: 0.5
            });
            for (const e of ents) {
                if (ALL_MACHINE_ENTITY_TYPES.includes(e.typeId)) {
                    try { e.remove(); } catch(err) {}
                }
            }
        } catch(e) {}
    }

    energyNetwork.delete(key);
    removeWireConnectionsFor(key);

    for (const [playerName, pendingData] of pendingWire) {
        if (pendingData.key === key) pendingWire.delete(playerName);
    }

    // Clean up tracking Maps
    connectorEntities.delete(key);
    energiserEntities.delete(key);
    energiserTimers.delete(key);
    generatorCoilEntities.delete(key);
    carbonBrushesEntities.delete(key);
    crusherEntities.delete(key);

    // Persist the removal immediately so it survives a world reload
    if (isInitialized) saveState();
});

// ============================================================
// Wire Items — Use Item on Block (supports all 4 wire types)
// ============================================================

world.beforeEvents.itemUseOn.subscribe((ev) => {
    const item = ev.itemStack;
    if (!item) return;

    const wireInfo = WIRE_TYPES[item.typeId];
    if (!wireInfo) return;

    const block = ev.block;
    if (!block || (block.typeId !== "ne:electrical_connector" && block.typeId !== "ne:street_light")) return;

    ev.cancel = true;

    const player     = ev.source;
    const dimId      = block.dimension.id;
    const targetKey  = getKey(block.location, dimId);
    const playerName = player.name;
    const wireItemId = item.typeId;
    const color      = wireInfo.color;
    const wireName   = wireInfo.name;
    const entityType = wireInfo.entity;

    system.run(() => {
        if (!pendingWire.has(playerName)) {
            pendingWire.set(playerName, { key: targetKey, dimId: dimId, wireItemId: wireItemId });

            try {
                const dim = world.getDimension(dimId);
                const loc = block.location;
                dim.spawnParticle("minecraft:endrod", {
                    x: loc.x + 0.5,
                    y: loc.y + 1.2,
                    z: loc.z + 0.5,
                });
            } catch (e) {}

            try {
                player.sendMessage(`${color}[${wireName}] §fFirst connector selected! Now use on another Electrical Connector to link them.`);
            } catch (e) {}
        } else {
            const pendingData = pendingWire.get(playerName);

            // If a different wire type was used than the one that started the connection, cancel and restart
            if (pendingData.wireItemId !== wireItemId) {
                pendingWire.set(playerName, { key: targetKey, dimId: dimId, wireItemId: wireItemId });
                try {
                    player.sendMessage(`${color}[${wireName}] §fPrevious selection cancelled. New first connector selected!`);
                } catch (e) {}
                return;
            }

            const firstKey = pendingData.key;
            pendingWire.delete(playerName);

            if (firstKey === targetKey) {
                try {
                    player.sendMessage(`§c[${wireName}] §fYou clicked the same connector! Select two different connectors.`);
                } catch (e) {}
                return;
            }

            const firstData  = energyNetwork.get(firstKey);
            const targetData = energyNetwork.get(targetKey);

            const validTypes = ["ne:electrical_connector", "ne:street_light"];
            if (!firstData || !validTypes.includes(firstData.type)) {
                try { player.sendMessage(`§c[${wireName}] §fThe first connector is no longer valid.`); } catch (e) {}
                return;
            }
            if (!targetData || !validTypes.includes(targetData.type)) {
                try { player.sendMessage(`§c[${wireName}] §fTarget is not a valid Electrical Connector.`); } catch (e) {}
                return;
            }

            if (wireConnections.has(firstKey) && wireConnections.get(firstKey).has(targetKey)) {
                try { player.sendMessage(`§6[${wireName}] §fThese connectors are already linked!`); } catch (e) {}
                return;
            }

            addWireConnection(firstKey, targetKey);
            spawnWireEntity(world, dimId, firstKey, targetKey, entityType);

            const [fx, fy, fz] = firstKey.split(",").map(Number);
            const [tx, ty, tz] = targetKey.split(",").map(Number);
            try {
                const dim = world.getDimension(dimId);
                dim.spawnParticle("minecraft:villager_happy", { x: fx + 0.5, y: fy + 1.2, z: fz + 0.5 });
                dim.spawnParticle("minecraft:villager_happy", { x: tx + 0.5, y: ty + 1.2, z: tz + 0.5 });
                dim.spawnParticle("minecraft:endrod",         { x: fx + 0.5, y: fy + 1.5, z: fz + 0.5 });
                dim.spawnParticle("minecraft:endrod",         { x: tx + 0.5, y: ty + 1.5, z: tz + 0.5 });
            } catch (e) {}

            try {
                player.sendMessage(`§a[${wireName}] §fConnectors linked! Energy can now flow between them.`);
            } catch (e) {}
        }
    });
});

// ============================================================
// Block Interactions
// ============================================================



// ============================================================
// Energy Connectivity (BFS)
// ============================================================

/**
 * Starting from any machine position, BFS through adjacent pipes AND
 * wire-linked connectors to find all connected solar panels.
 */
function findConnectedSources(machineKey, dimId) {
    const visited = new Set([machineKey]);
    const queue   = [];
    const sources  = [];

    function exploreNeighbors(nodeKey) {
        const [px, py, pz] = nodeKey.split(",").map(Number);
        const node = energyNetwork.get(nodeKey);

        for (const dir of DIRECTIONS) {
            const nKey = `${px + dir.x},${py + dir.y},${pz + dir.z},${dimId}`;
            if (visited.has(nKey)) continue;

            const n = energyNetwork.get(nKey);
            if (!n) continue;

            if (n.type === "ne:solar_panel") {
                visited.add(nKey);
                sources.push(nKey);
            } else if (n.type === "ne:generator_coil" && node && node.type === "ne:carbon_brushes") {
                visited.add(nKey);
                sources.push(nKey);
            } else if (n.type === "ne:electrical_pipe" || n.type === "ne:electrical_connector" || n.type === "ne:carbon_brushes") {
                visited.add(nKey);
                queue.push(nKey);
            }
        }

        if (node && node.type === "ne:electrical_connector") {
            const wired = wireConnections.get(nodeKey);
            if (wired) {
                for (const wKey of wired) {
                    if (visited.has(wKey)) continue;
                    visited.add(wKey);

                    const w = energyNetwork.get(wKey);
                    if (!w) continue;

                    if (w.type === "ne:solar_panel") {
                        sources.push(wKey);
                    } else if (w.type === "ne:electrical_pipe" || w.type === "ne:electrical_connector") {
                        queue.push(wKey);
                    }
                }
            }
        }
    }

    exploreNeighbors(machineKey);
    while (queue.length > 0) {
        exploreNeighbors(queue.shift());
    }

    return sources;
}

// ============================================================
// Main Energy Loop
// ============================================================

system.runInterval(() => {
    // --- Step 1: Solar panels generate RF during daytime ---
    const time      = world.getTimeOfDay();
    const isDaytime = time >= 0 && time < 12000;

    for (const [_key, data] of energyNetwork) {
        if (data.type === "ne:solar_panel" && isDaytime) {
            data.energy = Math.min(data.energy + SOLAR_RF_GEN, MAX_ENERGY);
        }
    }

    // --- Step 2: Crushers consume RF and process cobblestone → gravel ---
    for (const [key, data] of energyNetwork) {
        if (data.type !== "ne:electrical_crusher") continue;

        const parts = key.split(",");
        const cx    = parseInt(parts[0]);
        const cy    = parseInt(parts[1]);
        const cz    = parseInt(parts[2]);
        const dimId = parts.slice(3).join(",");

        const sources = findConnectedSources(key, dimId);
        let source = null;
        for (const sKey of sources) {
            const sData = energyNetwork.get(sKey);
            if (sData && sData.energy >= CRUSHER_COST) {
                source = sData;
                break;
            }
        }
        if (!source) continue;

        try {
            const dim   = world.getDimension(dimId);
            const items = dim.getEntities({
                type:        "minecraft:item",
                location:    { x: cx + 0.5, y: cy + 1.5, z: cz + 0.5 },
                maxDistance: 0.9,
            });

            let processedItem = false;
            for (const entity of items) {
                const itemComp = entity.getComponent("minecraft:item");
                if (!itemComp) continue;

                const stack = itemComp.itemStack;
                const typeId = stack.typeId;

                const crusherRecipes = {
                    "minecraft:cobblestone": [{ typeId: "minecraft:gravel", count: 1, chance: 1 }],
                    "minecraft:basalt": [{ typeId: "minecraft:netherrack", count: 1, chance: 1 }],
                    "minecraft:obsidian": [{ typeId: "minecraft:crying_obsidian", count: 1, chance: 1 }],
                    "minecraft:soul_sand": [{ typeId: "minecraft:glowstone_dust", count: 1, chance: 1 }],
                    "minecraft:cactus": [{ typeId: "minecraft:bone_meal", count: 1, chance: 1 }],
                    "minecraft:tuff": [
                        { typeId: "create:crushed_raw_copper", count: 1, chance: 1 },
                        { typeId: "create:crushed_raw_zinc", count: 1, chance: 1 }
                    ],
                    "minecraft:nether_brick": [
                        { typeId: "minecraft:netherite_scrap", count: 1, chance: 0.02 }
                    ]
                };

                const recipe = crusherRecipes[typeId];
                if (!recipe) continue;

                if (stack.amount > 1) {
                    entity.remove();
                    dim.spawnItem(new ItemStack(typeId, stack.amount - 1), {
                        x: cx + 0.5, y: cy + 1.5, z: cz + 0.5,
                    });
                } else {
                    entity.remove();
                }

                for (const output of recipe) {
                    if (Math.random() <= output.chance) {
                        try {
                            dim.spawnItem(new ItemStack(output.typeId, output.count), {
                                x: cx + 0.5, y: cy - 0.5, z: cz + 0.5,
                            });
                        } catch(e) {
                            // Ignore if the addon (like create) is not loaded for those items
                        }
                    }
                }

                dim.spawnParticle("minecraft:villager_happy", { x: cx + 0.5, y: cy + 1.2, z: cz + 0.5 });
                dim.spawnParticle("minecraft:basic_smoke_particle", { x: cx + 0.5, y: cy + 1.2, z: cz + 0.5 });

                processedItem = true;
                source.energy -= CRUSHER_COST;
                break;
            }

            const crushEnt = crusherEntities.get(key);
            if (crushEnt) { try { crushEnt.setProperty("ne:active", processedItem); } catch(e) {} }
        } catch (e) {}
    }

    // --- Step 3: Energisers process ingots → Overcharged items (7 seconds) ---
    for (const [key, data] of energyNetwork) {
        if (data.type !== "ne:energiser") continue;

        const parts = key.split(",");
        const cx    = parseInt(parts[0]);
        const cy    = parseInt(parts[1]);
        const cz    = parseInt(parts[2]);
        const dimId = parts.slice(3).join(",");

        const energiserEnt = energiserEntities.get(key);
        if (!energiserEnt) continue;

        // Find a connected source with enough energy
        const sources = findConnectedSources(key, dimId);
        let source = null;
        for (const sKey of sources) {
            const sData = energyNetwork.get(sKey);
            if (sData && sData.energy >= ENERGISER_COST) {
                source = sData;
                break;
            }
        }

        if (!source) {
            // No energy — deactivate energiser and clear timer
            try { energiserEnt.setProperty("ne:active", false); } catch (e) {}
            energiserTimers.delete(key);
            continue;
        }

        // Search for valid items in the beam space (1 block below the energiser)
        try {
            const dim   = world.getDimension(dimId);
            const items = dim.getEntities({
                type:        "minecraft:item",
                location:    { x: cx + 0.5, y: cy - 1, z: cz + 0.5 },
                maxDistance: 1.0,
            });

            const availableItems = {};
            for (const entity of items) {
                const itemComp = entity.getComponent("minecraft:item");
                if (!itemComp) continue;
                const typeId = itemComp.itemStack.typeId;
                if (!availableItems[typeId]) availableItems[typeId] = { totalCount: 0, entities: [] };
                availableItems[typeId].totalCount += itemComp.itemStack.amount;
                availableItems[typeId].entities.push(entity);
            }

            let foundRecipe = null;
            let recipeIndex = -1;

            for (let i = 0; i < ENERGISER_RECIPES.length; i++) {
                const r = ENERGISER_RECIPES[i];
                let canCraft = true;
                for (const inputType in r.inputs) {
                    if (!availableItems[inputType] || availableItems[inputType].totalCount < r.inputs[inputType]) {
                        canCraft = false;
                        break;
                    }
                }
                if (canCraft) {
                    foundRecipe = r;
                    recipeIndex = i;
                    break;
                }
            }

            if (!foundRecipe) {
                // No valid item — deactivate and reset timer
                try { energiserEnt.setProperty("ne:active", false); } catch (e) {}
                energiserTimers.delete(key);
                continue;
            }

            // Valid item + energy → activate the energiser animation
            try { energiserEnt.setProperty("ne:active", true); } catch (e) {}

            // Consume RF this second
            source.energy -= ENERGISER_COST;

            // Update or start the processing timer
            let timer = energiserTimers.get(key);
            if (!timer || timer.recipeIndex !== recipeIndex) {
                // New recipe — reset timer
                timer = { recipeIndex: recipeIndex, elapsed: 0 };
                energiserTimers.set(key, timer);
            }

            timer.elapsed++;

            // Progress particle every second
            dim.spawnParticle("minecraft:endrod", {
                x: cx + 0.5, y: cy - 0.5, z: cz + 0.5,
            });

            // Get target ticks from the type, defaults to 7 if unknown (e.g., if block id mismatch)
            let targetTicks = 7;
            try {
                const block = dim.getBlock({ x: cx, y: cy, z: cz });
                if (block && ENERGISER_PROCESS_TICKS[block.typeId]) {
                    targetTicks = ENERGISER_PROCESS_TICKS[block.typeId];
                }
            } catch(e) {}

            if (timer.elapsed >= targetTicks) {
                // ── Processing complete! ──
                
                // Consume the ingredients
                for (const inputType in foundRecipe.inputs) {
                    let required = foundRecipe.inputs[inputType];
                    for (const entity of availableItems[inputType].entities) {
                        if (required <= 0) break;
                        const itemComp = entity.getComponent("minecraft:item");
                        if (!itemComp) continue;
                        const stack = itemComp.itemStack;
                        const amount = stack.amount;

                        try { entity.remove(); } catch(e) {}

                        if (amount > required) {
                            dim.spawnItem(new ItemStack(inputType, amount - required), {
                                x: cx + 0.5, y: cy - 0.9, z: cz + 0.5,
                            });
                            required = 0;
                        } else {
                            required -= amount;
                        }
                    }
                }

                // Spawn output
                dim.spawnItem(new ItemStack(foundRecipe.output.typeId, foundRecipe.output.count), {
                    x: cx + 0.5, y: cy - 0.9, z: cz + 0.5,
                });

                // Celebration effects
                dim.spawnParticle("minecraft:villager_happy", { x: cx + 0.5, y: cy + 0.5, z: cz + 0.5 });
                dim.spawnParticle("minecraft:endrod",         { x: cx + 0.5, y: cy + 1.0, z: cz + 0.5 });
                dim.spawnParticle("minecraft:endrod",         { x: cx + 0.5, y: cy - 0.5, z: cz + 0.5 });

                // Deactivate energiser — ready for next item
                try { energiserEnt.setProperty("ne:active", false); } catch (e) {}
                energiserTimers.delete(key);
            }
        } catch (e) {
            // Chunk may not be loaded — ignore silently
        }
    }
    // --- Step 4: Generator Coil generates RF from nearby magnet blocks ---
    for (const [key, data] of energyNetwork) {
        if (data.type !== "ne:generator_coil") continue;

        const parts = key.split(",");
        const cx    = parseInt(parts[0]);
        const cy    = parseInt(parts[1]);
        const cz    = parseInt(parts[2]);
        const dimId = parts.slice(3).join(",");

        const coilEnt = generatorCoilEntities.get(key);
        if (!coilEnt) continue;

        // Scan up to GENERATOR_COIL_SCAN_RADIUS in all directions for magnet blocks
        let totalRF = 0;
        let magnetCount = 0;

        try {
            const dim = world.getDimension(dimId);

            for (let dx = -GENERATOR_COIL_SCAN_RADIUS; dx <= GENERATOR_COIL_SCAN_RADIUS && magnetCount < GENERATOR_COIL_MAX_MAGNETS; dx++) {
                for (let dy = -GENERATOR_COIL_SCAN_RADIUS; dy <= GENERATOR_COIL_SCAN_RADIUS && magnetCount < GENERATOR_COIL_MAX_MAGNETS; dy++) {
                    for (let dz = -GENERATOR_COIL_SCAN_RADIUS; dz <= GENERATOR_COIL_SCAN_RADIUS && magnetCount < GENERATOR_COIL_MAX_MAGNETS; dz++) {
                        if (dx === 0 && dy === 0 && dz === 0) continue;
                        try {
                            const block = dim.getBlock({ x: cx + dx, y: cy + dy, z: cz + dz });
                            if (!block) continue;
                            const rfPerBlock = GENERATOR_COIL_RF_PER_MAGNET[block.typeId];
                            if (rfPerBlock) {
                                totalRF += rfPerBlock;
                                magnetCount++;
                            }
                        } catch (e) {}
                    }
                }
            }
        } catch (e) {}

        if (magnetCount >= 12) {
            // Generate energy and cap at max
            data.energy = Math.min(data.energy + totalRF, GENERATOR_COIL_MAX_ENERGY);
            try { coilEnt.setProperty("ne:active", true); } catch (e) {}
            // Emit particles to show it's running
            try {
                const dim = world.getDimension(dimId);
                dim.spawnParticle("minecraft:endrod", { x: cx + 0.5, y: cy + 1.5, z: cz + 0.5 });
            } catch (e) {}
        } else {
            try { coilEnt.setProperty("ne:active", false); } catch (e) {}
        }
    }

    // --- Step 5: Update Carbon Brushes visual state ---
    for (const [key, data] of energyNetwork) {
        if (data.type !== "ne:carbon_brushes") continue;

        const brushEnt = carbonBrushesEntities.get(key);
        if (!brushEnt) continue;

        const parts = key.split(",");
        const cx    = parseInt(parts[0]);
        const cy    = parseInt(parts[1]);
        const cz    = parseInt(parts[2]);
        const dimId = parts.slice(3).join(",");

        let isActive = false;
        for (const dir of DIRECTIONS) {
            const nKey = `${cx + dir.x},${cy + dir.y},${cz + dir.z},${dimId}`;
            const nData = energyNetwork.get(nKey);
            if (nData && nData.type === "ne:generator_coil" && nData.energy > 0) {
                isActive = true;
                break;
            }
        }
        
        try { brushEnt.setProperty("ne:active", isActive); } catch (e) {}
    }

    // --- Step 6: Street Lights — activate when connected to a live energy source ---
    for (const [key, data] of energyNetwork) {
        if (data.type !== "ne:street_light") continue;

        const parts = key.split(",");
        const cx    = parseInt(parts[0]);
        const cy    = parseInt(parts[1]);
        const cz    = parseInt(parts[2]);
        const dimId = parts.slice(3).join(",");

        const sources = findConnectedSources(key, dimId);
        let hasEnergy = false;
        for (const sKey of sources) {
            const sData = energyNetwork.get(sKey);
            if (sData && sData.energy > 0) { hasEnergy = true; break; }
        }

        try {
            const dim   = world.getDimension(dimId);
            const block = dim.getBlock({ x: cx, y: cy, z: cz });
            if (block && block.typeId === "ne:street_light") {
                const currentActive = block.permutation.getState("ne:active");
                if (currentActive !== hasEnergy) {
                    block.setPermutation(block.permutation.withState("ne:active", hasEnergy));
                }
            }
        } catch (e) {}
    }

    // --- Step 7: Electric Glasses HUD ---
    const players = world.getAllPlayers();
    for (const player of players) {
        try {
            const equipment = player.getComponent("minecraft:equippable");
            if (!equipment) continue;
            const helmet = equipment.getEquipment("Head");
            if (!helmet || helmet.typeId !== "ne:electric_glasses") continue;

            // Player is wearing the glasses, cast a ray
            const hit = player.getBlockFromViewDirection({ maxDistance: 6 });
            if (hit && hit.block) {
                const loc = hit.block.location;
                const dimId = hit.block.dimension.id;
                const bKey = getKey(loc, dimId);
                const bData = energyNetwork.get(bKey);

                if (bData) {
                    let msg = "";
                    if (bData.type === "ne:generator_coil") {
                        msg = `§e⚡ Generator Coil §f| Armazenado: §a${bData.energy.toFixed(0)} / ${GENERATOR_COIL_MAX_ENERGY} RF`;
                    } else if (bData.type === "ne:solar_panel") {
                        msg = `§e⚡ Solar Panel §f| Armazenado: §a${bData.energy.toFixed(0)} / ${MAX_ENERGY} RF`;
                    } else if (bData.type === "ne:energiser") {
                        msg = `§b🔋 Energiser §f| Processando: §e${energiserTimers.has(bKey) ? "Sim" : "Não"}`;
                    } else if (bData.type === "ne:electrical_crusher") {
                        msg = `§c🔋 Crusher §f| Custo: §c${CRUSHER_COST} RF/oper.`;
                    } else if (bData.type === "ne:carbon_brushes") {
                        const bBrushEnt = carbonBrushesEntities.get(bKey);
                        const bIsActive = bBrushEnt ? bBrushEnt.getProperty("ne:active") : false;
                        msg = `§6🔧 Carbon Brushes §f| Transmissor Ativo: §a${bIsActive ? "Sim" : "Não"}`;
                    } else if (bData.type === "ne:electrical_pipe" || bData.type === "ne:electrical_connector") {
                        msg = `§8🔌 Condutor §f| Status: OK`;
                    }
                    
                    if (msg) {
                        player.onScreenDisplay.setActionBar(msg);
                    }
                }
            }
        } catch (e) {}
    }

    // --- Save state every 5 cycles so machines survive world reloads ---
    saveState();

}, TICK_RATE);
