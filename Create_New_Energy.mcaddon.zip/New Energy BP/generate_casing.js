const fs = require('fs');

const boneNames = [
    "default", "all_except_up", "all_except_down", "all_except_north", "all_except_south", 
    "all_except_east", "all_except_west", "up_south_west", "up_south_west_east", "up_south_east", 
    "up_down_south_west", "up_down_south_east", "down_south_west", "down_south_west_east", 
    "down_south_east", "down_north_east", "up_down_north_east", "up_north_east", "down_north_west", 
    "down_north_west_east", "up_down_north_west", "up_north_west", "up_north_west_east", 
    "up_north_south_east", "up_north_south_west", "down_north_south_west", "down_north_south_east", 
    "north_east", "all_cardinals", "north_south_east", "north_west", "north_west_east", 
    "north_south_west", "south_west", "south_east", "south_west_east", "up_down_west_east", 
    "up_east", "up_down_east", "up_west", "up_west_east", "up_down_west", "down_west", 
    "down_east", "down_west_east", "down", "up", "up_down", "down_south", "down_north_south", 
    "down_north", "up_down_north_south", "up_north_south", "up_down_south", "up_south", 
    "up_down_north", "up_north", "west_east", "west", "east", "south", "north", "north_south"
];

const allDirs = ['up', 'down', 'north', 'south', 'east', 'west'];

const boneVisibility = {};

boneNames.forEach(bone => {
    let required = [];
    let excluded = [];

    if (bone === "default") {
        excluded = [...allDirs];
    } else if (bone.startsWith("all_except_")) {
        const dir = bone.replace("all_except_", "");
        excluded = [dir];
        required = allDirs.filter(d => d !== dir);
    } else if (bone === "all_cardinals") {
        required = [...allDirs];
    } else {
        // e.g. up_south_west
        const parts = bone.split('_');
        required = parts;
        excluded = allDirs.filter(d => !parts.includes(d));
    }

    const conditions = [];
    required.forEach(d => conditions.push(`q.block_state('ne:${d}')`));
    excluded.forEach(d => conditions.push(`!q.block_state('ne:${d}')`));

    boneVisibility[bone] = conditions.join(" && ");
});

const blockJson = {
    "format_version": "1.21.40",
    "minecraft:block": {
        "description": {
            "identifier": "ne:thorium_casing",
            "menu_category": {
                "category": "items",
                "group": "itemGroup.name.ne"
            },
            "states": {
                "ne:up": [false, true],
                "ne:down": [false, true],
                "ne:north": [false, true],
                "ne:south": [false, true],
                "ne:east": [false, true],
                "ne:west": [false, true]
            }
        },
        "components": {
            "minecraft:destructible_by_mining": {
                "seconds_to_destroy": 4.0
            },
            "minecraft:destructible_by_explosion": {
                "explosion_resistance": 6.0
            },
            "minecraft:material_instances": {
                "*": {
                    "texture": "thorium_casing_connected",
                    "render_method": "opaque"
                }
            },
            "minecraft:geometry": {
                "identifier": "geometry.create.connected_block",
                "bone_visibility": boneVisibility
            }
        }
    }
};

fs.writeFileSync('blocks/thorium_casing.json', JSON.stringify(blockJson, null, 4));
console.log("Updated blocks/thorium_casing.json");
