export const miniBlocksTypes = [
    "vtng_mb:miniblock",
    "vtng_mb:microblock",
    "vtng_mb:nanoblock"
];

export const placeSounds = new Map([
    ["oak_planks", "dig.wood"],
    ["spruce_planks", "dig.wood"],
    ["birch_planks", "dig.wood"],
    ["jungle_planks", "dig.wood"],
    ["acacia_planks", "dig.wood"],
    ["dark_oak_planks", "dig.wood"],
    ["mangrove_planks", "dig.wood"],
    ["cherry_planks", "dig.wood"],
    ["pale_oak_planks", "dig.wood"],
    ["bamboo_planks", "dig.wood"],
    ["bamboo_mosaic", "dig.wood"],
    ["crimson_planks", "dig.wood"],
    ["warped_planks", "dig.wood"],

    ["brick_block", "dig.stone"],
    ["stone_bricks", "dig.stone"],
    ["mossy_stone_bricks", "dig.stone"],
    ["cracked_stone_bricks", "dig.stone"],
    ["chiseled_stone_bricks", "dig.stone"],
    ["smooth_stone", "dig.stone"],
    ["end_bricks", "dig.stone"],
    ["polished_blackstone_bricks", "dig.stone"],
    ["cracked_polished_blackstone_bricks", "dig.stone"],
    ["gilded_blackstone", "dig.stone"],
    ["chiseled_polished_blackstone", "dig.stone"],
    ["deepslate_tiles", "place.deepslate"],
    ["cracked_deepslate_tiles", "place.deepslate"],
    ["deepslate_bricks", "place.deepslate"],
    ["tuff_bricks", "dig.stone"],
    ["cracked_deepslate_bricks", "place.deepslate"],
    ["chiseled_deepslate", "place.deepslate"],

    ["cobblestone", "dig.stone"],
    ["mossy_cobblestone", "dig.stone"],
    ["cobbled_deepslate", "place.deepslate"],

    ["smooth_sandstone", "dig.stone"],
    ["smooth_red_sandstone", "dig.stone"],

    ["coal_block", "dig.stone"],

    ["copper_block", "dig.copper"],
    ["exposed_copper", "dig.copper"],
    ["weathered_copper", "dig.copper"],
    ["oxidized_copper", "dig.copper"],
    ["cut_copper", "dig.copper"],
    ["exposed_cut_copper", "dig.copper"],
    ["weathered_cut_copper", "dig.copper"],
    ["oxidized_cut_copper", "dig.copper"],
    ["chiseled_copper", "dig.copper"],
    ["exposed_chiseled_copper", "dig.copper"],
    ["weathered_chiseled_copper", "dig.copper"],
    ["oxidized_chiseled_copper", "dig.copper"],

    ["iron_block", "break.iron"],
    ["gold_block", "use.stone"],
    ["emerald_block", "use.stone"],
    ["diamond_block", "use.stone"],
    ["lapis_block", "dig.stone"],

    ["raw_copper_block", "dig.copper"],
    ["raw_iron_block", "break.iron"],
    ["raw_gold_block", "use.stone"],

    ["quartz_block", "dig.stone"],
    ["quartz_bricks", "dig.stone"],
    ["smooth_quartz", "dig.stone"],

    ["prismarine", "dig.stone"],
    ["prismarine_bricks", "dig.stone"],
    ["dark_prismarine", "dig.stone"],

    ["honeycomb_block", "dig.cloth"],
    ["resin_block", "dig.stone"],
    ["resin_bricks", "dig.stone"],
    ["chiseled_resin_bricks", "dig.stone"],

    ["nether_brick", "dig.nether_brick"],
    ["red_nether_brick", "dig.nether_brick"],
    ["chiseled_nether_bricks", "dig.nether_brick"],
    ["cracked_nether_bricks", "dig.nether_brick"],
    ["netherite_block", "dig.netherite"],

    ["white_wool", "dig.cloth"],
    ["light_gray_wool", "dig.cloth"],
    ["gray_wool", "dig.cloth"],
    ["black_wool", "dig.cloth"],
    ["brown_wool", "dig.cloth"],
    ["red_wool", "dig.cloth"],
    ["orange_wool", "dig.cloth"],
    ["yellow_wool", "dig.cloth"],
    ["lime_wool", "dig.cloth"],
    ["green_wool", "dig.cloth"],
    ["cyan_wool", "dig.cloth"],
    ["light_blue_wool", "dig.cloth"],
    ["blue_wool", "dig.cloth"],
    ["purple_wool", "dig.cloth"],
    ["magenta_wool", "dig.cloth"],
    ["pink_wool", "dig.cloth"],

    ["white_concrete", "dig.stone"],
    ["light_gray_concrete", "dig.stone"],
    ["gray_concrete", "dig.stone"],
    ["black_concrete", "dig.stone"],
    ["brown_concrete", "dig.stone"],
    ["red_concrete", "dig.stone"],
    ["orange_concrete", "dig.stone"],
    ["yellow_concrete", "dig.stone"],
    ["lime_concrete", "dig.stone"],
    ["green_concrete", "dig.stone"],
    ["cyan_concrete", "dig.stone"],
    ["light_blue_concrete", "dig.stone"],
    ["blue_concrete", "dig.stone"],
    ["purple_concrete", "dig.stone"],
    ["magenta_concrete", "dig.stone"],
    ["pink_concrete", "dig.stone"],

    ["hardened_clay", "dig.stone"],
    ["white_terracotta", "dig.stone"],
    ["light_gray_terracotta", "dig.stone"],
    ["gray_terracotta", "dig.stone"],
    ["black_terracotta", "dig.stone"],
    ["brown_terracotta", "dig.stone"],
    ["red_terracotta", "dig.stone"],
    ["orange_terracotta", "dig.stone"],
    ["yellow_terracotta", "dig.stone"],
    ["lime_terracotta", "dig.stone"],
    ["green_terracotta", "dig.stone"],
    ["cyan_terracotta", "dig.stone"],
    ["light_blue_terracotta", "dig.stone"],
    ["blue_terracotta", "dig.stone"],
    ["purple_terracotta", "dig.stone"],
    ["magenta_terracotta", "dig.stone"],
    ["pink_terracotta", "dig.stone"],

    ["purpur_block", "dig.stone"],
    ["packed_mud", "dig.stone"],
    ["mud_bricks", "dig.stone"],

    ["glowstone", "dig.stone"],
    ["sea_lantern", "dig.stone"],
    ["redstone_block", "use.stone"],

    ["nether_wart_block", "dig.cloth"],
    ["warped_wart_block", "dig.cloth"],
    ["shroomlight", "dig.stone"],
    ["netherrack", "dig.netherrack"],
    ["soul_soil", "dig.sand"],
    ["dirt", "dig.grass"],
    ["sand", "dig.sand"],
    ["red_sand", "dig.sand"],
    ["gravel", "dig.gravel"],
    ["mud", "dig.sand"],
    ["clay", "dig.sand"],

    ["stone", "dig.stone"],
    ["granite", "dig.stone"],
    ["diorite", "dig.stone"],
    ["andesite", "dig.stone"],
    ["blackstone", "dig.stone"],
    ["deepslate", "place.deepslate"],
    ["tuff", "dig.stone"],
    ["polished_granite", "dig.stone"],
    ["polished_diorite", "dig.stone"],
    ["polished_andesite", "dig.stone"],
    ["polished_blackstone", "dig.stone"],
    ["polished_deepslate", "place.deepslate"],
    ["polished_tuff", "dig.stone"],
    ["smooth_basalt", "dig.stone"],

    ["oak_wood", "dig.wood"],
    ["stripped_oak_wood", "dig.wood"],
    ["spruce_wood", "dig.wood"],
    ["stripped_spruce_wood", "dig.wood"],
    ["birch_wood", "dig.wood"],
    ["stripped_birch_wood", "dig.wood"],
    ["jungle_wood", "dig.wood"],
    ["stripped_jungle_wood", "dig.wood"],
    ["acacia_wood", "dig.wood"],
    ["stripped_acacia_wood", "dig.wood"],
    ["dark_oak_wood", "dig.wood"],
    ["stripped_dark_oak_wood", "dig.wood"],
    ["mangrove_wood", "dig.wood"],
    ["stripped_mangrove_wood", "dig.wood"],
    ["cherry_wood", "dig.wood"],
    ["stripped_cherry_wood", "dig.wood"],
    ["pale_oak_wood", "dig.wood"],
    ["stripped_pale_oak_wood", "dig.wood"],
    ["crimson_hyphae", "dig.stem"],
    ["stripped_crimson_hyphae", "dig.stem"],
    ["warped_hyphae", "dig.stem"],
    ["stripped_warped_hyphae", "dig.stem"],
    ["bamboo_block", "dig.wood"],
    ["stripped_bamboo_block", "dig.wood"],

    ["snow", "dig.snow"],
    ["ice", "dig.stone"],
    ["packed_ice", "dig.stone"],
    ["blue_ice", "dig.stone"],

    ["dripstone_block", "dig.stone"],
    ["moss_block", "dig.stone"],
    ["pale_moss_block", "dig.stone"],
    ["amethyst_block", "place.amethyst_block"],
    ["calcite", "place.calcite"],
    ["obsidian", "dig.stone"],
    ["crying_obsidian", "dig.stone"],
    ["soul_sand", "dig.soul_sand"],
    ["soul_soil", "dig.soul_soil"],
    ["magma", "dig.stone"],
    ["end_stone", "dig.stone"],

    ["tube_coral_block", "dig.stone"],
    ["brain_coral_block", "dig.stone"],
    ["bubble_coral_block", "dig.stone"],
    ["fire_coral_block", "dig.stone"],
    ["horn_coral_block", "dig.stone"],
    ["dead_tube_coral_block", "dig.stone"],
    ["dead_brain_coral_block", "dig.stone"],
    ["dead_bubble_coral_block", "dig.stone"],
    ["dead_fire_coral_block", "dig.stone"],
    ["dead_horn_coral_block", "dig.stone"],

    ["sculk", "place.sculk"],

    ["azalea_leaves", "dig.azalea_leaves"],
    ["azalea_leaves_flowered", "dig.azalea_leaves"],

    ["oak_leaves", "dig.grass"],
    ["spruce_leaves", "dig.grass"],
    ["birch_leaves", "dig.grass"],
    ["jungle_leaves", "dig.grass"],
    ["acacia_leaves", "dig.grass"],
    ["dark_oak_leaves", "dig.grass"],
    ["mangrove_leaves", "dig.grass"],
    ["cherry_leaves", "dig.grass"],
    ["pale_oak_leaves", "dig.grass"],

    ["iron_ore", "dig.stone"],
    ["gold_ore", "dig.stone"],
    ["diamond_ore", "dig.stone"],
    ["lapis_ore", "dig.stone"],
    ["redstone_ore", "dig.stone"],
    ["coal_ore", "dig.stone"],
    ["copper_ore", "dig.stone"],
    ["emerald_ore", "dig.stone"],
    ["quartz_ore", "dig.stone"],
    ["nether_gold_ore", "dig.stone"],
    ["deepslate_iron_ore", "dig.deepslate"],
    ["deepslate_gold_ore", "dig.deepslate"],
    ["deepslate_diamond_ore", "dig.deepslate"],
    ["deepslate_lapis_ore", "dig.deepslate"],
    ["deepslate_redstone_ore", "dig.deepslate"],
    ["deepslate_coal_ore", "dig.deepslate"],
    ["deepslate_copper_ore", "dig.deepslate"],
    ["deepslate_emerald_ore", "dig.deepslate"],

    ["ancient_debris", "dig.ancient_debris"],

    ["grass_block", "dig.grass"],
    ["podzol", "dig.grass"],
    ["mycelium", "dig.grass"],

    ["oak_log", "dig.wood"],
    ["stripped_oak_log", "dig.wood"],

    ["spruce_log", "dig.wood"],
    ["stripped_spruce_log", "dig.wood"],

    ["birch_log", "dig.wood"],
    ["stripped_birch_log", "dig.wood"],

    ["jungle_log", "dig.wood"],
    ["stripped_jungle_log", "dig.wood"],

    ["acacia_log", "dig.wood"],
    ["stripped_acacia_log", "dig.wood"],

    ["dark_oak_log", "dig.wood"],
    ["stripped_dark_oak_log", "dig.wood"],

    ["mangrove_log", "dig.wood"],
    ["stripped_mangrove_log", "dig.wood"],

    ["cherry_log", "dig.wood"],
    ["stripped_cherry_log", "dig.wood"],

    ["pale_oak_log", "dig.wood"],
    ["stripped_pale_oak_log", "dig.wood"],

    ["crimson_stem", "dig.stem"],
    ["stripped_crimson_stem", "dig.stem"],

    ["warped_stem", "dig.stem"],
    ["stripped_warped_stem", "dig.stem"],
]);

export const breakSounds = new Map([
    ["oak_planks", "dig.wood"],
    ["spruce_planks", "dig.wood"],
    ["birch_planks", "dig.wood"],
    ["jungle_planks", "dig.wood"],
    ["acacia_planks", "dig.wood"],
    ["dark_oak_planks", "dig.wood"],
    ["mangrove_planks", "dig.wood"],
    ["cherry_planks", "dig.wood"],
    ["pale_oak_planks", "dig.wood"],
    ["bamboo_planks", "dig.wood"],
    ["bamboo_mosaic", "dig.wood"],
    ["crimson_planks", "dig.wood"],
    ["warped_planks", "dig.wood"],

    ["brick_block", "dig.stone"],
    ["stone_bricks", "dig.stone"],
    ["mossy_stone_bricks", "dig.stone"],
    ["cracked_stone_bricks", "dig.stone"],
    ["chiseled_stone_bricks", "dig.stone"],
    ["smooth_stone", "dig.stone"],
    ["end_bricks", "dig.stone"],
    ["polished_blackstone_bricks", "dig.stone"],
    ["cracked_polished_blackstone_bricks", "dig.stone"],
    ["gilded_blackstone", "dig.stone"],
    ["chiseled_polished_blackstone", "dig.stone"],
    ["deepslate_tiles", "dig.deepslate"],
    ["cracked_deepslate_tiles", "dig.deepslate"],
    ["deepslate_bricks", "dig.deepslate"],
    ["tuff_bricks", "dig.stone"],
    ["cracked_deepslate_bricks", "dig.deepslate"],
    ["chiseled_deepslate", "dig.deepslate"],

    ["cobblestone", "dig.stone"],
    ["mossy_cobblestone", "dig.stone"],
    ["cobbled_deepslate", "dig.deepslate"],

    ["smooth_sandstone", "dig.stone"],
    ["smooth_red_sandstone", "dig.stone"],

    ["coal_block", "dig.stone"],

    ["copper_block", "dig.copper"],
    ["exposed_copper", "dig.copper"],
    ["weathered_copper", "dig.copper"],
    ["oxidized_copper", "dig.copper"],
    ["cut_copper", "dig.copper"],
    ["exposed_cut_copper", "dig.copper"],
    ["weathered_cut_copper", "dig.copper"],
    ["oxidized_cut_copper", "dig.copper"],
    ["chiseled_copper", "dig.copper"],
    ["exposed_chiseled_copper", "dig.copper"],
    ["weathered_chiseled_copper", "dig.copper"],
    ["oxidized_chiseled_copper", "dig.copper"],

    ["iron_block", "break.iron"],
    ["gold_block", "use.stone"],
    ["emerald_block", "use.stone"],
    ["diamond_block", "use.stone"],
    ["lapis_block", "dig.stone"],

    ["raw_copper_block", "dig.copper"],
    ["raw_iron_block", "break.iron"],
    ["raw_gold_block", "use.stone"],

    ["quartz_block", "dig.stone"],
    ["quartz_bricks", "dig.stone"],
    ["smooth_quartz", "dig.stone"],

    ["prismarine", "dig.stone"],
    ["prismarine_bricks", "dig.stone"],
    ["dark_prismarine", "dig.stone"],

    ["honeycomb_block", "dig.cloth"],
    ["resin_block", "dig.stone"],
    ["resin_bricks", "dig.stone"],
    ["chiseled_resin_bricks", "dig.stone"],

    ["nether_brick", "dig.nether_brick"],
    ["red_nether_brick", "dig.nether_brick"],
    ["chiseled_nether_bricks", "dig.nether_brick"],
    ["cracked_nether_bricks", "dig.nether_brick"],
    ["netherite_block", "dig.netherite"],

    ["white_wool", "dig.cloth"],
    ["light_gray_wool", "dig.cloth"],
    ["gray_wool", "dig.cloth"],
    ["black_wool", "dig.cloth"],
    ["brown_wool", "dig.cloth"],
    ["red_wool", "dig.cloth"],
    ["orange_wool", "dig.cloth"],
    ["yellow_wool", "dig.cloth"],
    ["lime_wool", "dig.cloth"],
    ["green_wool", "dig.cloth"],
    ["cyan_wool", "dig.cloth"],
    ["light_blue_wool", "dig.cloth"],
    ["blue_wool", "dig.cloth"],
    ["purple_wool", "dig.cloth"],
    ["magenta_wool", "dig.cloth"],
    ["pink_wool", "dig.cloth"],

    ["white_concrete", "dig.stone"],
    ["light_gray_concrete", "dig.stone"],
    ["gray_concrete", "dig.stone"],
    ["black_concrete", "dig.stone"],
    ["brown_concrete", "dig.stone"],
    ["red_concrete", "dig.stone"],
    ["orange_concrete", "dig.stone"],
    ["yellow_concrete", "dig.stone"],
    ["lime_concrete", "dig.stone"],
    ["green_concrete", "dig.stone"],
    ["cyan_concrete", "dig.stone"],
    ["light_blue_concrete", "dig.stone"],
    ["blue_concrete", "dig.stone"],
    ["purple_concrete", "dig.stone"],
    ["magenta_concrete", "dig.stone"],
    ["pink_concrete", "dig.stone"],

    ["hardened_clay", "dig.stone"],
    ["white_terracotta", "dig.stone"],
    ["light_gray_terracotta", "dig.stone"],
    ["gray_terracotta", "dig.stone"],
    ["black_terracotta", "dig.stone"],
    ["brown_terracotta", "dig.stone"],
    ["red_terracotta", "dig.stone"],
    ["orange_terracotta", "dig.stone"],
    ["yellow_terracotta", "dig.stone"],
    ["lime_terracotta", "dig.stone"],
    ["green_terracotta", "dig.stone"],
    ["cyan_terracotta", "dig.stone"],
    ["light_blue_terracotta", "dig.stone"],
    ["blue_terracotta", "dig.stone"],
    ["purple_terracotta", "dig.stone"],
    ["magenta_terracotta", "dig.stone"],
    ["pink_terracotta", "dig.stone"],

    ["purpur_block", "dig.stone"],
    ["packed_mud", "dig.stone"],
    ["mud_bricks", "dig.stone"],

    ["glowstone", "dig.stone"],
    ["sea_lantern", "dig.stone"],
    ["redstone_block", "use.stone"],

    ["nether_wart_block", "dig.cloth"],
    ["warped_wart_block", "dig.cloth"],
    ["shroomlight", "dig.stone"],
    ["netherrack", "dig.netherrack"],
    ["soul_sand", "dig.soul_sand"],
    ["soul_soil", "dig.soul_soil"],
    ["dirt", "dig.grass"],
    ["sand", "dig.sand"],
    ["red_sand", "dig.sand"],
    ["gravel", "dig.gravel"],
    ["mud", "dig.sand"],
    ["clay", "dig.sand"],

    ["stone", "dig.stone"],
    ["granite", "dig.stone"],
    ["diorite", "dig.stone"],
    ["andesite", "dig.stone"],
    ["blackstone", "dig.stone"],
    ["deepslate", "dig.deepslate"],
    ["tuff", "dig.stone"],
    ["polished_granite", "dig.stone"],
    ["polished_diorite", "dig.stone"],
    ["polished_andesite", "dig.stone"],
    ["polished_blackstone", "dig.stone"],
    ["polished_deepslate", "dig.deepslate"],
    ["polished_tuff", "dig.stone"],
    ["smooth_basalt", "dig.stone"],

    ["oak_wood", "dig.wood"],
    ["stripped_oak_wood", "dig.wood"],
    ["spruce_wood", "dig.wood"],
    ["stripped_spruce_wood", "dig.wood"],
    ["birch_wood", "dig.wood"],
    ["stripped_birch_wood", "dig.wood"],
    ["jungle_wood", "dig.wood"],
    ["stripped_jungle_wood", "dig.wood"],
    ["acacia_wood", "dig.wood"],
    ["stripped_acacia_wood", "dig.wood"],
    ["dark_oak_wood", "dig.wood"],
    ["stripped_dark_oak_wood", "dig.wood"],
    ["mangrove_wood", "dig.wood"],
    ["stripped_mangrove_wood", "dig.wood"],
    ["cherry_wood", "dig.wood"],
    ["stripped_cherry_wood", "dig.wood"],
    ["pale_oak_wood", "dig.wood"],
    ["stripped_pale_oak_wood", "dig.wood"],
    ["crimson_hyphae", "dig.stem"],
    ["stripped_crimson_hyphae", "dig.stem"],
    ["warped_hyphae", "dig.stem"],
    ["stripped_warped_hyphae", "dig.stem"],
    ["bamboo_block", "dig.wood"],
    ["stripped_bamboo_block", "dig.wood"],

    ["snow", "dig.snow"],
    ["ice", "dig.stone"],
    ["packed_ice", "dig.stone"],
    ["blue_ice", "dig.stone"],

    ["dripstone_block", "dig.stone"],
    ["moss_block", "dig.stone"],
    ["pale_moss_block", "dig.stone"],
    ["amethyst_block", "dig.amethyst_block"],
    ["calcite", "dig.calcite"],
    ["obsidian", "dig.stone"],
    ["crying_obsidian", "dig.stone"],
    ["soul_soil", "dig.soul_soil"],
    ["magma", "dig.stone"],
    ["end_stone", "dig.stone"],

    ["tube_coral_block", "dig.stone"],
    ["brain_coral_block", "dig.stone"],
    ["bubble_coral_block", "dig.stone"],
    ["fire_coral_block", "dig.stone"],
    ["horn_coral_block", "dig.stone"],
    ["dead_tube_coral_block", "dig.stone"],
    ["dead_brain_coral_block", "dig.stone"],
    ["dead_bubble_coral_block", "dig.stone"],
    ["dead_fire_coral_block", "dig.stone"],
    ["dead_horn_coral_block", "dig.stone"],

    ["sculk", "dig.sculk"],

    ["azalea_leaves", "dig.azalea_leaves"],
    ["azalea_leaves_flowered", "dig.azalea_leaves"],

    ["oak_leaves", "dig.grass"],
    ["spruce_leaves", "dig.grass"],
    ["birch_leaves", "dig.grass"],
    ["jungle_leaves", "dig.grass"],
    ["acacia_leaves", "dig.grass"],
    ["dark_oak_leaves", "dig.grass"],
    ["mangrove_leaves", "dig.grass"],
    ["cherry_leaves", "dig.grass"],
    ["pale_oak_leaves", "dig.grass"],

    ["iron_ore", "dig.stone"],
    ["gold_ore", "dig.stone"],
    ["diamond_ore", "dig.stone"],
    ["lapis_ore", "dig.stone"],
    ["redstone_ore", "dig.stone"],
    ["coal_ore", "dig.stone"],
    ["copper_ore", "dig.stone"],
    ["emerald_ore", "dig.stone"],
    ["quartz_ore", "dig.stone"],
    ["nether_gold_ore", "dig.stone"],
    ["deepslate_iron_ore", "dig.deepslate"],
    ["deepslate_gold_ore", "dig.deepslate"],
    ["deepslate_diamond_ore", "dig.deepslate"],
    ["deepslate_lapis_ore", "dig.deepslate"],
    ["deepslate_redstone_ore", "dig.deepslate"],
    ["deepslate_coal_ore", "dig.deepslate"],
    ["deepslate_copper_ore", "dig.deepslate"],
    ["deepslate_emerald_ore", "dig.deepslate"],

    ["ancient_debris", "dig.ancient_debris"],

    ["grass_block", "dig.grass"],
    ["podzol", "dig.grass"],
    ["mycelium", "dig.grass"],
    ["oak_log", "dig.wood"],
    ["stripped_oak_log", "dig.wood"],

    ["spruce_log", "dig.wood"],
    ["stripped_spruce_log", "dig.wood"],

    ["birch_log", "dig.wood"],
    ["stripped_birch_log", "dig.wood"],

    ["jungle_log", "dig.wood"],
    ["stripped_jungle_log", "dig.wood"],

    ["acacia_log", "dig.wood"],
    ["stripped_acacia_log", "dig.wood"],

    ["dark_oak_log", "dig.wood"],
    ["stripped_dark_oak_log", "dig.wood"],

    ["mangrove_log", "dig.wood"],
    ["stripped_mangrove_log", "dig.wood"],

    ["cherry_log", "dig.wood"],
    ["stripped_cherry_log", "dig.wood"],

    ["pale_oak_log", "dig.wood"],
    ["stripped_pale_oak_log", "dig.wood"],

    ["crimson_stem", "dig.stem"],
    ["stripped_crimson_stem", "dig.stem"],

    ["warped_stem", "dig.stem"],
    ["stripped_warped_stem", "dig.stem"],
]);

export const blocksTypeIds = [
    "none",
    "oak_planks",
    "spruce_planks",
    "birch_planks",
    "jungle_planks",
    "acacia_planks",
    "dark_oak_planks",
    "mangrove_planks",
    "cherry_planks",
    "pale_oak_planks",
    "bamboo_planks",
    "bamboo_mosaic",
    "crimson_planks",
    "warped_planks",
    "brick_block",
    "stone_bricks",
    "mossy_stone_bricks",
    "cracked_stone_bricks",
    "chiseled_stone_bricks",
    "smooth_stone",
    "end_bricks",
    "polished_blackstone_bricks",
    "cracked_polished_blackstone_bricks",
    "gilded_blackstone",
    "chiseled_polished_blackstone",
    "deepslate_tiles",
    "cracked_deepslate_tiles",
    "deepslate_bricks",
    "tuff_bricks",
    "cracked_deepslate_bricks",
    "chiseled_deepslate",
    "cobblestone",
    "mossy_cobblestone",
    "cobbled_deepslate",
    "smooth_sandstone",
    "smooth_red_sandstone",
    "coal_block",
    "copper_block",
    "exposed_copper",
    "weathered_copper",
    "oxidized_copper",
    "cut_copper",
    "exposed_cut_copper",
    "weathered_cut_copper",
    "oxidized_cut_copper",
    "chiseled_copper",
    "exposed_chiseled_copper",
    "weathered_chiseled_copper",
    "oxidized_chiseled_copper",
    "iron_block",
    "gold_block",
    "emerald_block",
    "diamond_block",
    "lapis_block",
    "raw_copper_block",
    "raw_iron_block",
    "raw_gold_block",
    "quartz_block",
    "quartz_bricks",
    "smooth_quartz",
    "prismarine",
    "prismarine_bricks",
    "dark_prismarine",
    "honeycomb_block",
    "resin_block",
    "resin_bricks",
    "chiseled_resin_bricks",
    "nether_brick",
    "red_nether_brick",
    "chiseled_nether_bricks",
    "cracked_nether_bricks",
    "netherite_block",
    "white_wool",
    "light_gray_wool",
    "gray_wool",
    "black_wool",
    "brown_wool",
    "red_wool",
    "orange_wool",
    "yellow_wool",
    "lime_wool",
    "green_wool",
    "cyan_wool",
    "light_blue_wool",
    "blue_wool",
    "purple_wool",
    "magenta_wool",
    "pink_wool",
    "white_concrete",
    "light_gray_concrete",
    "gray_concrete",
    "black_concrete",
    "brown_concrete",
    "red_concrete",
    "orange_concrete",
    "yellow_concrete",
    "lime_concrete",
    "green_concrete",
    "cyan_concrete",
    "light_blue_concrete",
    "blue_concrete",
    "purple_concrete",
    "magenta_concrete",
    "pink_concrete",
    "hardened_clay",
    "white_terracotta",
    "light_gray_terracotta",
    "gray_terracotta",
    "black_terracotta",
    "brown_terracotta",
    "red_terracotta",
    "orange_terracotta",
    "yellow_terracotta",
    "lime_terracotta",
    "green_terracotta",
    "cyan_terracotta",
    "light_blue_terracotta",
    "blue_terracotta",
    "purple_terracotta",
    "magenta_terracotta",
    "pink_terracotta",
    "purpur_block",
    "packed_mud",
    "mud_bricks",
    "glowstone",
    "sea_lantern",
    "redstone_block",
    "nether_wart_block",
    "warped_wart_block",
    "shroomlight",
    "netherrack",
    "soul_soil",
    "dirt",
    "sand",
    "red_sand",
    "gravel",
    "mud",
    "clay",
    "stone",
    "granite",
    "diorite",
    "andesite",
    "blackstone",
    "deepslate",
    "tuff",
    "polished_granite",
    "polished_diorite",
    "polished_andesite",
    "polished_blackstone",
    "polished_deepslate",
    "polished_tuff",
    "smooth_basalt",
    "oak_wood",
    "stripped_oak_wood",
    "spruce_wood",
    "stripped_spruce_wood",
    "birch_wood",
    "stripped_birch_wood",
    "jungle_wood",
    "stripped_jungle_wood",
    "acacia_wood",
    "stripped_acacia_wood",
    "dark_oak_wood",
    "stripped_dark_oak_wood",
    "mangrove_wood",
    "stripped_mangrove_wood",
    "cherry_wood",
    "stripped_cherry_wood",
    "pale_oak_wood",
    "stripped_pale_oak_wood",
    "crimson_hyphae",
    "stripped_crimson_hyphae",
    "warped_hyphae",
    "stripped_warped_hyphae",
    "bamboo_block",
    "stripped_bamboo_block",
    "snow",
    "ice",
    "packed_ice",
    "blue_ice",
    "dripstone_block",
    "moss_block",
    "pale_moss_block",
    "amethyst_block",
    "calcite",
    "obsidian",
    "crying_obsidian",
    "soul_sand",
    "magma",
    "end_stone",
    "tube_coral_block",
    "brain_coral_block",
    "bubble_coral_block",
    "fire_coral_block",
    "horn_coral_block",
    "dead_tube_coral_block",
    "dead_brain_coral_block",
    "dead_bubble_coral_block",
    "dead_fire_coral_block",
    "dead_horn_coral_block",
    "sculk",

    "azalea_leaves",
    "azalea_leaves_flowered",
    "oak_leaves",
    "spruce_leaves",
    "birch_leaves",
    "jungle_leaves",
    "acacia_leaves",
    "dark_oak_leaves",
    "mangrove_leaves",
    "cherry_leaves",
    "pale_oak_leaves",

    "iron_ore",
    "gold_ore",
    "diamond_ore",
    "lapis_ore",
    "redstone_ore",
    "coal_ore",
    "copper_ore",
    "emerald_ore",
    "quartz_ore",
    "nether_gold_ore",
    "deepslate_iron_ore",
    "deepslate_gold_ore",
    "deepslate_diamond_ore",
    "deepslate_lapis_ore",
    "deepslate_redstone_ore",
    "deepslate_coal_ore",
    "deepslate_copper_ore",
    "deepslate_emerald_ore",

    "ancient_debris",

    "grass_block",
    "podzol",
    "mycelium",

    "oak_log",
    "stripped_oak_log",
    "spruce_log",
    "stripped_spruce_log",
    "birch_log",
    "stripped_birch_log",
    "jungle_log",
    "stripped_jungle_log",
    "acacia_log",
    "stripped_acacia_log",
    "dark_oak_log",
    "stripped_dark_oak_log",
    "mangrove_log",
    "stripped_mangrove_log",
    "cherry_log",
    "stripped_cherry_log",
    "pale_oak_log",
    "stripped_pale_oak_log",
    "crimson_stem",
    "stripped_crimson_stem",
    "warped_stem",
    "stripped_warped_stem"
];

export const unBuildableBlocks = [
    'minecraft:torch'
];

export const destructionParticles = {
    'undefined': {
        hardness: 0,
        colors: [
            { red: 1, green: 0, blue: 1, alpha: 1 },
            { red: 0, green: 0, blue: 0, alpha: 1 }
        ]
    },
    'minecraft:air': {
        hardness: 0,
        colors: [
            { red: 0.9, green: 0.9, blue: 1, alpha: 0.5 }
        ]
    },
    'minecraft:acacia_door': {
        hardness: 3,
        colors: [
            { red: 0.796, green: 0.467, blue: 0.31, alpha: 1 },
            { red: 0.773, green: 0.447, blue: 0.29, alpha: 1 },
            { red: 0.51, green: 0.286, blue: 0.165, alpha: 1 }
        ]
    },
    'minecraft:activator_rail': {
        hardness: 0.7,
        colors: [
            { red: 0.384, green: 0.008, blue: 0.008, alpha: 1 },
            { red: 0.612, green: 0.612, blue: 0.612, alpha: 1 },
            { red: 0.408, green: 0.408, blue: 0.408, alpha: 1 }
        ]
    },
    'minecraft:allium': {
        hardness: 0,
        colors: [
            { red: 0.824, green: 0.651, blue: 0.965, alpha: 1 },
            { red: 0.722, green: 0.471, blue: 0.929, alpha: 1 },
            { red: 0.651, green: 0.369, blue: 0.882, alpha: 1 }
        ]
    },
    'minecraft:allow': {
        hardness: -1,
        colors: [
            { red: 0.549, green: 0.439, blue: 0.275, alpha: 1 },
            { red: 0.604, green: 0.482, blue: 0.306, alpha: 1 },
            { red: 0.502, green: 0.404, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:amethyst_block': {
        hardness: 1.5,
        colors: [
            { red: 0.478, green: 0.357, blue: 0.71, alpha: 1 },
            { red: 0.392, green: 0.278, blue: 0.62, alpha: 1 },
            { red: 0.553, green: 0.416, blue: 0.8, alpha: 1 }
        ]
    },
    'minecraft:amethyst_cluster': {
        hardness: 1.5,
        colors: [
            { red: 0.812, green: 0.627, blue: 0.953, alpha: 1 },
            { red: 0.478, green: 0.357, blue: 0.71, alpha: 1 },
            { red: 0.553, green: 0.416, blue: 0.8, alpha: 1 }
        ]
    },
    'minecraft:ancient_debris': {
        hardness: 30,
        colors: [
            { red: 0.365, green: 0.204, blue: 0.173, alpha: 1 },
            { red: 0.396, green: 0.278, blue: 0.251, alpha: 1 },
            { red: 0.29, green: 0.173, blue: 0.137, alpha: 1 }
        ]
    },
    'minecraft:andesite': {
        hardness: 1.5,
        colors: [
            { red: 0.541, green: 0.541, blue: 0.557, alpha: 1 },
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.612, green: 0.612, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:andesite_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.541, green: 0.541, blue: 0.557, alpha: 1 },
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.612, green: 0.612, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:andesite_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.541, green: 0.541, blue: 0.557, alpha: 1 },
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.612, green: 0.612, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:andesite_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.541, green: 0.541, blue: 0.557, alpha: 1 },
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.612, green: 0.612, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:anvil': {
        hardness: 5,
        colors: [
            { red: 0.239, green: 0.239, blue: 0.239, alpha: 1 },
            { red: 0.259, green: 0.259, blue: 0.259, alpha: 1 },
            { red: 0.29, green: 0.29, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:azalea': {
        hardness: 0,
        colors: [
            { red: 0.314, green: 0.412, blue: 0.173, alpha: 1 },
            { red: 0.439, green: 0.573, blue: 0.176, alpha: 1 },
            { red: 0.424, green: 0.502, blue: 0.192, alpha: 1 }
        ]
    },
    'minecraft:azure_bluet': {
        hardness: 0,
        colors: [
            { red: 0.333, green: 0.671, blue: 0.176, alpha: 1 },
            { red: 0.969, green: 0.969, blue: 0.969, alpha: 1 },
            { red: 0.839, green: 0.91, blue: 0.91, alpha: 1 }
        ]
    },
    'minecraft:bamboo': {
        hardness: 1,
        colors: [
            { red: 0.349, green: 0.565, blue: 0.012, alpha: 1 },
            { red: 0.325, green: 0.51, blue: 0.035, alpha: 1 },
            { red: 0.553, green: 0.761, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:bamboo_block': {
        hardness: 2,
        colors: [
            { red: 0.502, green: 0.565, blue: 0.22, alpha: 1 },
            { red: 0.569, green: 0.651, blue: 0.263, alpha: 1 },
            { red: 0.396, green: 0.439, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:bamboo_mosaic': {
        hardness: 2,
        colors: [
            { red: 0.784, green: 0.694, blue: 0.302, alpha: 1 },
            { red: 0.6, green: 0.529, blue: 0.255, alpha: 1 },
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:bamboo_mosaic_slab': {
        hardness: 2,
        colors: [
            { red: 0.784, green: 0.694, blue: 0.302, alpha: 1 },
            { red: 0.6, green: 0.529, blue: 0.255, alpha: 1 },
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:bamboo_mosaic_stairs': {
        hardness: 2,
        colors: [
            { red: 0.784, green: 0.694, blue: 0.302, alpha: 1 },
            { red: 0.6, green: 0.529, blue: 0.255, alpha: 1 },
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:barrel': {
        hardness: 2.5,
        colors: [
            { red: 0.545, green: 0.404, blue: 0.235, alpha: 1 },
            { red: 0.502, green: 0.369, blue: 0.212, alpha: 1 },
            { red: 0.6, green: 0.443, blue: 0.251, alpha: 1 }
        ]
    },
    'minecraft:barrier': {
        hardness: -1,
        colors: [
            { red: 0.89, green: 0, blue: 0, alpha: 1 },
            { red: 0.694, green: 0, blue: 0, alpha: 1 },
            { red: 0.745, green: 0.004, blue: 0.004, alpha: 1 }
        ]
    },
    'minecraft:basalt': {
        hardness: 1.25,
        colors: [
            { red: 0.31, green: 0.294, blue: 0.31, alpha: 1 },
            { red: 0.361, green: 0.361, blue: 0.361, alpha: 1 },
            { red: 0.227, green: 0.231, blue: 0.282, alpha: 1 }
        ]
    },
    'minecraft:beacon': {
        hardness: 3,
        colors: [
            { red: 0.169, green: 0.796, blue: 0.753, alpha: 1 },
            { red: 0.286, green: 0.835, blue: 0.8, alpha: 1 },
            { red: 0.169, green: 0.725, blue: 0.69, alpha: 1 }
        ]
    },
    'minecraft:bed': {
        hardness: 0.2,
        colors: [
            { red: 0.51, green: 0.039, blue: 0.035, alpha: 1 },
            { red: 0.549, green: 0.082, blue: 0.082, alpha: 1 },
            { red: 0.549, green: 0.082, blue: 0.086, alpha: 1 }
        ]
    },
    'minecraft:bedrock': {
        hardness: -1,
        colors: [
            { red: 0.2, green: 0.2, blue: 0.2, alpha: 1 },
            { red: 0.341, green: 0.341, blue: 0.341, alpha: 1 },
            { red: 0.592, green: 0.592, blue: 0.592, alpha: 1 }
        ]
    },
    'minecraft:bee_nest': {
        hardness: 0.3,
        colors: [
            { red: 0.851, green: 0.643, blue: 0.325, alpha: 1 },
            { red: 0.784, green: 0.525, blue: 0.267, alpha: 1 },
            { red: 0.969, green: 0.808, blue: 0.275, alpha: 1 }
        ]
    },
    'minecraft:beehive': {
        hardness: 0.6,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.541, green: 0.412, blue: 0.22, alpha: 1 }
        ]
    },
    'minecraft:bell': {
        hardness: 5,
        colors: [
            { red: 0.996, green: 0.839, blue: 0.224, alpha: 1 },
            { red: 1, green: 0.965, blue: 0.553, alpha: 1 },
            { red: 1, green: 0.925, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:big_dripleaf': {
        hardness: 0.1,
        colors: [
            { red: 0.424, green: 0.502, blue: 0.192, alpha: 1 },
            { red: 0.314, green: 0.412, blue: 0.173, alpha: 1 },
            { red: 0.259, green: 0.333, blue: 0.176, alpha: 1 }
        ]
    },
    'minecraft:birch_door': {
        hardness: 3,
        colors: [
            { red: 0.965, green: 0.949, blue: 0.871, alpha: 1 },
            { red: 0.933, green: 0.902, blue: 0.835, alpha: 1 },
            { red: 0.859, green: 0.824, blue: 0.631, alpha: 1 }
        ]
    },
    'minecraft:blackstone': {
        hardness: 1.5,
        colors: [
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 },
            { red: 0.125, green: 0.075, blue: 0.11, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:blackstone_slab': {
        hardness: 2,
        colors: [
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 },
            { red: 0.125, green: 0.075, blue: 0.11, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:blackstone_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 },
            { red: 0.125, green: 0.075, blue: 0.11, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:blackstone_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 },
            { red: 0.125, green: 0.075, blue: 0.11, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:blast_furnace': {
        hardness: 3.5,
        colors: [
            { red: 0.349, green: 0.345, blue: 0.345, alpha: 1 },
            { red: 0.286, green: 0.282, blue: 0.282, alpha: 1 },
            { red: 0.247, green: 0.243, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:blue_ice': {
        hardness: 2.8,
        colors: [
            { red: 0.424, green: 0.639, blue: 0.992, alpha: 1 },
            { red: 0.455, green: 0.671, blue: 0.996, alpha: 1 },
            { red: 0.42, green: 0.616, blue: 0.984, alpha: 1 }
        ]
    },
    'minecraft:blue_orchid': {
        hardness: 0,
        colors: [
            { red: 0.153, green: 0.663, blue: 0.957, alpha: 1 },
            { red: 0.11, green: 0.573, blue: 0.839, alpha: 1 },
            { red: 0.165, green: 0.749, blue: 0.992, alpha: 1 }
        ]
    },
    'minecraft:bone_block': {
        hardness: 2,
        colors: [
            { red: 0.914, green: 0.902, blue: 0.831, alpha: 1 },
            { red: 0.902, green: 0.886, blue: 0.824, alpha: 1 },
            { red: 0.871, green: 0.855, blue: 0.773, alpha: 1 }
        ]
    },
    'minecraft:bookshelf': {
        hardness: 1.5,
        colors: [
            { red: 0.702, green: 0.549, blue: 0.318, alpha: 1 },
            { red: 0.608, green: 0.467, blue: 0.259, alpha: 1 },
            { red: 0.569, green: 0.067, blue: 0.067, alpha: 1 }
        ]
    },
    'minecraft:border_block': {
        hardness: -1,
        colors: [
            { red: 0.835, green: 0.255, blue: 0.212, alpha: 1 },
            { red: 0.667, green: 0.212, blue: 0.176, alpha: 1 },
            { red: 0.702, green: 0.22, blue: 0.184, alpha: 1 }
        ]
    },
    'minecraft:brewing_stand': {
        hardness: 0.5,
        colors: [
            { red: 0.412, green: 0.365, blue: 0.365, alpha: 1 },
            { red: 0.455, green: 0.424, blue: 0.424, alpha: 1 },
            { red: 0.439, green: 0.392, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:brick_slab': {
        hardness: 2,
        colors: [
            { red: 0.608, green: 0.337, blue: 0.263, alpha: 1 },
            { red: 0.545, green: 0.431, blue: 0.404, alpha: 1 },
            { red: 0.635, green: 0.525, blue: 0.49, alpha: 1 }
        ]
    },
    'minecraft:brick_stairs': {
        hardness: 2,
        colors: [
            { red: 0.608, green: 0.337, blue: 0.263, alpha: 1 },
            { red: 0.545, green: 0.431, blue: 0.404, alpha: 1 },
            { red: 0.635, green: 0.525, blue: 0.49, alpha: 1 }
        ]
    },
    'minecraft:brick_wall': {
        hardness: 2,
        colors: [
            { red: 0.608, green: 0.337, blue: 0.263, alpha: 1 },
            { red: 0.545, green: 0.431, blue: 0.404, alpha: 1 },
            { red: 0.635, green: 0.525, blue: 0.49, alpha: 1 }
        ]
    },
    'minecraft:brown_mushroom': {
        hardness: 0,
        colors: [
            { red: 0.8, green: 0.6, blue: 0.471, alpha: 1 },
            { red: 0.569, green: 0.427, blue: 0.333, alpha: 1 },
            { red: 0.447, green: 0.337, blue: 0.263, alpha: 1 }
        ]
    },
    'minecraft:brown_mushroom_block': {
        hardness: 0,
        colors: [
            { red: 0.592, green: 0.447, blue: 0.318, alpha: 1 },
            { red: 0.58, green: 0.427, blue: 0.322, alpha: 1 },
            { red: 0.553, green: 0.408, blue: 0.314, alpha: 1 }
        ]
    },
    'minecraft:bubble_column': {
        hardness: 0,
        colors: [
            { red: 0.129, green: 0.71, blue: 1, alpha: 1 },
            { red: 0.467, green: 0.851, blue: 1, alpha: 1 }
        ]
    },
    'minecraft:budding_amethyst': {
        hardness: 1.5,
        colors: [
            { red: 0.478, green: 0.357, blue: 0.71, alpha: 1 },
            { red: 0.392, green: 0.278, blue: 0.62, alpha: 1 },
            { red: 0.553, green: 0.416, blue: 0.8, alpha: 1 }
        ]
    },
    'minecraft:bush': {
        hardness: 0,
        colors: [
            { red: 0.42, green: 0.431, blue: 0.42, alpha: 1 },
            { red: 0.486, green: 0.494, blue: 0.486, alpha: 1 },
            { red: 0.345, green: 0.349, blue: 0.345, alpha: 1 }
        ]
    },
    'minecraft:cactus': {
        hardness: 0.4,
        colors: [
            { red: 0.322, green: 0.49, blue: 0.149, alpha: 1 },
            { red: 0.357, green: 0.549, blue: 0.169, alpha: 1 },
            { red: 0.392, green: 0.596, blue: 0.196, alpha: 1 }
        ]
    },
    'minecraft:cactus_flower': {
        hardness: 0,
        colors: [
            { red: 0.824, green: 0.439, blue: 0.533, alpha: 1 },
            { red: 0.631, green: 0.341, blue: 0.475, alpha: 1 },
            { red: 0.973, green: 0.522, blue: 0.518, alpha: 1 }
        ]
    },
    'minecraft:cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:calcite': {
        hardness: 0.75,
        colors: [
            { red: 0.851, green: 0.859, blue: 0.843, alpha: 1 },
            { red: 0.929, green: 0.925, blue: 0.902, alpha: 1 },
            { red: 0.788, green: 0.788, blue: 0.769, alpha: 1 }
        ]
    },
    'minecraft:calibrated_sculk_sensor': {
        hardness: 1.5,
        colors: [
            { red: 0.012, green: 0.255, blue: 0.314, alpha: 1 },
            { red: 0.027, green: 0.282, blue: 0.341, alpha: 1 },
            { red: 0.329, green: 0.392, blue: 0.608, alpha: 1 }
        ]
    },
    'minecraft:camera': {
        hardness: 0,
        colors: [
            { red: 0.184, green: 0.184, blue: 0.184, alpha: 1 },
            { red: 0.094, green: 0.094, blue: 0.094, alpha: 1 },
            { red: 0.294, green: 0.294, blue: 0.294, alpha: 1 }
        ]
    },
    'minecraft:campfire': {
        hardness: 2,
        colors: [
            { red: 0.937, green: 0.804, blue: 0.337, alpha: 1 },
            { red: 0.788, green: 0.424, blue: 0.012, alpha: 1 },
            { red: 0.914, green: 0.741, blue: 0.224, alpha: 1 }
        ]
    },
    'minecraft:candle': {
        hardness: 0.1,
        colors: [
            { red: 0.902, green: 0.725, blue: 0.549, alpha: 1 },
            { red: 0.98, green: 0.855, blue: 0.639, alpha: 1 },
            { red: 0.996, green: 0.941, blue: 0.702, alpha: 1 }
        ]
    },
    'minecraft:cartography_table': {
        hardness: 2.5,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.325, green: 0.22, blue: 0.102, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:carved_pumpkin': {
        hardness: 1,
        colors: [
            { red: 0.89, green: 0.541, blue: 0.114, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.043, alpha: 1 },
            { red: 0.769, green: 0.435, blue: 0.078, alpha: 1 }
        ]
    },
    'minecraft:cauldron': {
        hardness: 2,
        colors: [
            { red: 0.31, green: 0.31, blue: 0.31, alpha: 1 },
            { red: 0.349, green: 0.345, blue: 0.345, alpha: 1 },
            { red: 0.286, green: 0.282, blue: 0.282, alpha: 1 }
        ]
    },
    'minecraft:cave_vines': {
        hardness: 0,
        colors: [
            { red: 0.314, green: 0.447, blue: 0.2, alpha: 1 },
            { red: 0.282, green: 0.38, blue: 0.141, alpha: 1 },
            { red: 0.439, green: 0.573, blue: 0.176, alpha: 1 }
        ]
    },
    'minecraft:chain': {
        hardness: 5,
        colors: [
            { red: 0.145, green: 0.173, blue: 0.239, alpha: 1 },
            { red: 0.243, green: 0.267, blue: 0.325, alpha: 1 },
            { red: 0.286, green: 0.314, blue: 0.396, alpha: 1 }
        ]
    },
    'minecraft:chain_command_block': {
        hardness: -1,
        colors: [
            { red: 0.463, green: 0.698, blue: 0.592, alpha: 1 },
            { red: 0.702, green: 0.69, blue: 0.725, alpha: 1 },
            { red: 0.373, green: 0.561, blue: 0.478, alpha: 1 }
        ]
    },
    'minecraft:chest': {
        hardness: 2.5,
        colors: [
            { red: 0.561, green: 0.412, blue: 0.114, alpha: 1 },
            { red: 0.671, green: 0.475, blue: 0.176, alpha: 1 },
            { red: 0.643, green: 0.447, blue: 0.153, alpha: 1 }
        ]
    },
    'minecraft:chiseled_bookshelf': {
        hardness: 1.5,
        colors: [
            { red: 0.588, green: 0.455, blue: 0.255, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 },
            { red: 0.761, green: 0.616, blue: 0.384, alpha: 1 }
        ]
    },
    'minecraft:chiseled_copper': {
        hardness: 3,
        colors: [
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.565, green: 0.286, blue: 0.192, alpha: 1 }
        ]
    },
    'minecraft:chiseled_deepslate': {
        hardness: 3.5,
        colors: [
            { red: 0.141, green: 0.141, blue: 0.141, alpha: 1 },
            { red: 0.294, green: 0.298, blue: 0.31, alpha: 1 },
            { red: 0.176, green: 0.176, blue: 0.176, alpha: 1 }
        ]
    },
    'minecraft:chiseled_nether_bricks': {
        hardness: 2,
        colors: [
            { red: 0.098, green: 0.051, blue: 0.063, alpha: 1 },
            { red: 0.188, green: 0.094, blue: 0.11, alpha: 1 },
            { red: 0.243, green: 0.118, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:chiseled_polished_blackstone': {
        hardness: 1.5,
        colors: [
            { red: 0.306, green: 0.294, blue: 0.329, alpha: 1 },
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:chiseled_quartz_block': {
        hardness: 0.8,
        colors: [
            { red: 0.933, green: 0.918, blue: 0.902, alpha: 1 },
            { red: 0.867, green: 0.851, blue: 0.796, alpha: 1 },
            { red: 0.886, green: 0.871, blue: 0.816, alpha: 1 }
        ]
    },
    'minecraft:chiseled_red_sandstone': {
        hardness: 0.8,
        colors: [
            { red: 0.624, green: 0.306, blue: 0.043, alpha: 1 },
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:chiseled_resin_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.702, green: 0.243, blue: 0.075, alpha: 1 },
            { red: 0.651, green: 0.212, blue: 0.098, alpha: 1 },
            { red: 0.78, green: 0.286, blue: 0.039, alpha: 1 }
        ]
    },
    'minecraft:chiseled_sandstone': {
        hardness: 0.8,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.776, green: 0.682, blue: 0.443, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 }
        ]
    },
    'minecraft:chiseled_stone_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.353, green: 0.349, blue: 0.353, alpha: 1 },
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.612, green: 0.6, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:chiseled_tuff': {
        hardness: 1.5,
        colors: [
            { red: 0.271, green: 0.29, blue: 0.259, alpha: 1 },
            { red: 0.294, green: 0.318, blue: 0.271, alpha: 1 },
            { red: 0.463, green: 0.467, blue: 0.435, alpha: 1 }
        ]
    },
    'minecraft:chiseled_tuff_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.463, green: 0.467, blue: 0.435, alpha: 1 },
            { red: 0.294, green: 0.318, blue: 0.271, alpha: 1 },
            { red: 0.322, green: 0.353, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:chorus_flower': {
        hardness: 0.4,
        colors: [
            { red: 0.357, green: 0.204, blue: 0.357, alpha: 1 },
            { red: 0.337, green: 0.18, blue: 0.337, alpha: 1 },
            { red: 0.984, green: 0.953, blue: 0.996, alpha: 1 }
        ]
    },
    'minecraft:chorus_plant': {
        hardness: 0.4,
        colors: [
            { red: 0.357, green: 0.204, blue: 0.357, alpha: 1 },
            { red: 0.337, green: 0.18, blue: 0.337, alpha: 1 },
            { red: 0.278, green: 0.129, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:clay': {
        hardness: 0.6,
        colors: [
            { red: 0.631, green: 0.655, blue: 0.694, alpha: 1 },
            { red: 0.604, green: 0.639, blue: 0.702, alpha: 1 },
            { red: 0.675, green: 0.682, blue: 0.741, alpha: 1 }
        ]
    },
    'minecraft:closed_eyeblossom': {
        hardness: 0,
        colors: [
            { red: 0.357, green: 0.322, blue: 0.318, alpha: 1 },
            { red: 0.627, green: 0.584, blue: 0.604, alpha: 1 },
            { red: 0.506, green: 0.447, blue: 0.475, alpha: 1 }
        ]
    },
    'minecraft:coal_block': {
        hardness: 5,
        colors: [
            { red: 0.082, green: 0.082, blue: 0.082, alpha: 1 },
            { red: 0.02, green: 0.02, blue: 0.02, alpha: 1 },
            { red: 0.051, green: 0.051, blue: 0.051, alpha: 1 }
        ]
    },
    'minecraft:coal_ore': {
        hardness: 3,
        colors: [
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.361, green: 0.361, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:coarse_dirt': {
        hardness: 0.5,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.725, green: 0.522, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:cobbled_deepslate': {
        hardness: 3.5,
        colors: [
            { red: 0.29, green: 0.29, blue: 0.31, alpha: 1 },
            { red: 0.247, green: 0.247, blue: 0.271, alpha: 1 },
            { red: 0.208, green: 0.208, blue: 0.224, alpha: 1 }
        ]
    },
    'minecraft:cobbled_deepslate_slab': {
        hardness: 3.5,
        colors: [
            { red: 0.29, green: 0.29, blue: 0.31, alpha: 1 },
            { red: 0.247, green: 0.247, blue: 0.271, alpha: 1 },
            { red: 0.208, green: 0.208, blue: 0.224, alpha: 1 }
        ]
    },
    'minecraft:cobbled_deepslate_stairs': {
        hardness: 3.5,
        colors: [
            { red: 0.29, green: 0.29, blue: 0.31, alpha: 1 },
            { red: 0.247, green: 0.247, blue: 0.271, alpha: 1 },
            { red: 0.208, green: 0.208, blue: 0.224, alpha: 1 }
        ]
    },
    'minecraft:cobbled_deepslate_wall': {
        hardness: 3.5,
        colors: [
            { red: 0.29, green: 0.29, blue: 0.31, alpha: 1 },
            { red: 0.247, green: 0.247, blue: 0.271, alpha: 1 },
            { red: 0.208, green: 0.208, blue: 0.224, alpha: 1 }
        ]
    },
    'minecraft:cobblestone': {
        hardness: 2,
        colors: [
            { red: 0.533, green: 0.529, blue: 0.533, alpha: 1 },
            { red: 0.38, green: 0.38, blue: 0.38, alpha: 1 },
            { red: 0.431, green: 0.427, blue: 0.427, alpha: 1 }
        ]
    },
    'minecraft:cobblestone_slab': {
        hardness: 2,
        colors: [
            { red: 0.533, green: 0.529, blue: 0.533, alpha: 1 },
            { red: 0.38, green: 0.38, blue: 0.38, alpha: 1 },
            { red: 0.431, green: 0.427, blue: 0.427, alpha: 1 }
        ]
    },
    'minecraft:cobblestone_wall': {
        hardness: 2,
        colors: [
            { red: 0.533, green: 0.529, blue: 0.533, alpha: 1 },
            { red: 0.38, green: 0.38, blue: 0.38, alpha: 1 },
            { red: 0.431, green: 0.427, blue: 0.427, alpha: 1 }
        ]
    },
    'minecraft:cocoa': {
        hardness: 0.2,
        colors: [
            { red: 0.467, green: 0.451, blue: 0.208, alpha: 1 },
            { red: 0.431, green: 0.443, blue: 0.208, alpha: 1 },
            { red: 0.404, green: 0.392, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:command_block': {
        hardness: -1,
        colors: [
            { red: 0.78, green: 0.494, blue: 0.31, alpha: 1 },
            { red: 0.702, green: 0.69, blue: 0.725, alpha: 1 },
            { red: 0.651, green: 0.376, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:composter': {
        hardness: 0.6,
        colors: [
            { red: 0.529, green: 0.345, blue: 0.18, alpha: 1 },
            { red: 0.318, green: 0.169, blue: 0.039, alpha: 1 },
            { red: 0.471, green: 0.286, blue: 0.122, alpha: 1 }
        ]
    },
    'minecraft:compound_creator': { hardness: 2.5 },
    'minecraft:conduit': {
        hardness: 3,
        colors: [
            { red: 0.502, green: 0.447, blue: 0.322, alpha: 1 },
            { red: 0.729, green: 0.678, blue: 0.588, alpha: 1 },
            { red: 0.639, green: 0.6, blue: 0.522, alpha: 1 }
        ]
    },
    'minecraft:copper_block': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:copper_bulb': {
        hardness: 3,
        colors: [
            { red: 0.373, green: 0.2, blue: 0.082, alpha: 1 },
            { red: 0.451, green: 0.255, blue: 0.122, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 }
        ]
    },
    'minecraft:copper_door': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 }
        ]
    },
    'minecraft:copper_grate': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 }
        ]
    },
    'minecraft:copper_ore': {
        hardness: 3,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 }
        ]
    },
    'minecraft:copper_trapdoor': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.604, green: 0.314, blue: 0.22, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:cornflower': {
        hardness: 0,
        colors: [
            { red: 0.341, green: 0.549, blue: 0.302, alpha: 1 },
            { red: 0.275, green: 0.416, blue: 0.922, alpha: 1 },
            { red: 0.447, green: 0.561, blue: 0.945, alpha: 1 }
        ]
    },
    'minecraft:cracked_deepslate_bricks': {
        hardness: 3.5,
        colors: [
            { red: 0.22, green: 0.216, blue: 0.216, alpha: 1 },
            { red: 0.345, green: 0.345, blue: 0.345, alpha: 1 },
            { red: 0.141, green: 0.141, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:cracked_deepslate_tiles': {
        hardness: 3.5,
        colors: [
            { red: 0.176, green: 0.176, blue: 0.176, alpha: 1 },
            { red: 0.141, green: 0.141, blue: 0.141, alpha: 1 },
            { red: 0.22, green: 0.216, blue: 0.216, alpha: 1 }
        ]
    },
    'minecraft:cracked_nether_bricks': {
        hardness: 2,
        colors: [
            { red: 0.098, green: 0.051, blue: 0.063, alpha: 1 },
            { red: 0.188, green: 0.094, blue: 0.11, alpha: 1 },
            { red: 0.129, green: 0.067, blue: 0.078, alpha: 1 }
        ]
    },
    'minecraft:cracked_polished_blackstone_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.137, green: 0.086, blue: 0.122, alpha: 1 },
            { red: 0.086, green: 0.059, blue: 0.063, alpha: 1 }
        ]
    },
    'minecraft:cracked_stone_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.388, green: 0.388, blue: 0.388, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:crafter': {
        hardness: 1.5,
        colors: [
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 },
            { red: 0.631, green: 0.631, blue: 0.631, alpha: 1 }
        ]
    },
    'minecraft:crafting_table': {
        hardness: 2.5,
        colors: [
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.098, green: 0.078, blue: 0.047, alpha: 1 }
        ]
    },
    'minecraft:creaking_heart': {
        hardness: 10,
        colors: [
            { red: 0.431, green: 0.392, blue: 0.384, alpha: 1 },
            { red: 0.22, green: 0.169, blue: 0.149, alpha: 1 },
            { red: 0.275, green: 0.208, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:creeper_head': {
        hardness: 1,
        colors: [
            { red: 0.502, green: 0.796, blue: 0.459, alpha: 1 },
            { red: 0.443, green: 0.796, blue: 0.384, alpha: 1 },
            { red: 0.506, green: 0.722, blue: 0.478, alpha: 1 }
        ]
    },
    'minecraft:crimson_door': {
        hardness: 3,
        colors: [
            { red: 0.525, green: 0.243, blue: 0.353, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 },
            { red: 0.573, green: 0.255, blue: 0.376, alpha: 1 }
        ]
    },
    'minecraft:crimson_fungus': {
        hardness: 0,
        colors: [
            { red: 0.322, green: 0.094, blue: 0.063, alpha: 1 },
            { red: 0.451, green: 0.016, blue: 0.031, alpha: 1 },
            { red: 0.773, green: 0.204, blue: 0.224, alpha: 1 }
        ]
    },
    'minecraft:crimson_nylium': {
        hardness: 0.4,
        colors: [
            { red: 0.447, green: 0.196, blue: 0.196, alpha: 1 },
            { red: 0.396, green: 0.157, blue: 0.157, alpha: 1 },
            { red: 0.353, green: 0, blue: 0, alpha: 1 }
        ]
    },
    'minecraft:crimson_roots': {
        hardness: 0,
        colors: [
            { red: 0.573, green: 0.024, blue: 0.212, alpha: 1 },
            { red: 0.4, green: 0.024, blue: 0.153, alpha: 1 },
            { red: 0.678, green: 0.063, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:crying_obsidian': {
        hardness: 50,
        colors: [
            { red: 0.024, green: 0.012, blue: 0.043, alpha: 1 },
            { red: 0.063, green: 0.047, blue: 0.11, alpha: 1 },
            { red: 0, green: 0, blue: 0.004, alpha: 1 }
        ]
    },
    'minecraft:cut_copper': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:cut_copper_stairs': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:cut_red_sandstone': {
        hardness: 0.8,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 },
            { red: 0.824, green: 0.459, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:cut_red_sandstone_slab': {
        hardness: 2,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 },
            { red: 0.824, green: 0.459, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:cut_sandstone': {
        hardness: 0.8,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 },
            { red: 0.906, green: 0.894, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:cut_sandstone_slab': {
        hardness: 2,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 },
            { red: 0.906, green: 0.894, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:dandelion': {
        hardness: 0,
        colors: [
            { red: 1, green: 0.925, blue: 0.31, alpha: 1 },
            { red: 0.09, green: 0.486, blue: 0.016, alpha: 1 },
            { red: 0.29, green: 0.561, blue: 0.157, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_door': {
        hardness: 3,
        colors: [
            { red: 0.286, green: 0.192, blue: 0.086, alpha: 1 },
            { red: 0.325, green: 0.212, blue: 0.102, alpha: 1 },
            { red: 0.353, green: 0.259, blue: 0.173, alpha: 1 }
        ]
    },
    'minecraft:dark_prismarine': {
        hardness: 1.5,
        colors: [
            { red: 0.192, green: 0.314, blue: 0.255, alpha: 1 },
            { red: 0.153, green: 0.243, blue: 0.212, alpha: 1 },
            { red: 0.247, green: 0.427, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:dark_prismarine_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.192, green: 0.314, blue: 0.255, alpha: 1 },
            { red: 0.153, green: 0.243, blue: 0.212, alpha: 1 },
            { red: 0.247, green: 0.427, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:dark_prismarine_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.192, green: 0.314, blue: 0.255, alpha: 1 },
            { red: 0.153, green: 0.243, blue: 0.212, alpha: 1 },
            { red: 0.247, green: 0.427, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:daylight_detector': {
        hardness: 0.2,
        colors: [
            { red: 0.235, green: 0.2, blue: 0.133, alpha: 1 },
            { red: 0.2, green: 0.169, blue: 0.106, alpha: 1 },
            { red: 0.337, green: 0.271, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:decorated_pot': {
        hardness: 0,
        colors: [
            { red: 0.49, green: 0.275, blue: 0.224, alpha: 1 },
            { red: 0.514, green: 0.286, blue: 0.231, alpha: 1 },
            { red: 0.459, green: 0.259, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:deepslate': {
        hardness: 3,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 },
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:deepslate_brick_slab': {
        hardness: 3.5,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 },
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:deepslate_brick_stairs': {
        hardness: 3.5,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 },
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:deepslate_brick_wall': {
        hardness: 3.5,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 },
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:deepslate_bricks': {
        hardness: 3.5,
        colors: [
            { red: 0.345, green: 0.345, blue: 0.345, alpha: 1 },
            { red: 0.22, green: 0.216, blue: 0.216, alpha: 1 },
            { red: 0.255, green: 0.255, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:deepslate_coal_ore': {
        hardness: 4.5,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 }
        ]
    },
    'minecraft:deepslate_copper_ore': {
        hardness: 4.5,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 },
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:deepslate_diamond_ore': {
        hardness: 4.5,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 }
        ]
    },
    'minecraft:deepslate_emerald_ore': {
        hardness: 4.5,
        colors: [
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 },
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 }
        ]
    },
    'minecraft:deepslate_gold_ore': {
        hardness: 4.5,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.475, green: 0.475, blue: 0.475, alpha: 1 },
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:deepslate_iron_ore': {
        hardness: 4.5,
        colors: [
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 },
            { red: 0.475, green: 0.475, blue: 0.475, alpha: 1 },
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:deepslate_redstone_ore': {
        hardness: 4.5,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 }
        ]
    },
    'minecraft:deepslate_tile_slab': {
        hardness: 3.5,
        colors: [
            { red: 0.176, green: 0.176, blue: 0.176, alpha: 1 },
            { red: 0.22, green: 0.216, blue: 0.216, alpha: 1 },
            { red: 0.255, green: 0.255, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:deepslate_tile_stairs': {
        hardness: 3.5,
        colors: [
            { red: 0.176, green: 0.176, blue: 0.176, alpha: 1 },
            { red: 0.22, green: 0.216, blue: 0.216, alpha: 1 },
            { red: 0.255, green: 0.255, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:deepslate_tile_wall': {
        hardness: 3.5,
        colors: [
            { red: 0.176, green: 0.176, blue: 0.176, alpha: 1 },
            { red: 0.22, green: 0.216, blue: 0.216, alpha: 1 },
            { red: 0.255, green: 0.255, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:deepslate_tiles': {
        hardness: 3.5,
        colors: [
            { red: 0.176, green: 0.176, blue: 0.176, alpha: 1 },
            { red: 0.22, green: 0.216, blue: 0.216, alpha: 1 },
            { red: 0.255, green: 0.255, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:deny': {
        hardness: -1,
        colors: [
            { red: 0.416, green: 0.416, blue: 0.416, alpha: 1 },
            { red: 0.443, green: 0.443, blue: 0.443, alpha: 1 },
            { red: 0.478, green: 0.478, blue: 0.478, alpha: 1 }
        ]
    },
    'minecraft:deprecated_purpur_block_2': {
        hardness: 1.5,
        colors: [
            { red: 0.698, green: 0.525, blue: 0.698, alpha: 1 },
            { red: 0.675, green: 0.482, blue: 0.675, alpha: 1 },
            { red: 0.643, green: 0.447, blue: 0.639, alpha: 1 }
        ]
    },
    'minecraft:detector_rail': {
        hardness: 0.7,
        colors: [
            { red: 0.612, green: 0.612, blue: 0.612, alpha: 1 },
            { red: 0.408, green: 0.408, blue: 0.408, alpha: 1 },
            { red: 0.529, green: 0.427, blue: 0.271, alpha: 1 }
        ]
    },
    'minecraft:diamond_block': {
        hardness: 5,
        colors: [
            { red: 0.396, green: 0.961, blue: 0.89, alpha: 1 },
            { red: 0.294, green: 0.929, blue: 0.902, alpha: 1 },
            { red: 0.62, green: 0.996, blue: 0.922, alpha: 1 }
        ]
    },
    'minecraft:diamond_ore': {
        hardness: 3,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 }
        ]
    },
    'minecraft:diorite': {
        hardness: 1.5,
        colors: [
            { red: 0.914, green: 0.914, blue: 0.914, alpha: 1 },
            { red: 0.643, green: 0.635, blue: 0.635, alpha: 1 },
            { red: 0.745, green: 0.749, blue: 0.757, alpha: 1 }
        ]
    },
    'minecraft:diorite_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.914, green: 0.914, blue: 0.914, alpha: 1 },
            { red: 0.643, green: 0.635, blue: 0.635, alpha: 1 },
            { red: 0.745, green: 0.749, blue: 0.757, alpha: 1 }
        ]
    },
    'minecraft:diorite_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.914, green: 0.914, blue: 0.914, alpha: 1 },
            { red: 0.643, green: 0.635, blue: 0.635, alpha: 1 },
            { red: 0.745, green: 0.749, blue: 0.757, alpha: 1 }
        ]
    },
    'minecraft:diorite_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.914, green: 0.914, blue: 0.914, alpha: 1 },
            { red: 0.643, green: 0.635, blue: 0.635, alpha: 1 },
            { red: 0.745, green: 0.749, blue: 0.757, alpha: 1 }
        ]
    },
    'minecraft:dirt': {
        hardness: 0.5,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.725, green: 0.522, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:dispenser': {
        hardness: 3.5,
        colors: [
            { red: 0.467, green: 0.467, blue: 0.467, alpha: 1 },
            { red: 0.408, green: 0.408, blue: 0.408, alpha: 1 },
            { red: 0.314, green: 0.306, blue: 0.306, alpha: 1 }
        ]
    },
    'minecraft:dragon_egg': {
        hardness: 3,
        colors: [
            { red: 0.031, green: 0.031, blue: 0.047, alpha: 1 },
            { red: 0.063, green: 0.063, blue: 0.063, alpha: 1 },
            { red: 0.176, green: 0.004, blue: 0.2, alpha: 1 }
        ]
    },
    'minecraft:dragon_head': {
        hardness: 1,
        colors: [
            { red: 0.031, green: 0.031, blue: 0.047, alpha: 1 },
            { red: 0.063, green: 0.063, blue: 0.063, alpha: 1 },
            { red: 0.176, green: 0.004, blue: 0.2, alpha: 1 }
        ]
    },
    'minecraft:dried_kelp_block': {
        hardness: 0.5,
        colors: [
            { red: 0.137, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.125, green: 0.165, blue: 0.086, alpha: 1 },
            { red: 0.075, green: 0.129, blue: 0.075, alpha: 1 }
        ]
    },
    'minecraft:dripstone_block': {
        hardness: 1.5,
        colors: [
            { red: 0.573, green: 0.475, blue: 0.396, alpha: 1 },
            { red: 0.514, green: 0.388, blue: 0.337, alpha: 1 },
            { red: 0.451, green: 0.329, blue: 0.314, alpha: 1 }
        ]
    },
    'minecraft:dropper': {
        hardness: 3.5,
        colors: [
            { red: 0.314, green: 0.306, blue: 0.306, alpha: 1 },
            { red: 0.408, green: 0.408, blue: 0.408, alpha: 1 },
            { red: 0.569, green: 0.569, blue: 0.569, alpha: 1 }
        ]
    },
    'minecraft:emerald_block': {
        hardness: 5,
        colors: [
            { red: 0.09, green: 0.773, blue: 0.267, alpha: 1 },
            { red: 0.102, green: 0.682, blue: 0.208, alpha: 1 },
            { red: 0.09, green: 0.867, blue: 0.384, alpha: 1 }
        ]
    },
    'minecraft:emerald_ore': {
        hardness: 3,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 }
        ]
    },
    'minecraft:enchanting_table': {
        hardness: 5,
        colors: [
            { red: 0.063, green: 0.047, blue: 0.11, alpha: 1 },
            { red: 0.024, green: 0.012, blue: 0.043, alpha: 1 },
            { red: 0, green: 0, blue: 0.004, alpha: 1 }
        ]
    },
    'minecraft:end_gateway': {
        hardness: -1,
        colors: [
            { red: 0.071, green: 0.071, blue: 0.098, alpha: 1 },
            { red: 0.075, green: 0.075, blue: 0.075, alpha: 1 },
            { red: 0.008, green: 0.031, blue: 0.067, alpha: 1 }
        ]
    },
    'minecraft:end_portal': {
        hardness: -1,
        colors: [
            { red: 0.008, green: 0.031, blue: 0.067, alpha: 1 },
            { red: 0.031, green: 0.078, blue: 0.098, alpha: 1 },
            { red: 0.008, green: 0.016, blue: 0.027, alpha: 1 }
        ]
    },
    'minecraft:end_portal_frame': {
        hardness: -1,
        colors: [
            { red: 0.835, green: 0.855, blue: 0.58, alpha: 1 },
            { red: 0.075, green: 0.18, blue: 0.216, alpha: 1 },
            { red: 0.871, green: 0.902, blue: 0.643, alpha: 1 }
        ]
    },
    'minecraft:end_rod': {
        hardness: 0,
        colors: [
            { red: 0.541, green: 0.514, blue: 0.49, alpha: 1 },
            { red: 0.965, green: 0.886, blue: 0.804, alpha: 1 },
            { red: 1, green: 0.965, blue: 0.902, alpha: 1 }
        ]
    },
    'minecraft:end_stone': {
        hardness: 3,
        colors: [
            { red: 0.835, green: 0.855, blue: 0.58, alpha: 1 },
            { red: 0.933, green: 0.965, blue: 0.706, alpha: 1 },
            { red: 0.871, green: 0.902, blue: 0.643, alpha: 1 }
        ]
    },
    'minecraft:end_stone_brick_slab': {
        hardness: 3,
        colors: [
            { red: 0.91, green: 0.957, blue: 0.698, alpha: 1 },
            { red: 0.867, green: 0.894, blue: 0.647, alpha: 1 },
            { red: 0.839, green: 0.839, blue: 0.584, alpha: 1 }
        ]
    },
    'minecraft:end_stone_brick_wall': {
        hardness: 3,
        colors: [
            { red: 0.91, green: 0.957, blue: 0.698, alpha: 1 },
            { red: 0.867, green: 0.894, blue: 0.647, alpha: 1 },
            { red: 0.839, green: 0.839, blue: 0.584, alpha: 1 }
        ]
    },
    'minecraft:ender_chest': {
        hardness: 22.5,
        colors: [
            { red: 0.039, green: 0.098, blue: 0.125, alpha: 1 },
            { red: 0.008, green: 0.055, blue: 0.078, alpha: 1 },
            { red: 0.004, green: 0.047, blue: 0.067, alpha: 1 }
        ]
    },
    'minecraft:farmland': {
        hardness: 0.6,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.725, green: 0.522, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:fern': {
        hardness: 0,
        colors: [
            { red: 0.263, green: 0.4, blue: 0.141, alpha: 1 },
            { red: 0.216, green: 0.329, blue: 0.118, alpha: 1 },
            { red: 0.314, green: 0.475, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:fire': {
        hardness: 0,
        colors: [
            { red: 1, green: 1, blue: 1, alpha: 1 },
            { red: 0.733, green: 0.318, blue: 0, alpha: 1 },
            { red: 0.71, green: 0.275, blue: 0, alpha: 1 }
        ]
    },
    'minecraft:firefly_bush': {
        hardness: 0,
        colors: [
            { red: 0.271, green: 0.286, blue: 0.149, alpha: 1 },
            { red: 0.212, green: 0.231, blue: 0.118, alpha: 1 },
            { red: 0.459, green: 0.424, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:fletching_table': {
        hardness: 2.5,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.894, green: 0.804, blue: 0.557, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 }
        ]
    },
    'minecraft:flower_pot': {
        hardness: 0,
        colors: [
            { red: 0.537, green: 0.298, blue: 0.231, alpha: 1 },
            { red: 0.514, green: 0.286, blue: 0.224, alpha: 1 },
            { red: 0.475, green: 0.263, blue: 0.204, alpha: 1 }
        ]
    },
    'minecraft:flowering_azalea': {
        hardness: 0,
        colors: [
            { red: 0.314, green: 0.412, blue: 0.173, alpha: 1 },
            { red: 0.439, green: 0.573, blue: 0.176, alpha: 1 },
            { red: 0.392, green: 0.447, blue: 0.2, alpha: 1 }
        ]
    },
    'minecraft:flowing_water': {
        hardness: 100,
        colors: [
            { red: 0.447, green: 0.525, blue: 1, alpha: 1 },
            { red: 0.439, green: 0.514, blue: 1, alpha: 1 },
            { red: 0.443, green: 0.518, blue: 1, alpha: 1 }
        ]
    },
    'minecraft:frosted_ice': {
        hardness: 0.5,
        colors: [
            { red: 0.502, green: 0.678, blue: 0.984, alpha: 1 },
            { red: 0.573, green: 0.725, blue: 0.996, alpha: 1 },
            { red: 0.631, green: 0.765, blue: 1, alpha: 1 }
        ]
    },
    'minecraft:furnace': {
        hardness: 3.5,
        colors: [
            { red: 0.314, green: 0.306, blue: 0.306, alpha: 1 },
            { red: 0.408, green: 0.408, blue: 0.408, alpha: 1 },
            { red: 0.522, green: 0.522, blue: 0.522, alpha: 1 }
        ]
    },
    'minecraft:gilded_blackstone': {
        hardness: 1.5,
        colors: [
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.125, green: 0.075, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:glass': {
        hardness: 0.3,
        colors: [
            { red: 0.816, green: 0.918, blue: 0.914, alpha: 1 },
            { red: 0.545, green: 0.757, blue: 0.804, alpha: 1 },
            { red: 0.659, green: 0.816, blue: 0.851, alpha: 1 }
        ]
    },
    'minecraft:glass_pane': {
        hardness: 0.3,
        colors: [
            { red: 0.816, green: 0.918, blue: 0.914, alpha: 1 },
            { red: 0.545, green: 0.757, blue: 0.804, alpha: 1 },
            { red: 0.659, green: 0.816, blue: 0.851, alpha: 1 }
        ]
    },
    'minecraft:glow_lichen': {
        hardness: 0.2,
        colors: [
            { red: 0.431, green: 0.494, blue: 0.471, alpha: 1 },
            { red: 0.443, green: 0.525, blue: 0.494, alpha: 1 },
            { red: 0.388, green: 0.459, blue: 0.431, alpha: 1 }
        ]
    },
    'minecraft:glowstone': {
        hardness: 0.3,
        colors: [
            { red: 0.435, green: 0.271, blue: 0.133, alpha: 1 },
            { red: 0.8, green: 0.525, blue: 0.329, alpha: 1 },
            { red: 0.984, green: 0.855, blue: 0.455, alpha: 1 }
        ]
    },
    'minecraft:gold_block': {
        hardness: 3,
        colors: [
            { red: 1, green: 0.847, blue: 0.243, alpha: 1 },
            { red: 0.961, green: 0.8, blue: 0.153, alpha: 1 },
            { red: 1, green: 0.925, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:gold_ore': {
        hardness: 3,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 }
        ]
    },
    'minecraft:granite': {
        hardness: 1.5,
        colors: [
            { red: 0.624, green: 0.42, blue: 0.345, alpha: 1 },
            { red: 0.498, green: 0.337, blue: 0.275, alpha: 1 },
            { red: 0.663, green: 0.467, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:granite_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.624, green: 0.42, blue: 0.345, alpha: 1 },
            { red: 0.498, green: 0.337, blue: 0.275, alpha: 1 },
            { red: 0.663, green: 0.467, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:granite_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.624, green: 0.42, blue: 0.345, alpha: 1 },
            { red: 0.498, green: 0.337, blue: 0.275, alpha: 1 },
            { red: 0.663, green: 0.467, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:granite_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.624, green: 0.42, blue: 0.345, alpha: 1 },
            { red: 0.498, green: 0.337, blue: 0.275, alpha: 1 },
            { red: 0.663, green: 0.467, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:grass_block': {
        hardness: 0.6,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.725, green: 0.522, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:gravel': {
        hardness: 0.6,
        colors: [
            { red: 0.506, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.537, green: 0.506, blue: 0.494, alpha: 1 },
            { red: 0.447, green: 0.42, blue: 0.412, alpha: 1 }
        ]
    },
    'minecraft:grindstone': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 }
        ]
    },
    'minecraft:hanging_roots': {
        hardness: 0,
        colors: [
            { red: 0.678, green: 0.49, blue: 0.396, alpha: 1 },
            { red: 0.565, green: 0.341, blue: 0.251, alpha: 1 },
            { red: 0.733, green: 0.592, blue: 0.537, alpha: 1 }
        ]
    },
    'minecraft:hardened_clay': {
        hardness: 1.25,
        colors: [
            { red: 0.588, green: 0.365, blue: 0.263, alpha: 1 },
            { red: 0.596, green: 0.373, blue: 0.271, alpha: 1 },
            { red: 0.608, green: 0.376, blue: 0.271, alpha: 1 }
        ]
    },
    'minecraft:hay_block': {
        hardness: 0.5,
        colors: [
            { red: 0.671, green: 0.573, blue: 0.145, alpha: 1 },
            { red: 0.58, green: 0.502, blue: 0.118, alpha: 1 },
            { red: 0.541, green: 0.451, blue: 0.125, alpha: 1 }
        ]
    },
    'minecraft:heavy_core': {
        hardness: 10,
        colors: [
            { red: 0.239, green: 0.247, blue: 0.263, alpha: 1 },
            { red: 0.369, green: 0.396, blue: 0.435, alpha: 1 },
            { red: 0.306, green: 0.322, blue: 0.349, alpha: 1 }
        ]
    },
    'minecraft:heavy_weighted_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.902, green: 0.902, blue: 0.902, alpha: 1 },
            { red: 0.863, green: 0.863, blue: 0.863, alpha: 1 },
            { red: 0.757, green: 0.757, blue: 0.757, alpha: 1 }
        ]
    },
    'minecraft:honey_block': {
        hardness: 0,
        colors: [
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:honeycomb_block': {
        hardness: 0.6,
        colors: [
            { red: 0.91, green: 0.549, blue: 0.031, alpha: 1 },
            { red: 0.784, green: 0.416, blue: 0.031, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:hopper': {
        hardness: 3,
        colors: [
            { red: 0.247, green: 0.243, blue: 0.259, alpha: 1 },
            { red: 0.204, green: 0.204, blue: 0.22, alpha: 1 },
            { red: 0.286, green: 0.282, blue: 0.282, alpha: 1 }
        ]
    },
    'minecraft:ice': {
        hardness: 0.5,
        colors: [
            { red: 0.573, green: 0.725, blue: 0.996, alpha: 1 },
            { red: 0.549, green: 0.702, blue: 0.996, alpha: 1 },
            { red: 0.525, green: 0.682, blue: 0.992, alpha: 1 }
        ]
    },
    'minecraft:infested_chiseled_stone_bricks': {
        hardness: 0.75,
        colors: [
            { red: 0.353, green: 0.349, blue: 0.353, alpha: 1 },
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.612, green: 0.6, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:infested_cobblestone': {
        hardness: 1,
        colors: [
            { red: 0.533, green: 0.529, blue: 0.533, alpha: 1 },
            { red: 0.38, green: 0.38, blue: 0.38, alpha: 1 },
            { red: 0.431, green: 0.427, blue: 0.427, alpha: 1 }
        ]
    },
    'minecraft:infested_cracked_stone_bricks': {
        hardness: 0.75,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.388, green: 0.388, blue: 0.388, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:infested_deepslate': {
        hardness: 1.5,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 },
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:infested_mossy_stone_bricks': {
        hardness: 0.75,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 }
        ]
    },
    'minecraft:infested_stone': {
        hardness: 0.75,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 }
        ]
    },
    'minecraft:infested_stone_bricks': {
        hardness: 0.75,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:invisible_bedrock': {
        hardness: -1,
        colors: [
            { red: 0.51, green: 0.039, blue: 0.035, alpha: 1 },
            { red: 0.549, green: 0.082, blue: 0.082, alpha: 1 },
            { red: 0.549, green: 0.082, blue: 0.086, alpha: 1 }
        ]
    },
    'minecraft:iron_bars': {
        hardness: 5,
        colors: [
            { red: 0.447, green: 0.475, blue: 0.431, alpha: 1 },
            { red: 0.408, green: 0.408, blue: 0.408, alpha: 1 },
            { red: 0.612, green: 0.612, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:iron_block': {
        hardness: 5,
        colors: [
            { red: 0.902, green: 0.902, blue: 0.902, alpha: 1 },
            { red: 0.863, green: 0.863, blue: 0.863, alpha: 1 },
            { red: 0.757, green: 0.757, blue: 0.757, alpha: 1 }
        ]
    },
    'minecraft:iron_door': {
        hardness: 5,
        colors: [
            { red: 0.804, green: 0.792, blue: 0.792, alpha: 1 },
            { red: 0.694, green: 0.694, blue: 0.694, alpha: 1 },
            { red: 0.824, green: 0.824, blue: 0.824, alpha: 1 }
        ]
    },
    'minecraft:iron_ore': {
        hardness: 3,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 }
        ]
    },
    'minecraft:iron_trapdoor': {
        hardness: 5,
        colors: [
            { red: 0.82, green: 0.812, blue: 0.812, alpha: 1 },
            { red: 0.757, green: 0.757, blue: 0.757, alpha: 1 },
            { red: 0.839, green: 0.839, blue: 0.839, alpha: 1 }
        ]
    },
    'minecraft:jukebox': {
        hardness: 2,
        colors: [
            { red: 0.161, green: 0.157, blue: 0.125, alpha: 1 },
            { red: 0.255, green: 0.157, blue: 0.094, alpha: 1 },
            { red: 0.58, green: 0.365, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:jungle_door': {
        hardness: 3,
        colors: [
            { red: 0.725, green: 0.525, blue: 0.38, alpha: 1 },
            { red: 0.471, green: 0.329, blue: 0.216, alpha: 1 },
            { red: 0.682, green: 0.494, blue: 0.353, alpha: 1 }
        ]
    },
    'minecraft:kelp': {
        hardness: 0,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.349, green: 0.239, blue: 0.161, alpha: 1 }
        ]
    },
    'minecraft:lab_table': { hardness: 2.5 },
    'minecraft:ladder': {
        hardness: 0.4,
        colors: [
            { red: 0.404, green: 0.314, blue: 0.173, alpha: 1 },
            { red: 0.71, green: 0.553, blue: 0.314, alpha: 1 },
            { red: 0.318, green: 0.239, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:lantern': {
        hardness: 3.5,
        colors: [
            { red: 0.243, green: 0.267, blue: 0.325, alpha: 1 },
            { red: 0.286, green: 0.314, blue: 0.396, alpha: 1 },
            { red: 0.259, green: 0.29, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:lapis_block': {
        hardness: 3,
        colors: [
            { red: 0.118, green: 0.259, blue: 0.522, alpha: 1 },
            { red: 0.125, green: 0.29, blue: 0.541, alpha: 1 },
            { red: 0.11, green: 0.22, blue: 0.565, alpha: 1 }
        ]
    },
    'minecraft:lapis_ore': {
        hardness: 3,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 }
        ]
    },
    'minecraft:large_amethyst_bud': {
        hardness: 1.5,
        colors: [
            { red: 0.553, green: 0.416, blue: 0.8, alpha: 1 },
            { red: 0.392, green: 0.278, blue: 0.62, alpha: 1 },
            { red: 0.812, green: 0.627, blue: 0.953, alpha: 1 }
        ]
    },
    'minecraft:large_fern': {
        hardness: 0,
        colors: [
            { red: 0.263, green: 0.4, blue: 0.141, alpha: 1 },
            { red: 0.216, green: 0.329, blue: 0.118, alpha: 1 },
            { red: 0.314, green: 0.475, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:lava': {
        hardness: 100,
        colors: [
            { red: 0.784, green: 0.224, blue: 0.024, alpha: 1 },
            { red: 0.988, green: 0.988, blue: 0.498, alpha: 1 },
            { red: 0.886, green: 0.596, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:leaf_litter': {
        hardness: 0,
        colors: [
            { red: 0.655, green: 0.655, blue: 0.655, alpha: 1 },
            { red: 0.604, green: 0.604, blue: 0.604, alpha: 1 },
            { red: 0.49, green: 0.49, blue: 0.49, alpha: 1 }
        ]
    },
    'minecraft:lectern': {
        hardness: 2.5,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.71, green: 0.553, blue: 0.314, alpha: 1 },
            { red: 0.651, green: 0.51, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:lever': {
        hardness: 0.5,
        colors: [
            { red: 0.584, green: 0.459, blue: 0.275, alpha: 1 },
            { red: 0.427, green: 0.341, blue: 0.212, alpha: 1 },
            { red: 0.624, green: 0.498, blue: 0.314, alpha: 1 }
        ]
    },
    'minecraft:light_weighted_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.847, blue: 0.243, alpha: 1 },
            { red: 0.961, green: 0.8, blue: 0.153, alpha: 1 },
            { red: 1, green: 0.925, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:lightning_rod': {
        hardness: 3,
        colors: [
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 },
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 }
        ]
    },
    'minecraft:lilac': {
        hardness: 0,
        colors: [
            { red: 0.102, green: 0.22, blue: 0.122, alpha: 1 },
            { red: 0.125, green: 0.275, blue: 0.149, alpha: 1 },
            { red: 0.149, green: 0.353, blue: 0.145, alpha: 1 }
        ]
    },
    'minecraft:lily_of_the_valley': {
        hardness: 0,
        colors: [
            { red: 0.216, green: 0.498, blue: 0.075, alpha: 1 },
            { red: 0.314, green: 0.573, blue: 0.184, alpha: 1 },
            { red: 0.392, green: 0.694, blue: 0.196, alpha: 1 }
        ]
    },
    'minecraft:lodestone': {
        hardness: 3.5,
        colors: [
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 },
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.635, green: 0.643, blue: 0.675, alpha: 1 }
        ]
    },
    'minecraft:loom': {
        hardness: 2.5,
        colors: [
            { red: 0.518, green: 0.31, blue: 0.259, alpha: 1 },
            { red: 0.435, green: 0.259, blue: 0.216, alpha: 1 },
            { red: 0.737, green: 0.576, blue: 0.353, alpha: 1 }
        ]
    },
    'minecraft:mangrove_door': {
        hardness: 3,
        colors: [
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 },
            { red: 0.365, green: 0.11, blue: 0.118, alpha: 1 },
            { red: 0.392, green: 0.141, blue: 0.137, alpha: 1 }
        ]
    },
    'minecraft:mangrove_propagule': {
        hardness: 0,
        colors: [
            { red: 0.329, green: 0.698, blue: 0.341, alpha: 1 },
            { red: 0.31, green: 0.765, blue: 0.325, alpha: 1 },
            { red: 0.451, green: 0.776, blue: 0.463, alpha: 1 }
        ]
    },
    'minecraft:mangrove_roots': {
        hardness: 0.7,
        colors: [
            { red: 0.353, green: 0.282, blue: 0.173, alpha: 1 },
            { red: 0.306, green: 0.247, blue: 0.153, alpha: 1 },
            { red: 0.267, green: 0.208, blue: 0.133, alpha: 1 }
        ]
    },
    'minecraft:material_reducer': { hardness: 2.5 },
    'minecraft:medium_amethyst_bud': {
        hardness: 1.5,
        colors: [
            { red: 0.812, green: 0.627, blue: 0.953, alpha: 1 },
            { red: 0.392, green: 0.278, blue: 0.62, alpha: 1 },
            { red: 0.478, green: 0.357, blue: 0.71, alpha: 1 }
        ]
    },
    'minecraft:melon_block': {
        hardness: 1,
        colors: [
            { red: 0.655, green: 0.675, blue: 0.114, alpha: 1 },
            { red: 0.435, green: 0.576, blue: 0.137, alpha: 1 },
            { red: 0.322, green: 0.506, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:melon_stem': {
        hardness: 0,
        colors: [
            { red: 0.545, green: 0.553, blue: 0.545, alpha: 1 },
            { red: 0.384, green: 0.38, blue: 0.384, alpha: 1 },
            { red: 0.773, green: 0.776, blue: 0.773, alpha: 1 }
        ]
    },
    'minecraft:mob_spawner': {
        hardness: 5,
        colors: [
            { red: 0.094, green: 0.173, blue: 0.224, alpha: 1 },
            { red: 0.118, green: 0.094, blue: 0.153, alpha: 1 },
            { red: 0.165, green: 0.141, blue: 0.208, alpha: 1 }
        ]
    },
    'minecraft:moss_block': {
        hardness: 0.1,
        colors: [
            { red: 0.392, green: 0.447, blue: 0.2, alpha: 1 },
            { red: 0.286, green: 0.369, blue: 0.153, alpha: 1 },
            { red: 0.314, green: 0.412, blue: 0.173, alpha: 1 }
        ]
    },
    'minecraft:moss_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.392, green: 0.447, blue: 0.2, alpha: 1 },
            { red: 0.286, green: 0.369, blue: 0.153, alpha: 1 },
            { red: 0.314, green: 0.412, blue: 0.173, alpha: 1 }
        ]
    },
    'minecraft:mossy_cobblestone': {
        hardness: 2,
        colors: [
            { red: 0.322, green: 0.365, blue: 0.224, alpha: 1 },
            { red: 0.533, green: 0.529, blue: 0.533, alpha: 1 },
            { red: 0.384, green: 0.475, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:mossy_cobblestone_slab': {
        hardness: 2,
        colors: [
            { red: 0.322, green: 0.365, blue: 0.224, alpha: 1 },
            { red: 0.533, green: 0.529, blue: 0.533, alpha: 1 },
            { red: 0.384, green: 0.475, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:mossy_cobblestone_stairs': {
        hardness: 2,
        colors: [
            { red: 0.322, green: 0.365, blue: 0.224, alpha: 1 },
            { red: 0.533, green: 0.529, blue: 0.533, alpha: 1 },
            { red: 0.384, green: 0.475, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:mossy_cobblestone_wall': {
        hardness: 2,
        colors: [
            { red: 0.322, green: 0.365, blue: 0.224, alpha: 1 },
            { red: 0.533, green: 0.529, blue: 0.533, alpha: 1 },
            { red: 0.384, green: 0.475, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:mossy_stone_brick_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 }
        ]
    },
    'minecraft:mossy_stone_brick_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 }
        ]
    },
    'minecraft:mossy_stone_brick_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 }
        ]
    },
    'minecraft:mossy_stone_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 }
        ]
    },
    'minecraft:mud': {
        hardness: 0.5,
        colors: [
            { red: 0.2, green: 0.196, blue: 0.227, alpha: 1 },
            { red: 0.227, green: 0.22, blue: 0.239, alpha: 1 },
            { red: 0.275, green: 0.251, blue: 0.243, alpha: 1 }
        ]
    },
    'minecraft:mud_brick_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.584, green: 0.443, blue: 0.314, alpha: 1 },
            { red: 0.494, green: 0.365, blue: 0.282, alpha: 1 },
            { red: 0.616, green: 0.471, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:mud_brick_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.584, green: 0.443, blue: 0.314, alpha: 1 },
            { red: 0.494, green: 0.365, blue: 0.282, alpha: 1 },
            { red: 0.616, green: 0.471, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:mud_brick_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.584, green: 0.443, blue: 0.314, alpha: 1 },
            { red: 0.494, green: 0.365, blue: 0.282, alpha: 1 },
            { red: 0.616, green: 0.471, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:mud_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.584, green: 0.443, blue: 0.314, alpha: 1 },
            { red: 0.494, green: 0.365, blue: 0.282, alpha: 1 },
            { red: 0.616, green: 0.471, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:muddy_mangrove_roots': {
        hardness: 0.7,
        colors: [
            { red: 0.353, green: 0.282, blue: 0.173, alpha: 1 },
            { red: 0.306, green: 0.247, blue: 0.153, alpha: 1 },
            { red: 0.267, green: 0.208, blue: 0.133, alpha: 1 }
        ]
    },
    'minecraft:mycelium': {
        hardness: 0.6,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.416, green: 0.365, blue: 0.384, alpha: 1 }
        ]
    },
    'minecraft:nether_brick_fence': {
        hardness: 2,
        colors: [
            { red: 0.188, green: 0.094, blue: 0.11, alpha: 1 },
            { red: 0.098, green: 0.051, blue: 0.063, alpha: 1 },
            { red: 0.129, green: 0.067, blue: 0.078, alpha: 1 }
        ]
    },
    'minecraft:nether_brick_slab': {
        hardness: 2,
        colors: [
            { red: 0.188, green: 0.094, blue: 0.11, alpha: 1 },
            { red: 0.098, green: 0.051, blue: 0.063, alpha: 1 },
            { red: 0.129, green: 0.067, blue: 0.078, alpha: 1 }
        ]
    },
    'minecraft:nether_brick_stairs': {
        hardness: 2,
        colors: [
            { red: 0.188, green: 0.094, blue: 0.11, alpha: 1 },
            { red: 0.098, green: 0.051, blue: 0.063, alpha: 1 },
            { red: 0.129, green: 0.067, blue: 0.078, alpha: 1 }
        ]
    },
    'minecraft:nether_brick_wall': {
        hardness: 2,
        colors: [
            { red: 0.188, green: 0.094, blue: 0.11, alpha: 1 },
            { red: 0.098, green: 0.051, blue: 0.063, alpha: 1 },
            { red: 0.129, green: 0.067, blue: 0.078, alpha: 1 }
        ]
    },
    'minecraft:nether_gold_ore': {
        hardness: 3,
        colors: [
            { red: 0.396, green: 0.157, blue: 0.157, alpha: 1 },
            { red: 0.447, green: 0.196, blue: 0.196, alpha: 1 },
            { red: 0.314, green: 0.106, blue: 0.106, alpha: 1 }
        ]
    },
    'minecraft:nether_sprouts': {
        hardness: 0,
        colors: [
            { red: 0.067, green: 0.608, blue: 0.522, alpha: 1 },
            { red: 0.086, green: 0.494, blue: 0.525, alpha: 1 },
            { red: 0.078, green: 0.706, blue: 0.522, alpha: 1 }
        ]
    },
    'minecraft:nether_wart': {
        hardness: 0,
        colors: [
            { red: 0.514, green: 0.11, blue: 0.125, alpha: 1 },
            { red: 0.282, green: 0, blue: 0, alpha: 1 },
            { red: 0.643, green: 0.141, blue: 0.161, alpha: 1 }
        ]
    },
    'minecraft:nether_wart_block': {
        hardness: 1,
        colors: [
            { red: 0.482, green: 0, blue: 0, alpha: 1 },
            { red: 0.353, green: 0, blue: 0, alpha: 1 },
            { red: 0.416, green: 0.016, blue: 0, alpha: 1 }
        ]
    },
    'minecraft:netherite_block': {
        hardness: 50,
        colors: [
            { red: 0.302, green: 0.286, blue: 0.302, alpha: 1 },
            { red: 0.282, green: 0.271, blue: 0.282, alpha: 1 },
            { red: 0.235, green: 0.196, blue: 0.196, alpha: 1 }
        ]
    },
    'minecraft:netherrack': {
        hardness: 0.4,
        colors: [
            { red: 0.396, green: 0.157, blue: 0.157, alpha: 1 },
            { red: 0.447, green: 0.196, blue: 0.196, alpha: 1 },
            { red: 0.314, green: 0.106, blue: 0.106, alpha: 1 }
        ]
    },
    'minecraft:observer': {
        hardness: 3,
        colors: [
            { red: 0.275, green: 0.259, blue: 0.259, alpha: 1 },
            { red: 0.231, green: 0.231, blue: 0.231, alpha: 1 },
            { red: 0.239, green: 0.235, blue: 0.235, alpha: 1 }
        ]
    },
    'minecraft:obsidian': {
        hardness: 50,
        colors: [
            { red: 0.024, green: 0.012, blue: 0.043, alpha: 1 },
            { red: 0.063, green: 0.047, blue: 0.11, alpha: 1 },
            { red: 0, green: 0, blue: 0.004, alpha: 1 }
        ]
    },
    'minecraft:ochre_froglight': {
        hardness: 0.3,
        colors: [
            { red: 0.988, green: 0.98, blue: 0.804, alpha: 1 },
            { red: 0.996, green: 1, blue: 0.925, alpha: 1 },
            { red: 0.98, green: 0.937, blue: 0.698, alpha: 1 }
        ]
    },
    'minecraft:open_eyeblossom': {
        hardness: 0,
        colors: [
            { red: 0.357, green: 0.322, blue: 0.318, alpha: 1 },
            { red: 0.627, green: 0.584, blue: 0.604, alpha: 1 },
            { red: 0.506, green: 0.447, blue: 0.475, alpha: 1 }
        ]
    },
    'minecraft:orange_tulip': {
        hardness: 0,
        colors: [
            { red: 0.09, green: 0.486, blue: 0.016, alpha: 1 },
            { red: 0.333, green: 0.671, blue: 0.176, alpha: 1 },
            { red: 0.29, green: 0.561, blue: 0.157, alpha: 1 }
        ]
    },
    'minecraft:oxeye_daisy': {
        hardness: 0,
        colors: [
            { red: 0.969, green: 0.969, blue: 0.969, alpha: 1 },
            { red: 0.839, green: 0.91, blue: 0.91, alpha: 1 },
            { red: 0.09, green: 0.486, blue: 0.016, alpha: 1 }
        ]
    },
    'minecraft:packed_ice': {
        hardness: 0.5,
        colors: [
            { red: 0.573, green: 0.725, blue: 0.996, alpha: 1 },
            { red: 0.522, green: 0.678, blue: 0.973, alpha: 1 },
            { red: 0.486, green: 0.647, blue: 0.957, alpha: 1 }
        ]
    },
    'minecraft:packed_mud': {
        hardness: 1,
        colors: [
            { red: 0.537, green: 0.396, blue: 0.302, alpha: 1 },
            { red: 0.584, green: 0.443, blue: 0.314, alpha: 1 },
            { red: 0.608, green: 0.467, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:pale_hanging_moss': {
        hardness: 0,
        colors: [
            { red: 0.318, green: 0.333, blue: 0.318, alpha: 1 },
            { red: 0.427, green: 0.447, blue: 0.42, alpha: 1 },
            { red: 0.478, green: 0.502, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:pale_moss_block': {
        hardness: 0.1,
        colors: [
            { red: 0.349, green: 0.369, blue: 0.345, alpha: 1 },
            { red: 0.427, green: 0.447, blue: 0.42, alpha: 1 },
            { red: 0.478, green: 0.502, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:pale_moss_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.427, green: 0.447, blue: 0.42, alpha: 1 },
            { red: 0.318, green: 0.333, blue: 0.318, alpha: 1 },
            { red: 0.478, green: 0.502, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:pearlescent_froglight': {
        hardness: 0.3,
        colors: [
            { red: 0.976, green: 0.957, blue: 0.953, alpha: 1 },
            { red: 1, green: 0.996, blue: 0.992, alpha: 1 },
            { red: 0.937, green: 0.902, blue: 0.882, alpha: 1 }
        ]
    },
    'minecraft:peony': {
        hardness: 0,
        colors: [
            { red: 0.102, green: 0.22, blue: 0.122, alpha: 1 },
            { red: 0.125, green: 0.275, blue: 0.149, alpha: 1 },
            { red: 0.149, green: 0.353, blue: 0.145, alpha: 1 }
        ]
    },
    'minecraft:petrified_oak_slab': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:piglin_head': {
        hardness: 1,
        colors: [
            { red: 0.404, green: 0.212, blue: 0.133, alpha: 1 },
            { red: 0.62, green: 0.361, blue: 0.251, alpha: 1 },
            { red: 0.451, green: 0.239, blue: 0.153, alpha: 1 }
        ]
    },
    'minecraft:pink_petals': {
        hardness: 0,
        colors: [
            { red: 0.988, green: 0.796, blue: 0.906, alpha: 1 },
            { red: 0.961, green: 0.855, blue: 0.937, alpha: 1 },
            { red: 0.969, green: 0.725, blue: 0.863, alpha: 1 }
        ]
    },
    'minecraft:pink_tulip': {
        hardness: 0,
        colors: [
            { red: 0.09, green: 0.486, blue: 0.016, alpha: 1 },
            { red: 0.333, green: 0.671, blue: 0.176, alpha: 1 },
            { red: 0.29, green: 0.561, blue: 0.157, alpha: 1 }
        ]
    },
    'minecraft:piston': {
        hardness: 1.5,
        colors: [
            { red: 0.325, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.408, green: 0.408, blue: 0.408, alpha: 1 },
            { red: 0.267, green: 0.267, blue: 0.267, alpha: 1 }
        ]
    },
    'minecraft:pitcher_plant': {
        hardness: 0,
        colors: [
            { red: 0.467, green: 0.271, blue: 0.176, alpha: 1 },
            { red: 0.376, green: 0.22, blue: 0.137, alpha: 1 },
            { red: 0.286, green: 0.165, blue: 0.094, alpha: 1 }
        ]
    },
    'minecraft:player_head': {
        hardness: 1,
        colors: [
            { red: 0.024, green: 0.714, blue: 0.71, alpha: 1 },
            { red: 0.122, green: 0.561, blue: 0.541, alpha: 1 },
            { red: 0.247, green: 0.224, blue: 0.592, alpha: 1 }
        ]
    },
    'minecraft:podzol': {
        hardness: 0.5,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.725, green: 0.522, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:pointed_dripstone': {
        hardness: 1.5,
        colors: [
            { red: 0.573, green: 0.475, blue: 0.396, alpha: 1 },
            { red: 0.514, green: 0.388, blue: 0.337, alpha: 1 },
            { red: 0.451, green: 0.329, blue: 0.314, alpha: 1 }
        ]
    },
    'minecraft:polished_andesite': {
        hardness: 1.5,
        colors: [
            { red: 0.525, green: 0.533, blue: 0.529, alpha: 1 },
            { red: 0.486, green: 0.498, blue: 0.502, alpha: 1 },
            { red: 0.541, green: 0.565, blue: 0.565, alpha: 1 }
        ]
    },
    'minecraft:polished_andesite_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.525, green: 0.533, blue: 0.529, alpha: 1 },
            { red: 0.486, green: 0.498, blue: 0.502, alpha: 1 },
            { red: 0.541, green: 0.565, blue: 0.565, alpha: 1 }
        ]
    },
    'minecraft:polished_andesite_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.525, green: 0.533, blue: 0.529, alpha: 1 },
            { red: 0.486, green: 0.498, blue: 0.502, alpha: 1 },
            { red: 0.541, green: 0.565, blue: 0.565, alpha: 1 }
        ]
    },
    'minecraft:polished_basalt': {
        hardness: 1.25,
        colors: [
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.361, green: 0.361, blue: 0.361, alpha: 1 },
            { red: 0.31, green: 0.294, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone': {
        hardness: 2,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone_brick_slab': {
        hardness: 2,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone_brick_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone_brick_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone_button': {
        hardness: 0.5,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone_slab': {
        hardness: 2,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone_stairs': {
        hardness: 2,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone_wall': {
        hardness: 2,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:polished_deepslate': {
        hardness: 3.5,
        colors: [
            { red: 0.345, green: 0.345, blue: 0.345, alpha: 1 },
            { red: 0.294, green: 0.298, blue: 0.31, alpha: 1 },
            { red: 0.255, green: 0.255, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:polished_deepslate_slab': {
        hardness: 3.5,
        colors: [
            { red: 0.345, green: 0.345, blue: 0.345, alpha: 1 },
            { red: 0.294, green: 0.298, blue: 0.31, alpha: 1 },
            { red: 0.255, green: 0.255, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:polished_deepslate_stairs': {
        hardness: 3.5,
        colors: [
            { red: 0.345, green: 0.345, blue: 0.345, alpha: 1 },
            { red: 0.294, green: 0.298, blue: 0.31, alpha: 1 },
            { red: 0.255, green: 0.255, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:polished_deepslate_wall': {
        hardness: 3.5,
        colors: [
            { red: 0.345, green: 0.345, blue: 0.345, alpha: 1 },
            { red: 0.294, green: 0.298, blue: 0.31, alpha: 1 },
            { red: 0.255, green: 0.255, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:polished_diorite': {
        hardness: 1.5,
        colors: [
            { red: 0.784, green: 0.788, blue: 0.784, alpha: 1 },
            { red: 0.851, green: 0.847, blue: 0.851, alpha: 1 },
            { red: 0.729, green: 0.733, blue: 0.753, alpha: 1 }
        ]
    },
    'minecraft:polished_diorite_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.784, green: 0.788, blue: 0.784, alpha: 1 },
            { red: 0.851, green: 0.847, blue: 0.851, alpha: 1 },
            { red: 0.729, green: 0.733, blue: 0.753, alpha: 1 }
        ]
    },
    'minecraft:polished_diorite_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.784, green: 0.788, blue: 0.784, alpha: 1 },
            { red: 0.851, green: 0.847, blue: 0.851, alpha: 1 },
            { red: 0.729, green: 0.733, blue: 0.753, alpha: 1 }
        ]
    },
    'minecraft:polished_granite': {
        hardness: 1.5,
        colors: [
            { red: 0.624, green: 0.42, blue: 0.345, alpha: 1 },
            { red: 0.573, green: 0.384, blue: 0.318, alpha: 1 },
            { red: 0.663, green: 0.467, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:polished_granite_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.624, green: 0.42, blue: 0.345, alpha: 1 },
            { red: 0.573, green: 0.384, blue: 0.318, alpha: 1 },
            { red: 0.663, green: 0.467, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:polished_granite_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.624, green: 0.42, blue: 0.345, alpha: 1 },
            { red: 0.573, green: 0.384, blue: 0.318, alpha: 1 },
            { red: 0.663, green: 0.467, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:polished_tuff': {
        hardness: 1.5,
        colors: [
            { red: 0.388, green: 0.424, blue: 0.427, alpha: 1 },
            { red: 0.357, green: 0.384, blue: 0.369, alpha: 1 },
            { red: 0.424, green: 0.443, blue: 0.42, alpha: 1 }
        ]
    },
    'minecraft:polished_tuff_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.388, green: 0.424, blue: 0.427, alpha: 1 },
            { red: 0.357, green: 0.384, blue: 0.369, alpha: 1 },
            { red: 0.424, green: 0.443, blue: 0.42, alpha: 1 }
        ]
    },
    'minecraft:polished_tuff_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.388, green: 0.424, blue: 0.427, alpha: 1 },
            { red: 0.357, green: 0.384, blue: 0.369, alpha: 1 },
            { red: 0.424, green: 0.443, blue: 0.42, alpha: 1 }
        ]
    },
    'minecraft:polished_tuff_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.388, green: 0.424, blue: 0.427, alpha: 1 },
            { red: 0.357, green: 0.384, blue: 0.369, alpha: 1 },
            { red: 0.424, green: 0.443, blue: 0.42, alpha: 1 }
        ]
    },
    'minecraft:poppy': {
        hardness: 0,
        colors: [
            { red: 0.929, green: 0.188, blue: 0.173, alpha: 1 },
            { red: 0.125, green: 0.275, blue: 0.149, alpha: 1 },
            { red: 0.749, green: 0.145, blue: 0.161, alpha: 1 }
        ]
    },
    'minecraft:portal': {
        hardness: -1,
        colors: [
            { red: 0.231, green: 0, blue: 0.663, alpha: 1 },
            { red: 0.306, green: 0.012, blue: 0.741, alpha: 1 },
            { red: 0.224, green: 0, blue: 0.647, alpha: 1 }
        ]
    },
    'minecraft:potatoes': {
        hardness: 0,
        colors: [
            { red: 0.149, green: 0.388, blue: 0.145, alpha: 1 },
            { red: 0.333, green: 0.671, blue: 0.176, alpha: 1 },
            { red: 0.29, green: 0.561, blue: 0.157, alpha: 1 }
        ]
    },
    'minecraft:powder_snow': {
        hardness: 0.25,
        colors: [
            { red: 1, green: 1, blue: 1, alpha: 1 },
            { red: 0.957, green: 0.988, blue: 0.988, alpha: 1 },
            { red: 0.925, green: 0.984, blue: 0.984, alpha: 1 }
        ]
    },
    'minecraft:prismarine': {
        hardness: 1.5,
        colors: [
            { red: 0.369, green: 0.643, blue: 0.557, alpha: 1 },
            { red: 0.608, green: 0.796, blue: 0.749, alpha: 1 },
            { red: 0.369, green: 0.522, blue: 0.643, alpha: 1 }
        ]
    },
    'minecraft:prismarine_brick_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.431, green: 0.725, blue: 0.682, alpha: 1 },
            { red: 0.353, green: 0.686, blue: 0.643, alpha: 1 },
            { red: 0.38, green: 0.647, blue: 0.604, alpha: 1 }
        ]
    },
    'minecraft:prismarine_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.431, green: 0.725, blue: 0.682, alpha: 1 },
            { red: 0.353, green: 0.686, blue: 0.643, alpha: 1 },
            { red: 0.38, green: 0.647, blue: 0.604, alpha: 1 }
        ]
    },
    'minecraft:prismarine_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.369, green: 0.643, blue: 0.557, alpha: 1 },
            { red: 0.608, green: 0.796, blue: 0.749, alpha: 1 },
            { red: 0.369, green: 0.522, blue: 0.643, alpha: 1 }
        ]
    },
    'minecraft:prismarine_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.369, green: 0.643, blue: 0.557, alpha: 1 },
            { red: 0.608, green: 0.796, blue: 0.749, alpha: 1 },
            { red: 0.369, green: 0.522, blue: 0.643, alpha: 1 }
        ]
    },
    'minecraft:prismarine_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.369, green: 0.643, blue: 0.557, alpha: 1 },
            { red: 0.608, green: 0.796, blue: 0.749, alpha: 1 },
            { red: 0.369, green: 0.522, blue: 0.643, alpha: 1 }
        ]
    },
    'minecraft:pumpkin': {
        hardness: 1,
        colors: [
            { red: 0.89, green: 0.541, blue: 0.114, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.043, alpha: 1 },
            { red: 0.769, green: 0.435, blue: 0.078, alpha: 1 }
        ]
    },
    'minecraft:pumpkin_stem': {
        hardness: 0,
        colors: [
            { red: 0.89, green: 0.541, blue: 0.114, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.043, alpha: 1 },
            { red: 0.769, green: 0.435, blue: 0.078, alpha: 1 }
        ]
    },
    'minecraft:purpur_block': {
        hardness: 1.5,
        colors: [
            { red: 0.698, green: 0.525, blue: 0.698, alpha: 1 },
            { red: 0.675, green: 0.482, blue: 0.675, alpha: 1 },
            { red: 0.643, green: 0.447, blue: 0.639, alpha: 1 }
        ]
    },
    'minecraft:purpur_pillar': {
        hardness: 1.5,
        colors: [
            { red: 0.698, green: 0.525, blue: 0.698, alpha: 1 },
            { red: 0.565, green: 0.396, blue: 0.565, alpha: 1 },
            { red: 0.729, green: 0.584, blue: 0.729, alpha: 1 }
        ]
    },
    'minecraft:purpur_slab': {
        hardness: 2,
        colors: [
            { red: 0.698, green: 0.525, blue: 0.698, alpha: 1 },
            { red: 0.675, green: 0.482, blue: 0.675, alpha: 1 },
            { red: 0.643, green: 0.447, blue: 0.639, alpha: 1 }
        ]
    },
    'minecraft:purpur_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.698, green: 0.525, blue: 0.698, alpha: 1 },
            { red: 0.675, green: 0.482, blue: 0.675, alpha: 1 },
            { red: 0.643, green: 0.447, blue: 0.639, alpha: 1 }
        ]
    },
    'minecraft:quartz_block': {
        hardness: 0.8,
        colors: [
            { red: 0.933, green: 0.918, blue: 0.902, alpha: 1 },
            { red: 0.933, green: 0.902, blue: 0.871, alpha: 1 },
            { red: 0.918, green: 0.886, blue: 0.855, alpha: 1 }
        ]
    },
    'minecraft:quartz_bricks': {
        hardness: 0.8,
        colors: [
            { red: 0.933, green: 0.918, blue: 0.902, alpha: 1 },
            { red: 0.918, green: 0.886, blue: 0.855, alpha: 1 },
            { red: 0.933, green: 0.902, blue: 0.871, alpha: 1 }
        ]
    },
    'minecraft:quartz_ore': {
        hardness: 3,
        colors: [
            { red: 0.447, green: 0.196, blue: 0.196, alpha: 1 },
            { red: 0.396, green: 0.157, blue: 0.157, alpha: 1 },
            { red: 0.314, green: 0.106, blue: 0.106, alpha: 1 }
        ]
    },
    'minecraft:quartz_pillar': {
        hardness: 0.8,
        colors: [
            { red: 0.933, green: 0.918, blue: 0.902, alpha: 1 },
            { red: 0.933, green: 0.902, blue: 0.871, alpha: 1 },
            { red: 0.918, green: 0.886, blue: 0.855, alpha: 1 }
        ]
    },
    'minecraft:quartz_slab': {
        hardness: 2,
        colors: [
            { red: 0.933, green: 0.918, blue: 0.902, alpha: 1 },
            { red: 0.933, green: 0.902, blue: 0.871, alpha: 1 },
            { red: 0.918, green: 0.886, blue: 0.855, alpha: 1 }
        ]
    },
    'minecraft:quartz_stairs': {
        hardness: 0.8,
        colors: [
            { red: 0.933, green: 0.918, blue: 0.902, alpha: 1 },
            { red: 0.933, green: 0.902, blue: 0.871, alpha: 1 },
            { red: 0.918, green: 0.886, blue: 0.855, alpha: 1 }
        ]
    },
    'minecraft:rail': {
        hardness: 0.7,
        colors: [
            { red: 0.404, green: 0.314, blue: 0.173, alpha: 1 },
            { red: 0.612, green: 0.612, blue: 0.612, alpha: 1 },
            { red: 0.494, green: 0.384, blue: 0.216, alpha: 1 }
        ]
    },
    'minecraft:raw_copper_block': {
        hardness: 5,
        colors: [
            { red: 0.616, green: 0.341, blue: 0.247, alpha: 1 },
            { red: 0.518, green: 0.302, blue: 0.231, alpha: 1 },
            { red: 0.443, green: 0.404, blue: 0.271, alpha: 1 }
        ]
    },
    'minecraft:raw_gold_block': {
        hardness: 5,
        colors: [
            { red: 0.788, green: 0.549, blue: 0.11, alpha: 1 },
            { red: 0.969, green: 0.769, blue: 0.192, alpha: 1 },
            { red: 0.933, green: 0.643, blue: 0.102, alpha: 1 }
        ]
    },
    'minecraft:raw_iron_block': {
        hardness: 5,
        colors: [
            { red: 0.686, green: 0.557, blue: 0.467, alpha: 1 },
            { red: 0.557, green: 0.455, blue: 0.329, alpha: 1 },
            { red: 0.486, green: 0.384, blue: 0.247, alpha: 1 }
        ]
    },
    'minecraft:red_mushroom': {
        hardness: 0,
        colors: [
            { red: 0.886, green: 0.071, blue: 0.071, alpha: 1 },
            { red: 0.996, green: 0.165, blue: 0.165, alpha: 1 },
            { red: 0.769, green: 0.114, blue: 0.149, alpha: 1 }
        ]
    },
    'minecraft:red_mushroom_block': {
        hardness: 0,
        colors: [
            { red: 0.765, green: 0.157, blue: 0.149, alpha: 1 },
            { red: 0.788, green: 0.169, blue: 0.161, alpha: 1 },
            { red: 0.745, green: 0.137, blue: 0.129, alpha: 1 }
        ]
    },
    'minecraft:red_nether_brick_slab': {
        hardness: 2,
        colors: [
            { red: 0.267, green: 0.02, blue: 0.027, alpha: 1 },
            { red: 0.18, green: 0, blue: 0.004, alpha: 1 },
            { red: 0.204, green: 0.004, blue: 0.012, alpha: 1 }
        ]
    },
    'minecraft:red_nether_brick_stairs': {
        hardness: 2,
        colors: [
            { red: 0.267, green: 0.02, blue: 0.027, alpha: 1 },
            { red: 0.18, green: 0, blue: 0.004, alpha: 1 },
            { red: 0.204, green: 0.004, blue: 0.012, alpha: 1 }
        ]
    },
    'minecraft:red_nether_brick_wall': {
        hardness: 2,
        colors: [
            { red: 0.267, green: 0.02, blue: 0.027, alpha: 1 },
            { red: 0.18, green: 0, blue: 0.004, alpha: 1 },
            { red: 0.204, green: 0.004, blue: 0.012, alpha: 1 }
        ]
    },
    'minecraft:red_sand': {
        hardness: 0.5,
        colors: [
            { red: 0.749, green: 0.404, blue: 0.129, alpha: 1 },
            { red: 0.698, green: 0.376, blue: 0.122, alpha: 1 },
            { red: 0.796, green: 0.431, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:red_sandstone': {
        hardness: 0.8,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 },
            { red: 0.824, green: 0.459, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:red_sandstone_slab': {
        hardness: 2,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 },
            { red: 0.824, green: 0.459, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:red_sandstone_stairs': {
        hardness: 0.8,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 },
            { red: 0.824, green: 0.459, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:red_sandstone_wall': {
        hardness: 0.8,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 },
            { red: 0.824, green: 0.459, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:red_tulip': {
        hardness: 0,
        colors: [
            { red: 0.09, green: 0.486, blue: 0.016, alpha: 1 },
            { red: 0.333, green: 0.671, blue: 0.176, alpha: 1 },
            { red: 0.322, green: 0.604, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:redstone_block': {
        hardness: 5,
        colors: [
            { red: 0.902, green: 0.125, blue: 0.031, alpha: 1 },
            { red: 0.451, green: 0.047, blue: 0, alpha: 1 },
            { red: 0.643, green: 0.094, blue: 0.031, alpha: 1 }
        ]
    },
    'minecraft:redstone_lamp': {
        hardness: 0.3,
        colors: [
            { red: 0.192, green: 0.102, blue: 0.067, alpha: 1 },
            { red: 0.525, green: 0.306, blue: 0.161, alpha: 1 },
            { red: 0.373, green: 0.2, blue: 0.082, alpha: 1 }
        ]
    },
    'minecraft:redstone_ore': {
        hardness: 3,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.576, green: 0.549, blue: 0.549, alpha: 1 }
        ]
    },
    'minecraft:redstone_torch': {
        hardness: 0,
        colors: [
            { red: 0.624, green: 0.498, blue: 0.314, alpha: 1 },
            { red: 0.427, green: 0.341, blue: 0.212, alpha: 1 },
            { red: 0.333, green: 0.271, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:redstone_wire': {
        hardness: 0,
        colors: [
            { red: 0.902, green: 0.125, blue: 0.031, alpha: 1 },
            { red: 0.451, green: 0.047, blue: 0, alpha: 1 },
            { red: 0.643, green: 0.094, blue: 0.031, alpha: 1 }
        ]
    },
    'minecraft:reinforced_deepslate': {
        hardness: 55,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 },
            { red: 0.22, green: 0.216, blue: 0.216, alpha: 1 }
        ]
    },
    'minecraft:repeating_command_block': {
        hardness: -1,
        colors: [
            { red: 0.416, green: 0.31, blue: 0.78, alpha: 1 },
            { red: 0.702, green: 0.69, blue: 0.725, alpha: 1 },
            { red: 0.333, green: 0.231, blue: 0.608, alpha: 1 }
        ]
    },
    'minecraft:reserved6': { hardness: 0 },
    'minecraft:resin_block': {
        hardness: 0,
        colors: [
            { red: 0.89, green: 0.384, blue: 0.086, alpha: 1 },
            { red: 0.78, green: 0.286, blue: 0.039, alpha: 1 },
            { red: 0.702, green: 0.243, blue: 0.075, alpha: 1 }
        ]
    },
    'minecraft:resin_brick_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.78, green: 0.286, blue: 0.039, alpha: 1 },
            { red: 0.89, green: 0.384, blue: 0.086, alpha: 1 },
            { red: 0.702, green: 0.243, blue: 0.075, alpha: 1 }
        ]
    },
    'minecraft:resin_brick_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.78, green: 0.286, blue: 0.039, alpha: 1 },
            { red: 0.89, green: 0.384, blue: 0.086, alpha: 1 },
            { red: 0.702, green: 0.243, blue: 0.075, alpha: 1 }
        ]
    },
    'minecraft:resin_brick_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.78, green: 0.286, blue: 0.039, alpha: 1 },
            { red: 0.89, green: 0.384, blue: 0.086, alpha: 1 },
            { red: 0.702, green: 0.243, blue: 0.075, alpha: 1 }
        ]
    },
    'minecraft:resin_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.78, green: 0.286, blue: 0.039, alpha: 1 },
            { red: 0.89, green: 0.384, blue: 0.086, alpha: 1 },
            { red: 0.702, green: 0.243, blue: 0.075, alpha: 1 }
        ]
    },
    'minecraft:resin_clump': {
        hardness: 0,
        colors: [
            { red: 0.89, green: 0.384, blue: 0.086, alpha: 1 },
            { red: 0.71, green: 0.251, blue: 0.024, alpha: 1 },
            { red: 0.937, green: 0.529, blue: 0.216, alpha: 1 }
        ]
    },
    'minecraft:respawn_anchor': {
        hardness: 50,
        colors: [
            { red: 0.024, green: 0.012, blue: 0.043, alpha: 1 },
            { red: 0.282, green: 0.22, blue: 0.376, alpha: 1 },
            { red: 0.11, green: 0.078, blue: 0.129, alpha: 1 }
        ]
    },
    'minecraft:rose_bush': {
        hardness: 0,
        colors: [
            { red: 0.749, green: 0.145, blue: 0.161, alpha: 1 },
            { red: 0.929, green: 0.188, blue: 0.173, alpha: 1 },
            { red: 0.125, green: 0.275, blue: 0.149, alpha: 1 }
        ]
    },
    'minecraft:sand': {
        hardness: 0.5,
        colors: [
            { red: 0.855, green: 0.812, blue: 0.639, alpha: 1 },
            { red: 0.835, green: 0.769, blue: 0.588, alpha: 1 },
            { red: 0.89, green: 0.859, blue: 0.69, alpha: 1 }
        ]
    },
    'minecraft:sandstone': {
        hardness: 0.8,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 },
            { red: 0.906, green: 0.894, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:sandstone_slab': {
        hardness: 2,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 },
            { red: 0.906, green: 0.894, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:sandstone_stairs': {
        hardness: 0.8,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 },
            { red: 0.906, green: 0.894, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:sandstone_wall': {
        hardness: 0.8,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 },
            { red: 0.906, green: 0.894, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:scaffolding': {
        hardness: 0,
        colors: [
            { red: 0.671, green: 0.451, blue: 0.255, alpha: 1 },
            { red: 0.549, green: 0.408, blue: 0.278, alpha: 1 },
            { red: 0.757, green: 0.537, blue: 0.345, alpha: 1 }
        ]
    },
    'minecraft:sculk': {
        hardness: 0.2,
        colors: [
            { red: 0.051, green: 0.071, blue: 0.09, alpha: 1 },
            { red: 0.067, green: 0.106, blue: 0.129, alpha: 1 },
            { red: 0.02, green: 0.165, blue: 0.196, alpha: 1 }
        ]
    },
    'minecraft:sculk_catalyst': {
        hardness: 3,
        colors: [
            { red: 0.051, green: 0.071, blue: 0.09, alpha: 1 },
            { red: 0.067, green: 0.106, blue: 0.129, alpha: 1 },
            { red: 0.251, green: 0.341, blue: 0.424, alpha: 1 }
        ]
    },
    'minecraft:sculk_sensor': {
        hardness: 1.5,
        colors: [
            { red: 0.051, green: 0.071, blue: 0.09, alpha: 1 },
            { red: 0.024, green: 0.18, blue: 0.216, alpha: 1 },
            { red: 0.043, green: 0.129, blue: 0.165, alpha: 1 }
        ]
    },
    'minecraft:sculk_shrieker': {
        hardness: 3,
        colors: [
            { red: 0.024, green: 0.18, blue: 0.216, alpha: 1 },
            { red: 0.733, green: 0.765, blue: 0.608, alpha: 1 },
            { red: 0.067, green: 0.106, blue: 0.129, alpha: 1 }
        ]
    },
    'minecraft:sculk_vein': {
        hardness: 0.2,
        colors: [
            { red: 0.012, green: 0.255, blue: 0.314, alpha: 1 },
            { red: 0.02, green: 0.165, blue: 0.196, alpha: 1 },
            { red: 0.067, green: 0.106, blue: 0.129, alpha: 1 }
        ]
    },
    'minecraft:sea_lantern': {
        hardness: 0.3,
        colors: [
            { red: 0.89, green: 0.922, blue: 0.894, alpha: 1 },
            { red: 0.882, green: 0.918, blue: 0.882, alpha: 1 },
            { red: 0.875, green: 0.91, blue: 0.878, alpha: 1 }
        ]
    },
    'minecraft:sea_pickle': {
        hardness: 0,
        colors: [
            { red: 0.424, green: 0.447, blue: 0.165, alpha: 1 },
            { red: 0.294, green: 0.31, blue: 0.098, alpha: 1 },
            { red: 0.384, green: 0.408, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:seagrass': {
        hardness: 0,
        colors: [
            { red: 0.184, green: 0.51, blue: 0, alpha: 1 },
            { red: 0.22, green: 0.576, blue: 0.024, alpha: 1 },
            { red: 0.129, green: 0.345, blue: 0, alpha: 1 }
        ]
    },
    'minecraft:short_dry_grass': {
        hardness: 0,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.349, green: 0.239, blue: 0.161, alpha: 1 }
        ]
    },
    'minecraft:short_grass': {
        hardness: 0,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.349, green: 0.239, blue: 0.161, alpha: 1 }
        ]
    },
    'minecraft:shroomlight': {
        hardness: 1,
        colors: [
            { red: 0.996, green: 0.675, blue: 0.427, alpha: 1 },
            { red: 0.894, green: 0.447, blue: 0.02, alpha: 1 },
            { red: 0.996, green: 0.529, blue: 0.22, alpha: 1 }
        ]
    },
    'minecraft:skeleton_skull': {
        hardness: 1,
        colors: [
            { red: 0.573, green: 0.573, blue: 0.573, alpha: 1 },
            { red: 0.553, green: 0.553, blue: 0.553, alpha: 1 },
            { red: 0.702, green: 0.702, blue: 0.702, alpha: 1 }
        ]
    },
    'minecraft:small_amethyst_bud': {
        hardness: 1.5,
        colors: [
            { red: 0.392, green: 0.278, blue: 0.62, alpha: 1 },
            { red: 0.478, green: 0.357, blue: 0.71, alpha: 1 },
            { red: 0.553, green: 0.416, blue: 0.8, alpha: 1 }
        ]
    },
    'minecraft:small_dripleaf_block': {
        hardness: 0,
        colors: [
            { red: 0.439, green: 0.573, blue: 0.176, alpha: 1 },
            { red: 0.314, green: 0.412, blue: 0.173, alpha: 1 },
            { red: 0.259, green: 0.333, blue: 0.176, alpha: 1 }
        ]
    },
    'minecraft:smithing_table': {
        hardness: 2.5,
        colors: [
            { red: 0.184, green: 0.078, blue: 0.067, alpha: 1 },
            { red: 0.29, green: 0.122, blue: 0.102, alpha: 1 },
            { red: 0.259, green: 0.11, blue: 0.09, alpha: 1 }
        ]
    },
    'minecraft:smoker': {
        hardness: 3.5,
        colors: [
            { red: 0.404, green: 0.314, blue: 0.173, alpha: 1 },
            { red: 0.318, green: 0.239, blue: 0.141, alpha: 1 },
            { red: 0.522, green: 0.522, blue: 0.522, alpha: 1 }
        ]
    },
    'minecraft:smooth_basalt': {
        hardness: 1.25,
        colors: [
            { red: 0.31, green: 0.294, blue: 0.31, alpha: 1 },
            { red: 0.361, green: 0.361, blue: 0.361, alpha: 1 },
            { red: 0.227, green: 0.231, blue: 0.282, alpha: 1 }
        ]
    },
    'minecraft:smooth_quartz_slab': {
        hardness: 2,
        colors: [
            { red: 0.933, green: 0.918, blue: 0.902, alpha: 1 },
            { red: 0.933, green: 0.902, blue: 0.871, alpha: 1 },
            { red: 0.918, green: 0.886, blue: 0.855, alpha: 1 }
        ]
    },
    'minecraft:smooth_quartz_stairs': {
        hardness: 2,
        colors: [
            { red: 0.933, green: 0.918, blue: 0.902, alpha: 1 },
            { red: 0.933, green: 0.902, blue: 0.871, alpha: 1 },
            { red: 0.918, green: 0.886, blue: 0.855, alpha: 1 }
        ]
    },
    'minecraft:smooth_red_sandstone': {
        hardness: 2,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.698, green: 0.376, blue: 0.122, alpha: 1 },
            { red: 0.796, green: 0.431, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:smooth_red_sandstone_slab': {
        hardness: 2,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 },
            { red: 0.824, green: 0.459, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:smooth_red_sandstone_stairs': {
        hardness: 2,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 },
            { red: 0.824, green: 0.459, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:smooth_sandstone': {
        hardness: 2,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.835, green: 0.769, blue: 0.588, alpha: 1 },
            { red: 0.89, green: 0.859, blue: 0.69, alpha: 1 }
        ]
    },
    'minecraft:smooth_sandstone_slab': {
        hardness: 2,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 },
            { red: 0.906, green: 0.894, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:smooth_sandstone_stairs': {
        hardness: 2,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 },
            { red: 0.906, green: 0.894, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:smooth_stone': {
        hardness: 2,
        colors: [
            { red: 0.659, green: 0.659, blue: 0.659, alpha: 1 },
            { red: 0.639, green: 0.639, blue: 0.639, alpha: 1 },
            { red: 0.69, green: 0.69, blue: 0.69, alpha: 1 }
        ]
    },
    'minecraft:smooth_stone_slab': {
        hardness: 2,
        colors: [
            { red: 0.659, green: 0.659, blue: 0.659, alpha: 1 },
            { red: 0.639, green: 0.639, blue: 0.639, alpha: 1 },
            { red: 0.69, green: 0.69, blue: 0.69, alpha: 1 }
        ]
    },
    'minecraft:sniffer_egg': {
        hardness: 0.5,
        colors: [
            { red: 0.204, green: 0.475, blue: 0.302, alpha: 1 },
            { red: 0.486, green: 0.078, blue: 0.078, alpha: 1 },
            { red: 0.541, green: 0.129, blue: 0.098, alpha: 1 }
        ]
    },
    'minecraft:snow': {
        hardness: 0.1,
        colors: [
            { red: 1, green: 1, blue: 1, alpha: 1 },
            { red: 0.969, green: 0.996, blue: 0.996, alpha: 1 },
            { red: 0.941, green: 0.992, blue: 0.992, alpha: 1 }
        ]
    },
    'minecraft:snow_layer': {
        hardness: 0.1,
        colors: [
            { red: 1, green: 1, blue: 1, alpha: 1 },
            { red: 0.969, green: 0.996, blue: 0.996, alpha: 1 },
            { red: 0.941, green: 0.992, blue: 0.992, alpha: 1 }
        ]
    },
    'minecraft:soul_campfire': {
        hardness: 2,
        colors: [
            { red: 0.486, green: 0.949, blue: 0.961, alpha: 1 },
            { red: 0.075, green: 0.686, blue: 0.702, alpha: 1 },
            { red: 0.357, green: 0.89, blue: 0.91, alpha: 1 }
        ]
    },
    'minecraft:soul_fire': {
        hardness: 0,
        colors: [
            { red: 1, green: 1, blue: 1, alpha: 1 },
            { red: 0.004, green: 0.635, blue: 0.655, alpha: 1 },
            { red: 0.004, green: 0.518, blue: 0.533, alpha: 1 }
        ]
    },
    'minecraft:soul_lantern': {
        hardness: 3.5,
        colors: [
            { red: 0.243, green: 0.267, blue: 0.325, alpha: 1 },
            { red: 0.286, green: 0.314, blue: 0.396, alpha: 1 },
            { red: 0.259, green: 0.29, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:soul_sand': {
        hardness: 0.5,
        colors: [
            { red: 0.286, green: 0.216, blue: 0.173, alpha: 1 },
            { red: 0.357, green: 0.271, blue: 0.22, alpha: 1 },
            { red: 0.416, green: 0.322, blue: 0.267, alpha: 1 }
        ]
    },
    'minecraft:soul_soil': {
        hardness: 0.5,
        colors: [
            { red: 0.286, green: 0.216, blue: 0.173, alpha: 1 },
            { red: 0.357, green: 0.271, blue: 0.22, alpha: 1 },
            { red: 0.239, green: 0.18, blue: 0.145, alpha: 1 }
        ]
    },
    'minecraft:soul_torch': {
        hardness: 0,
        colors: [
            { red: 0.624, green: 0.498, blue: 0.314, alpha: 1 },
            { red: 0.427, green: 0.341, blue: 0.212, alpha: 1 },
            { red: 0.333, green: 0.271, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:sponge': {
        hardness: 0.6,
        colors: [
            { red: 0.804, green: 0.808, blue: 0.29, alpha: 1 },
            { red: 0.757, green: 0.737, blue: 0.306, alpha: 1 },
            { red: 0.882, green: 0.89, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:spore_blossom': {
        hardness: 0,
        colors: [
            { red: 0.439, green: 0.573, blue: 0.176, alpha: 1 },
            { red: 0.424, green: 0.502, blue: 0.192, alpha: 1 },
            { red: 0.518, green: 0.659, blue: 0.235, alpha: 1 }
        ]
    },
    'minecraft:spruce_door': {
        hardness: 3,
        colors: [
            { red: 0.502, green: 0.369, blue: 0.212, alpha: 1 },
            { red: 0.353, green: 0.267, blue: 0.141, alpha: 1 },
            { red: 0.42, green: 0.325, blue: 0.196, alpha: 1 }
        ]
    },
    'minecraft:sticky_piston': {
        hardness: 1.5,
        colors: [
            { red: 0.325, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.408, green: 0.408, blue: 0.408, alpha: 1 },
            { red: 0.267, green: 0.267, blue: 0.267, alpha: 1 }
        ]
    },
    'minecraft:stone': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 }
        ]
    },
    'minecraft:stone_brick_slab': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:stone_brick_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:stone_brick_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:stone_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:stone_button': {
        hardness: 0.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 }
        ]
    },
    'minecraft:stone_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 }
        ]
    },
    'minecraft:stone_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 }
        ]
    },
    'minecraft:stonecutter': {
        hardness: 3.5,
        colors: [
            { red: 0.714, green: 0.741, blue: 0.741, alpha: 1 },
            { red: 0.808, green: 0.839, blue: 0.839, alpha: 1 },
            { red: 0.639, green: 0.639, blue: 0.639, alpha: 1 }
        ]
    },
    'minecraft:stonecutter_block': {
        hardness: 3.5,
        colors: [
            { red: 0.533, green: 0.529, blue: 0.533, alpha: 1 },
            { red: 0.502, green: 0.502, blue: 0.502, alpha: 1 },
            { red: 0.322, green: 0.322, blue: 0.322, alpha: 1 }
        ]
    },
    'minecraft:stripped_bamboo_block': {
        hardness: 2,
        colors: [
            { red: 0.784, green: 0.694, blue: 0.302, alpha: 1 },
            { red: 0.89, green: 0.8, blue: 0.416, alpha: 1 },
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:structure_block': {
        hardness: -1,
        colors: [
            { red: 0.149, green: 0.114, blue: 0.165, alpha: 1 },
            { red: 0.063, green: 0.063, blue: 0.063, alpha: 1 },
            { red: 0.588, green: 0.471, blue: 0.588, alpha: 1 }
        ]
    },
    'minecraft:structure_void': { hardness: 0, colors: [{ red: 1, green: 0, blue: 0, alpha: 1 }] },
    'minecraft:sunflower': {
        hardness: 0,
        colors: [
            { red: 0.29, green: 0.561, blue: 0.157, alpha: 1 },
            { red: 0.09, green: 0.486, blue: 0.016, alpha: 1 },
            { red: 0.322, green: 0.604, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:suspicious_gravel': {
        hardness: 0.25,
        colors: [
            { red: 0.506, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.537, green: 0.506, blue: 0.494, alpha: 1 },
            { red: 0.447, green: 0.42, blue: 0.412, alpha: 1 }
        ]
    },
    'minecraft:suspicious_sand': {
        hardness: 0.25,
        colors: [
            { red: 0.855, green: 0.812, blue: 0.639, alpha: 1 },
            { red: 0.835, green: 0.769, blue: 0.588, alpha: 1 },
            { red: 0.89, green: 0.859, blue: 0.69, alpha: 1 }
        ]
    },
    'minecraft:tall_dry_grass': {
        hardness: 0,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.349, green: 0.239, blue: 0.161, alpha: 1 }
        ]
    },
    'minecraft:tall_grass': {
        hardness: 0,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.349, green: 0.239, blue: 0.161, alpha: 1 }
        ]
    },
    'minecraft:target': {
        hardness: 0.5,
        colors: [
            { red: 0.937, green: 0.886, blue: 0.816, alpha: 1 },
            { red: 0.953, green: 0.922, blue: 0.875, alpha: 1 },
            { red: 0.996, green: 0.996, blue: 0.992, alpha: 1 }
        ]
    },
    'minecraft:tinted_glass': {
        hardness: 0.3,
        colors: [
            { red: 0.153, green: 0.145, blue: 0.157, alpha: 1 },
            { red: 0.208, green: 0.157, blue: 0.231, alpha: 1 },
            { red: 0.169, green: 0.125, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:tnt': {
        hardness: 0,
        colors: [
            { red: 0.859, green: 0.184, blue: 0.102, alpha: 1 },
            { red: 0.694, green: 0.082, blue: 0.153, alpha: 1 },
            { red: 0.569, green: 0.176, blue: 0.067, alpha: 1 }
        ]
    },
    'minecraft:torch': {
        hardness: 0,
        colors: [
            { red: 0.624, green: 0.498, blue: 0.314, alpha: 1 },
            { red: 0.427, green: 0.341, blue: 0.212, alpha: 1 },
            { red: 0.333, green: 0.271, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:torchflower': {
        hardness: 0,
        colors: [
            { red: 0.11, green: 0.357, blue: 0.227, alpha: 1 },
            { red: 0.075, green: 0.271, blue: 0.196, alpha: 1 },
            { red: 0.153, green: 0.518, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:trapdoor': {
        hardness: 3,
        colors: [
            { red: 0.612, green: 0.475, blue: 0.29, alpha: 1 },
            { red: 0.384, green: 0.314, blue: 0.161, alpha: 1 },
            { red: 0.29, green: 0.235, blue: 0.125, alpha: 1 }
        ]
    },
    'minecraft:trapped_chest': {
        hardness: 2.5,
        colors: [
            { red: 0.561, green: 0.412, blue: 0.114, alpha: 1 },
            { red: 0.671, green: 0.475, blue: 0.176, alpha: 1 },
            { red: 0.643, green: 0.447, blue: 0.153, alpha: 1 }
        ]
    },
    'minecraft:trial_spawner': {
        hardness: 50,
        colors: [
            { red: 0.165, green: 0.267, blue: 0.333, alpha: 1 },
            { red: 0.094, green: 0.173, blue: 0.224, alpha: 1 },
            { red: 0.251, green: 0.384, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:tripwire_hook': {
        hardness: 0,
        colors: [
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 },
            { red: 0.357, green: 0.357, blue: 0.357, alpha: 1 },
            { red: 0.467, green: 0.467, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:tuff': {
        hardness: 1.5,
        colors: [
            { red: 0.416, green: 0.431, blue: 0.435, alpha: 1 },
            { red: 0.365, green: 0.365, blue: 0.322, alpha: 1 },
            { red: 0.522, green: 0.514, blue: 0.482, alpha: 1 }
        ]
    },
    'minecraft:tuff_brick_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.522, green: 0.514, blue: 0.478, alpha: 1 },
            { red: 0.424, green: 0.443, blue: 0.42, alpha: 1 },
            { red: 0.322, green: 0.353, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:tuff_brick_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.522, green: 0.514, blue: 0.478, alpha: 1 },
            { red: 0.424, green: 0.443, blue: 0.42, alpha: 1 },
            { red: 0.322, green: 0.353, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:tuff_brick_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.522, green: 0.514, blue: 0.478, alpha: 1 },
            { red: 0.424, green: 0.443, blue: 0.42, alpha: 1 },
            { red: 0.322, green: 0.353, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:tuff_bricks': {
        hardness: 1.5,
        colors: [
            { red: 0.522, green: 0.514, blue: 0.478, alpha: 1 },
            { red: 0.424, green: 0.443, blue: 0.42, alpha: 1 },
            { red: 0.322, green: 0.353, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:tuff_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.416, green: 0.431, blue: 0.435, alpha: 1 },
            { red: 0.365, green: 0.365, blue: 0.322, alpha: 1 },
            { red: 0.522, green: 0.514, blue: 0.482, alpha: 1 }
        ]
    },
    'minecraft:tuff_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.416, green: 0.431, blue: 0.435, alpha: 1 },
            { red: 0.365, green: 0.365, blue: 0.322, alpha: 1 },
            { red: 0.522, green: 0.514, blue: 0.482, alpha: 1 }
        ]
    },
    'minecraft:tuff_wall': {
        hardness: 1.5,
        colors: [
            { red: 0.416, green: 0.431, blue: 0.435, alpha: 1 },
            { red: 0.365, green: 0.365, blue: 0.322, alpha: 1 },
            { red: 0.522, green: 0.514, blue: 0.482, alpha: 1 }
        ]
    },
    'minecraft:turtle_egg': {
        hardness: 0.5,
        colors: [
            { red: 0.969, green: 0.945, blue: 0.851, alpha: 1 },
            { red: 0.949, green: 0.914, blue: 0.78, alpha: 1 },
            { red: 0.949, green: 0.886, blue: 0.663, alpha: 1 }
        ]
    },
    'minecraft:twisting_vines': {
        hardness: 0,
        colors: [
            { red: 0.067, green: 0.608, blue: 0.522, alpha: 1 },
            { red: 0.086, green: 0.38, blue: 0.357, alpha: 1 },
            { red: 0.086, green: 0.494, blue: 0.525, alpha: 1 }
        ]
    },
    'minecraft:underwater_tnt': {
        hardness: 0,
        colors: [
            { red: 0.447, green: 0.525, blue: 1, alpha: 1 },
            { red: 0.439, green: 0.514, blue: 1, alpha: 1 },
            { red: 0.443, green: 0.518, blue: 1, alpha: 1 }
        ]
    },
    'minecraft:underwater_torch': {
        hardness: 0,
        colors: [
            { red: 0.624, green: 0.498, blue: 0.314, alpha: 1 },
            { red: 0.427, green: 0.341, blue: 0.212, alpha: 1 },
            { red: 0.333, green: 0.271, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:vault': {
        hardness: 50,
        colors: [
            { red: 0.063, green: 0.114, blue: 0.145, alpha: 1 },
            { red: 0.094, green: 0.173, blue: 0.224, alpha: 1 },
            { red: 0.345, green: 0.376, blue: 0.345, alpha: 1 }
        ]
    },
    'minecraft:verdant_froglight': {
        hardness: 0.3,
        colors: [
            { red: 0.922, green: 0.976, blue: 0.925, alpha: 1 },
            { red: 0.973, green: 0.992, blue: 0.973, alpha: 1 },
            { red: 0.843, green: 0.933, blue: 0.835, alpha: 1 }
        ]
    },
    'minecraft:warped_door': {
        hardness: 3,
        colors: [
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.122, green: 0.341, blue: 0.322, alpha: 1 },
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 }
        ]
    },
    'minecraft:warped_fungus': {
        hardness: 0,
        colors: [
            { red: 0.078, green: 0.706, blue: 0.522, alpha: 1 },
            { red: 0.086, green: 0.38, blue: 0.357, alpha: 1 },
            { red: 0.086, green: 0.494, blue: 0.525, alpha: 1 }
        ]
    },
    'minecraft:warped_nylium': {
        hardness: 0.4,
        colors: [
            { red: 0.447, green: 0.196, blue: 0.196, alpha: 1 },
            { red: 0.396, green: 0.157, blue: 0.157, alpha: 1 },
            { red: 0.188, green: 0.235, blue: 0.208, alpha: 1 }
        ]
    },
    'minecraft:warped_roots': {
        hardness: 0,
        colors: [
            { red: 0.086, green: 0.494, blue: 0.525, alpha: 1 },
            { red: 0.067, green: 0.608, blue: 0.522, alpha: 1 },
            { red: 0.086, green: 0.38, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:warped_wart_block': {
        hardness: 1,
        colors: [
            { red: 0.086, green: 0.494, blue: 0.525, alpha: 1 },
            { red: 0.098, green: 0.388, blue: 0.404, alpha: 1 },
            { red: 0.094, green: 0.435, blue: 0.412, alpha: 1 }
        ]
    },
    'minecraft:water': {
        hardness: 100,
        colors: [
            { red: 0.447, green: 0.525, blue: 1, alpha: 1 },
            { red: 0.439, green: 0.514, blue: 1, alpha: 1 },
            { red: 0.443, green: 0.518, blue: 1, alpha: 1 }
        ]
    },
    'minecraft:web': {
        hardness: 4,
        colors: [
            { red: 1, green: 1, blue: 1, alpha: 1 },
            { red: 0.894, green: 0.914, blue: 0.914, alpha: 1 },
            { red: 0.769, green: 0.808, blue: 0.824, alpha: 1 }
        ]
    },
    'minecraft:weeping_vines': {
        hardness: 0,
        colors: [
            { red: 0.51, green: 0.02, blue: 0.173, alpha: 1 },
            { red: 0.4, green: 0.024, blue: 0.153, alpha: 1 },
            { red: 0.314, green: 0.024, blue: 0.165, alpha: 1 }
        ]
    },
    'minecraft:wet_sponge': {
        hardness: 0.6,
        colors: [
            { red: 0.69, green: 0.749, blue: 0.298, alpha: 1 },
            { red: 0.588, green: 0.659, blue: 0.275, alpha: 1 },
            { red: 0.804, green: 0.808, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:wheat': {
        hardness: 0,
        colors: [
            { red: 0.031, green: 0.533, blue: 0.024, alpha: 1 },
            { red: 0.02, green: 0.416, blue: 0.02, alpha: 1 },
            { red: 0.067, green: 0.463, blue: 0.122, alpha: 1 }
        ]
    },
    'minecraft:white_tulip': {
        hardness: 0,
        colors: [
            { red: 0.333, green: 0.671, blue: 0.176, alpha: 1 },
            { red: 0.09, green: 0.486, blue: 0.016, alpha: 1 },
            { red: 0.322, green: 0.604, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:wildflowers': {
        hardness: 0,
        colors: [
            { red: 0.996, green: 0.839, blue: 0.224, alpha: 1 },
            { red: 0.961, green: 0.729, blue: 0.153, alpha: 1 },
            { red: 0.839, green: 0.91, blue: 0.91, alpha: 1 }
        ]
    },
    'minecraft:wither_rose': {
        hardness: 0,
        colors: [
            { red: 0.22, green: 0.271, blue: 0.102, alpha: 1 },
            { red: 0.173, green: 0.208, blue: 0.09, alpha: 1 },
            { red: 0.259, green: 0.208, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:wither_skeleton_skull': {
        hardness: 1,
        colors: [
            { red: 0.078, green: 0.078, blue: 0.078, alpha: 1 },
            { red: 0.133, green: 0.133, blue: 0.133, alpha: 1 },
            { red: 0.102, green: 0.102, blue: 0.102, alpha: 1 }
        ]
    },
    'minecraft:wooden_button': {
        hardness: 0.5,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:wooden_door': {
        hardness: 3,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:wooden_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:zombie_head': {
        hardness: 1,
        colors: [
            { red: 0, green: 0.655, blue: 0.655, alpha: 1 },
            { red: 0.235, green: 0.396, blue: 0.18, alpha: 1 },
            { red: 0.247, green: 0.412, blue: 0.184, alpha: 1 }
        ]
    },
    'minecraft:acacia_button': {
        hardness: 0.5,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:acacia_fence': {
        hardness: 2,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:acacia_fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:acacia_log': {
        hardness: 2,
        colors: [
            { red: 0.412, green: 0.384, blue: 0.349, alpha: 1 },
            { red: 0.482, green: 0.451, blue: 0.408, alpha: 1 },
            { red: 0.357, green: 0.333, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:bamboo_button': {
        hardness: 0.5,
        colors: [
            { red: 0.349, green: 0.565, blue: 0.012, alpha: 1 },
            { red: 0.325, green: 0.51, blue: 0.035, alpha: 1 },
            { red: 0.553, green: 0.761, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:bamboo_fence': {
        hardness: 2,
        colors: [
            { red: 0.89, green: 0.8, blue: 0.416, alpha: 1 },
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 },
            { red: 0.733, green: 0.659, blue: 0.298, alpha: 1 }
        ]
    },
    'minecraft:bamboo_fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 },
            { red: 0.89, green: 0.8, blue: 0.416, alpha: 1 },
            { red: 0.784, green: 0.694, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:birch_button': {
        hardness: 0.5,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:birch_fence': {
        hardness: 2,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:birch_fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:birch_log': {
        hardness: 2,
        colors: [
            { red: 1, green: 1, blue: 1, alpha: 1 },
            { red: 0.941, green: 0.933, blue: 0.922, alpha: 1 },
            { red: 0.847, green: 0.847, blue: 0.808, alpha: 1 }
        ]
    },
    'minecraft:cherry_button': {
        hardness: 0.5,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:cherry_fence': {
        hardness: 2,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:cherry_fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:cherry_log': {
        hardness: 2,
        colors: [
            { red: 0.188, green: 0.114, blue: 0.161, alpha: 1 },
            { red: 0.231, green: 0.137, blue: 0.176, alpha: 1 },
            { red: 0.153, green: 0.086, blue: 0.125, alpha: 1 }
        ]
    },
    'minecraft:crimson_button': {
        hardness: 0.5,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:crimson_fence': {
        hardness: 2,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:crimson_fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:crimson_stem': {
        hardness: 2,
        colors: [
            { red: 0.322, green: 0.094, blue: 0.063, alpha: 1 },
            { red: 0.267, green: 0.129, blue: 0.192, alpha: 1 },
            { red: 0.294, green: 0.153, blue: 0.216, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_button': {
        hardness: 0.5,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_fence': {
        hardness: 2,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_log': {
        hardness: 2,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:jungle_button': {
        hardness: 0.5,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:jungle_fence': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:jungle_fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:jungle_log': {
        hardness: 2,
        colors: [
            { red: 0.349, green: 0.275, blue: 0.102, alpha: 1 },
            { red: 0.251, green: 0.212, blue: 0.071, alpha: 1 },
            { red: 0.314, green: 0.247, blue: 0.086, alpha: 1 }
        ]
    },
    'minecraft:mangrove_button': {
        hardness: 0.5,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:mangrove_fence': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:mangrove_fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:mangrove_log': {
        hardness: 2,
        colors: [
            { red: 0.306, green: 0.247, blue: 0.153, alpha: 1 },
            { red: 0.353, green: 0.282, blue: 0.173, alpha: 1 },
            { red: 0.404, green: 0.322, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:mushroom_stem': {
        hardness: 2,
        colors: [
            { red: 0.827, green: 0.8, blue: 0.769, alpha: 1 },
            { red: 0.804, green: 0.776, blue: 0.741, alpha: 1 },
            { red: 0.78, green: 0.757, blue: 0.706, alpha: 1 }
        ]
    },
    'minecraft:oak_fence': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:oak_log': {
        hardness: 2,
        colors: [
            { red: 0.455, green: 0.353, blue: 0.212, alpha: 1 },
            { red: 0.569, green: 0.443, blue: 0.259, alpha: 1 },
            { red: 0.373, green: 0.29, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_button': {
        hardness: 0.5,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_fence': {
        hardness: 2,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_log': {
        hardness: 2,
        colors: [
            { red: 0.369, green: 0.325, blue: 0.314, alpha: 1 },
            { red: 0.306, green: 0.263, blue: 0.251, alpha: 1 },
            { red: 0.431, green: 0.392, blue: 0.384, alpha: 1 }
        ]
    },
    'minecraft:spruce_button': {
        hardness: 0.5,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:spruce_fence': {
        hardness: 2,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:spruce_fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:spruce_log': {
        hardness: 2,
        colors: [
            { red: 0.231, green: 0.153, blue: 0.075, alpha: 1 },
            { red: 0.302, green: 0.2, blue: 0.09, alpha: 1 },
            { red: 0.18, green: 0.11, blue: 0.039, alpha: 1 }
        ]
    },
    'minecraft:stripped_acacia_log': {
        hardness: 2,
        colors: [
            { red: 0.698, green: 0.357, blue: 0.231, alpha: 1 },
            { red: 0.71, green: 0.376, blue: 0.243, alpha: 1 },
            { red: 0.588, green: 0.345, blue: 0.216, alpha: 1 }
        ]
    },
    'minecraft:stripped_birch_log': {
        hardness: 2,
        colors: [
            { red: 0.769, green: 0.675, blue: 0.447, alpha: 1 },
            { red: 0.729, green: 0.659, blue: 0.455, alpha: 1 },
            { red: 0.804, green: 0.722, blue: 0.49, alpha: 1 }
        ]
    },
    'minecraft:stripped_cherry_log': {
        hardness: 2,
        colors: [
            { red: 0.851, green: 0.58, blue: 0.6, alpha: 1 },
            { red: 0.863, green: 0.596, blue: 0.62, alpha: 1 },
            { red: 0.839, green: 0.561, blue: 0.576, alpha: 1 }
        ]
    },
    'minecraft:stripped_crimson_stem': {
        hardness: 2,
        colors: [
            { red: 0.537, green: 0.224, blue: 0.357, alpha: 1 },
            { red: 0.588, green: 0.243, blue: 0.384, alpha: 1 },
            { red: 0.502, green: 0.22, blue: 0.325, alpha: 1 }
        ]
    },
    'minecraft:stripped_dark_oak_log': {
        hardness: 2,
        colors: [
            { red: 0.271, green: 0.212, blue: 0.137, alpha: 1 },
            { red: 0.322, green: 0.247, blue: 0.153, alpha: 1 },
            { red: 0.231, green: 0.188, blue: 0.125, alpha: 1 }
        ]
    },
    'minecraft:stripped_jungle_log': {
        hardness: 2,
        colors: [
            { red: 0.706, green: 0.525, blue: 0.353, alpha: 1 },
            { red: 0.733, green: 0.553, blue: 0.38, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:stripped_mangrove_log': {
        hardness: 2,
        colors: [
            { red: 0.478, green: 0.216, blue: 0.192, alpha: 1 },
            { red: 0.478, green: 0.239, blue: 0.184, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.192, alpha: 1 }
        ]
    },
    'minecraft:stripped_oak_log': {
        hardness: 2,
        colors: [
            { red: 0.725, green: 0.584, blue: 0.345, alpha: 1 },
            { red: 0.753, green: 0.616, blue: 0.384, alpha: 1 },
            { red: 0.682, green: 0.557, blue: 0.322, alpha: 1 }
        ]
    },
    'minecraft:stripped_pale_oak_log': {
        hardness: 2,
        colors: [
            { red: 0.973, green: 0.941, blue: 0.941, alpha: 1 },
            { red: 1, green: 0.984, blue: 0.973, alpha: 1 },
            { red: 0.941, green: 0.906, blue: 0.898, alpha: 1 }
        ]
    },
    'minecraft:stripped_spruce_log': {
        hardness: 2,
        colors: [
            { red: 0.275, green: 0.227, blue: 0.125, alpha: 1 },
            { red: 0.325, green: 0.243, blue: 0.141, alpha: 1 },
            { red: 0.302, green: 0.235, blue: 0.133, alpha: 1 }
        ]
    },
    'minecraft:stripped_warped_stem': {
        hardness: 2,
        colors: [
            { red: 0.231, green: 0.6, blue: 0.592, alpha: 1 },
            { red: 0.267, green: 0.631, blue: 0.624, alpha: 1 },
            { red: 0.192, green: 0.553, blue: 0.549, alpha: 1 }
        ]
    },
    'minecraft:warped_button': {
        hardness: 0.5,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:warped_fence': {
        hardness: 2,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:warped_fence_gate': {
        hardness: 2,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:warped_stem': {
        hardness: 2,
        colors: [
            { red: 0.271, green: 0.176, blue: 0.361, alpha: 1 },
            { red: 0.267, green: 0.129, blue: 0.192, alpha: 1 },
            { red: 0.294, green: 0.153, blue: 0.216, alpha: 1 }
        ]
    },
    'minecraft:acacia_leaves': {
        hardness: 0.2,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:acacia_sapling': {
        hardness: 0,
        colors: [
            { red: 0.486, green: 0.369, blue: 0.071, alpha: 1 },
            { red: 0.404, green: 0.494, blue: 0.09, alpha: 1 },
            { red: 0.455, green: 0.549, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:azalea_leaves': {
        hardness: 0.2,
        colors: [
            { red: 0.314, green: 0.412, blue: 0.173, alpha: 1 },
            { red: 0.439, green: 0.573, blue: 0.176, alpha: 1 },
            { red: 0.424, green: 0.502, blue: 0.192, alpha: 1 }
        ]
    },
    'minecraft:azalea_leaves_flowered': {
        hardness: 0.2,
        colors: [
            { red: 0.227, green: 0.298, blue: 0.149, alpha: 1 },
            { red: 0.314, green: 0.412, blue: 0.173, alpha: 1 },
            { red: 0.424, green: 0.502, blue: 0.192, alpha: 1 }
        ]
    },
    'minecraft:bamboo_sapling': {
        hardness: 0,
        colors: [
            { red: 0.396, green: 0.361, blue: 0.118, alpha: 1 },
            { red: 0.592, green: 0.561, blue: 0.329, alpha: 1 },
            { red: 0.341, green: 0.247, blue: 0.122, alpha: 1 }
        ]
    },
    'minecraft:birch_leaves': {
        hardness: 0.2,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:birch_sapling': {
        hardness: 0,
        colors: [
            { red: 0.424, green: 0.62, blue: 0.22, alpha: 1 },
            { red: 0.353, green: 0.494, blue: 0.2, alpha: 1 },
            { red: 0.675, green: 0.749, blue: 0.384, alpha: 1 }
        ]
    },
    'minecraft:black_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.557, green: 0.125, blue: 0.125, alpha: 1 },
            { red: 0.114, green: 0.114, blue: 0.129, alpha: 1 },
            { red: 0.6, green: 0.133, blue: 0.133, alpha: 1 }
        ]
    },
    'minecraft:black_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.145, green: 0.086, blue: 0.063, alpha: 1 },
            { red: 0.145, green: 0.09, blue: 0.067, alpha: 1 },
            { red: 0.145, green: 0.09, blue: 0.063, alpha: 1 }
        ]
    },
    'minecraft:black_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.11, green: 0.11, blue: 0.125, alpha: 1 },
            { red: 0.145, green: 0.145, blue: 0.161, alpha: 1 },
            { red: 0.059, green: 0.063, blue: 0.082, alpha: 1 }
        ]
    },
    'minecraft:blue_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.173, green: 0.18, blue: 0.561, alpha: 1 },
            { red: 0.235, green: 0.267, blue: 0.667, alpha: 1 },
            { red: 0.271, green: 0.467, blue: 0.827, alpha: 1 }
        ]
    },
    'minecraft:blue_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.29, green: 0.231, blue: 0.357, alpha: 1 },
            { red: 0.286, green: 0.227, blue: 0.353, alpha: 1 },
            { red: 0.29, green: 0.235, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:blue_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.243, green: 0.302, blue: 0.698, alpha: 1 },
            { red: 0.231, green: 0.251, blue: 0.651, alpha: 1 },
            { red: 0.192, green: 0.2, blue: 0.588, alpha: 1 }
        ]
    },
    'minecraft:brown_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.514, green: 0.329, blue: 0.196, alpha: 1 },
            { red: 0.804, green: 0.569, blue: 0.486, alpha: 1 },
            { red: 0.643, green: 0.463, blue: 0.298, alpha: 1 }
        ]
    },
    'minecraft:brown_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.302, green: 0.204, blue: 0.141, alpha: 1 },
            { red: 0.298, green: 0.196, blue: 0.137, alpha: 1 },
            { red: 0.302, green: 0.2, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:brown_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.494, green: 0.314, blue: 0.184, alpha: 1 },
            { red: 0.514, green: 0.329, blue: 0.196, alpha: 1 },
            { red: 0.427, green: 0.267, blue: 0.149, alpha: 1 }
        ]
    },
    'minecraft:cherry_leaves': {
        hardness: 0.2,
        colors: [
            { red: 0.988, green: 0.796, blue: 0.906, alpha: 1 },
            { red: 0.961, green: 0.855, blue: 0.937, alpha: 1 },
            { red: 0.922, green: 0.573, blue: 0.757, alpha: 1 }
        ]
    },
    'minecraft:cherry_sapling': {
        hardness: 0,
        colors: [
            { red: 0.969, green: 0.725, blue: 0.863, alpha: 1 },
            { red: 0.153, green: 0.086, blue: 0.125, alpha: 1 },
            { red: 0.937, green: 0.655, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:cyan_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.082, green: 0.467, blue: 0.533, alpha: 1 },
            { red: 0.212, green: 0.224, blue: 0.239, alpha: 1 },
            { red: 0.086, green: 0.612, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:cyan_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.337, green: 0.353, blue: 0.353, alpha: 1 },
            { red: 0.333, green: 0.349, blue: 0.353, alpha: 1 },
            { red: 0.341, green: 0.361, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:cyan_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.086, green: 0.588, blue: 0.596, alpha: 1 },
            { red: 0.086, green: 0.608, blue: 0.612, alpha: 1 },
            { red: 0.082, green: 0.498, blue: 0.549, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_leaves': {
        hardness: 0.2,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_sapling': {
        hardness: 0,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:gray_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.212, green: 0.224, blue: 0.239, alpha: 1 },
            { red: 0.278, green: 0.31, blue: 0.322, alpha: 1 },
            { red: 0.357, green: 0.424, blue: 0.443, alpha: 1 }
        ]
    },
    'minecraft:gray_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.227, green: 0.169, blue: 0.141, alpha: 1 },
            { red: 0.224, green: 0.165, blue: 0.137, alpha: 1 },
            { red: 0.224, green: 0.161, blue: 0.137, alpha: 1 }
        ]
    },
    'minecraft:gray_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.278, green: 0.31, blue: 0.322, alpha: 1 },
            { red: 0.271, green: 0.298, blue: 0.31, alpha: 1 },
            { red: 0.267, green: 0.294, blue: 0.306, alpha: 1 }
        ]
    },
    'minecraft:green_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.286, green: 0.357, blue: 0.141, alpha: 1 },
            { red: 0.447, green: 0.608, blue: 0.141, alpha: 1 },
            { red: 0.369, green: 0.486, blue: 0.086, alpha: 1 }
        ]
    },
    'minecraft:green_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.294, green: 0.322, blue: 0.161, alpha: 1 },
            { red: 0.294, green: 0.322, blue: 0.165, alpha: 1 },
            { red: 0.298, green: 0.325, blue: 0.165, alpha: 1 }
        ]
    },
    'minecraft:green_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.396, green: 0.525, blue: 0.098, alpha: 1 },
            { red: 0.314, green: 0.4, blue: 0.118, alpha: 1 },
            { red: 0.318, green: 0.408, blue: 0.114, alpha: 1 }
        ]
    },
    'minecraft:jungle_leaves': {
        hardness: 0.2,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:jungle_sapling': {
        hardness: 0,
        colors: [
            { red: 0.169, green: 0.29, blue: 0.047, alpha: 1 },
            { red: 0.184, green: 0.188, blue: 0.031, alpha: 1 },
            { red: 0.173, green: 0.424, blue: 0.094, alpha: 1 }
        ]
    },
    'minecraft:light_blue_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.227, green: 0.702, blue: 0.855, alpha: 1 },
            { red: 0.137, green: 0.537, blue: 0.78, alpha: 1 },
            { red: 0.302, green: 0.725, blue: 0.867, alpha: 1 }
        ]
    },
    'minecraft:light_blue_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.439, green: 0.424, blue: 0.541, alpha: 1 },
            { red: 0.447, green: 0.424, blue: 0.541, alpha: 1 },
            { red: 0.435, green: 0.42, blue: 0.537, alpha: 1 }
        ]
    },
    'minecraft:light_blue_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.306, green: 0.773, blue: 0.906, alpha: 1 },
            { red: 0.286, green: 0.761, blue: 0.894, alpha: 1 },
            { red: 0.192, green: 0.647, blue: 0.827, alpha: 1 }
        ]
    },
    'minecraft:light_gray_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.529, green: 0.42, blue: 0.384, alpha: 1 },
            { red: 0.522, green: 0.412, blue: 0.376, alpha: 1 },
            { red: 0.529, green: 0.416, blue: 0.38, alpha: 1 }
        ]
    },
    'minecraft:light_gray_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.6, green: 0.6, blue: 0.576, alpha: 1 },
            { red: 0.616, green: 0.616, blue: 0.592, alpha: 1 },
            { red: 0.529, green: 0.529, blue: 0.498, alpha: 1 }
        ]
    },
    'minecraft:lime_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.502, green: 0.78, blue: 0.122, alpha: 1 },
            { red: 0.667, green: 0.914, blue: 0.396, alpha: 1 },
            { red: 0.349, green: 0.627, blue: 0.09, alpha: 1 }
        ]
    },
    'minecraft:lime_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.404, green: 0.459, blue: 0.204, alpha: 1 },
            { red: 0.408, green: 0.467, blue: 0.212, alpha: 1 },
            { red: 0.404, green: 0.455, blue: 0.2, alpha: 1 }
        ]
    },
    'minecraft:lime_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.525, green: 0.8, blue: 0.149, alpha: 1 },
            { red: 0.486, green: 0.765, blue: 0.106, alpha: 1 },
            { red: 0.404, green: 0.694, blue: 0.094, alpha: 1 }
        ]
    },
    'minecraft:magenta_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.78, green: 0.306, blue: 0.741, alpha: 1 },
            { red: 0.867, green: 0.408, blue: 0.855, alpha: 1 },
            { red: 0.957, green: 0.71, blue: 0.796, alpha: 1 }
        ]
    },
    'minecraft:magenta_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.584, green: 0.341, blue: 0.424, alpha: 1 },
            { red: 0.584, green: 0.337, blue: 0.42, alpha: 1 },
            { red: 0.576, green: 0.337, blue: 0.42, alpha: 1 }
        ]
    },
    'minecraft:magenta_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.839, green: 0.376, blue: 0.82, alpha: 1 },
            { red: 0.792, green: 0.322, blue: 0.757, alpha: 1 },
            { red: 0.698, green: 0.224, blue: 0.659, alpha: 1 }
        ]
    },
    'minecraft:mangrove_leaves': {
        hardness: 0.2,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:oak_leaves': {
        hardness: 0.2,
        colors: [
            { red: 0.227, green: 0.298, blue: 0.149, alpha: 1 },
            { red: 0.314, green: 0.412, blue: 0.173, alpha: 1 },
            { red: 0.424, green: 0.502, blue: 0.192, alpha: 1 }
        ]
    },
    'minecraft:oak_sapling': {
        hardness: 0,
        colors: [
            { red: 0.439, green: 0.325, blue: 0.18, alpha: 1 },
            { red: 0.251, green: 0.561, blue: 0.184, alpha: 1 },
            { red: 0.341, green: 0.678, blue: 0.247, alpha: 1 }
        ]
    },
    'minecraft:orange_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.976, green: 0.502, blue: 0.114, alpha: 1 },
            { red: 0.882, green: 0.38, blue: 0, alpha: 1 },
            { red: 0.086, green: 0.612, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:orange_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.624, green: 0.322, blue: 0.141, alpha: 1 },
            { red: 0.635, green: 0.325, blue: 0.149, alpha: 1 },
            { red: 0.627, green: 0.325, blue: 0.145, alpha: 1 }
        ]
    },
    'minecraft:orange_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.976, green: 0.576, blue: 0.169, alpha: 1 },
            { red: 0.976, green: 0.518, blue: 0.125, alpha: 1 },
            { red: 0.925, green: 0.427, blue: 0.043, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_leaves': {
        hardness: 0.2,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_sapling': {
        hardness: 0,
        colors: [
            { red: 0.478, green: 0.502, blue: 0.467, alpha: 1 },
            { red: 0.537, green: 0.573, blue: 0.529, alpha: 1 },
            { red: 0.263, green: 0.231, blue: 0.224, alpha: 1 }
        ]
    },
    'minecraft:pink_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.957, green: 0.71, blue: 0.796, alpha: 1 },
            { red: 0.953, green: 0.545, blue: 0.667, alpha: 1 },
            { red: 0.851, green: 0.443, blue: 0.596, alpha: 1 }
        ]
    },
    'minecraft:pink_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.627, green: 0.302, blue: 0.306, alpha: 1 },
            { red: 0.624, green: 0.298, blue: 0.302, alpha: 1 },
            { red: 0.635, green: 0.306, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:pink_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.957, green: 0.698, blue: 0.788, alpha: 1 },
            { red: 0.957, green: 0.655, blue: 0.753, alpha: 1 },
            { red: 0.925, green: 0.494, blue: 0.631, alpha: 1 }
        ]
    },
    'minecraft:purple_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.537, green: 0.196, blue: 0.722, alpha: 1 },
            { red: 0.173, green: 0.173, blue: 0.196, alpha: 1 },
            { red: 0.392, green: 0.122, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:purple_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.451, green: 0.267, blue: 0.329, alpha: 1 },
            { red: 0.463, green: 0.275, blue: 0.337, alpha: 1 },
            { red: 0.463, green: 0.271, blue: 0.337, alpha: 1 }
        ]
    },
    'minecraft:purple_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.592, green: 0.263, blue: 0.804, alpha: 1 },
            { red: 0.525, green: 0.188, blue: 0.71, alpha: 1 },
            { red: 0.443, green: 0.141, blue: 0.647, alpha: 1 }
        ]
    },
    'minecraft:red_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.69, green: 0.18, blue: 0.149, alpha: 1 },
            { red: 0.808, green: 0.294, blue: 0.267, alpha: 1 },
            { red: 0.557, green: 0.125, blue: 0.125, alpha: 1 }
        ]
    },
    'minecraft:red_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.553, green: 0.231, blue: 0.18, alpha: 1 },
            { red: 0.557, green: 0.239, blue: 0.184, alpha: 1 },
            { red: 0.557, green: 0.235, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:red_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.722, green: 0.204, blue: 0.173, alpha: 1 },
            { red: 0.6, green: 0.141, blue: 0.129, alpha: 1 },
            { red: 0.675, green: 0.173, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:silver_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.8, green: 0.816, blue: 0.824, alpha: 1 },
            { red: 0.6, green: 0.6, blue: 0.6, alpha: 1 },
            { red: 0.376, green: 0.447, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:spruce_leaves': {
        hardness: 0.2,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:spruce_sapling': {
        hardness: 0,
        colors: [
            { red: 0.133, green: 0.208, blue: 0.133, alpha: 1 },
            { red: 0.18, green: 0.286, blue: 0.18, alpha: 1 },
            { red: 0.224, green: 0.353, blue: 0.224, alpha: 1 }
        ]
    },
    'minecraft:white_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.976, green: 1, blue: 0.996, alpha: 1 },
            { red: 0.137, green: 0.537, blue: 0.78, alpha: 1 },
            { red: 0.996, green: 0.847, blue: 0.239, alpha: 1 }
        ]
    },
    'minecraft:white_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.824, green: 0.694, blue: 0.631, alpha: 1 },
            { red: 0.82, green: 0.694, blue: 0.631, alpha: 1 },
            { red: 0.812, green: 0.686, blue: 0.627, alpha: 1 }
        ]
    },
    'minecraft:white_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.996, green: 0.996, blue: 0.996, alpha: 1 },
            { red: 0.98, green: 0.98, blue: 0.98, alpha: 1 },
            { red: 0.871, green: 0.886, blue: 0.89, alpha: 1 }
        ]
    },
    'minecraft:yellow_glazed_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 1, green: 0.925, blue: 0.616, alpha: 1 },
            { red: 0.949, green: 0.69, blue: 0.082, alpha: 1 },
            { red: 0.643, green: 0.463, blue: 0.298, alpha: 1 }
        ]
    },
    'minecraft:yellow_terracotta': {
        hardness: 1.25,
        colors: [
            { red: 0.722, green: 0.514, blue: 0.133, alpha: 1 },
            { red: 0.729, green: 0.525, blue: 0.141, alpha: 1 },
            { red: 0.729, green: 0.522, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:yellow_wool': {
        hardness: 0.8,
        colors: [
            { red: 0.996, green: 0.851, blue: 0.247, alpha: 1 },
            { red: 0.992, green: 0.831, blue: 0.208, alpha: 1 },
            { red: 0.965, green: 0.741, blue: 0.122, alpha: 1 }
        ]
    },
    'minecraft:black_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.098, green: 0.098, blue: 0.098, alpha: 1 }]
    },
    'minecraft:black_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.098, green: 0.098, blue: 0.098, alpha: 1 }]
    },
    'minecraft:blue_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.2, green: 0.298, blue: 0.698, alpha: 1 }]
    },
    'minecraft:blue_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.2, green: 0.298, blue: 0.698, alpha: 1 }]
    },
    'minecraft:brown_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.4, green: 0.298, blue: 0.2, alpha: 1 }]
    },
    'minecraft:brown_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.4, green: 0.298, blue: 0.2, alpha: 1 }]
    },
    'minecraft:cyan_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.298, green: 0.498, blue: 0.6, alpha: 1 }]
    },
    'minecraft:cyan_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.298, green: 0.498, blue: 0.6, alpha: 1 }]
    },
    'minecraft:gray_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.298, green: 0.298, blue: 0.298, alpha: 1 }]
    },
    'minecraft:gray_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.298, green: 0.298, blue: 0.298, alpha: 1 }]
    },
    'minecraft:green_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.4, green: 0.498, blue: 0.2, alpha: 1 }]
    },
    'minecraft:green_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.4, green: 0.498, blue: 0.2, alpha: 1 }]
    },
    'minecraft:light_blue_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.4, green: 0.6, blue: 0.847, alpha: 1 }]
    },
    'minecraft:light_blue_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.4, green: 0.6, blue: 0.847, alpha: 1 }]
    },
    'minecraft:light_gray_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.6, green: 0.6, blue: 0.6, alpha: 1 }]
    },
    'minecraft:light_gray_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.6, green: 0.6, blue: 0.6, alpha: 1 }]
    },
    'minecraft:lime_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.498, green: 0.8, blue: 0.098, alpha: 1 }]
    },
    'minecraft:lime_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.498, green: 0.8, blue: 0.098, alpha: 1 }]
    },
    'minecraft:magenta_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.698, green: 0.298, blue: 0.847, alpha: 1 }]
    },
    'minecraft:magenta_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.698, green: 0.298, blue: 0.847, alpha: 1 }]
    },
    'minecraft:orange_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.847, green: 0.498, blue: 0.2, alpha: 1 }]
    },
    'minecraft:orange_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.847, green: 0.498, blue: 0.2, alpha: 1 }]
    },
    'minecraft:pink_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.949, green: 0.498, blue: 0.647, alpha: 1 }]
    },
    'minecraft:pink_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.949, green: 0.498, blue: 0.647, alpha: 1 }]
    },
    'minecraft:purple_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.498, green: 0.247, blue: 0.698, alpha: 1 }]
    },
    'minecraft:purple_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.498, green: 0.247, blue: 0.698, alpha: 1 }]
    },
    'minecraft:red_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.6, green: 0.2, blue: 0.2, alpha: 1 }]
    },
    'minecraft:red_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.6, green: 0.2, blue: 0.2, alpha: 1 }]
    },
    'minecraft:white_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 1, green: 1, blue: 1, alpha: 1 }]
    },
    'minecraft:white_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 1, green: 1, blue: 1, alpha: 1 }]
    },
    'minecraft:yellow_stained_glass': {
        hardness: 0.3,
        colors: [{ red: 0.898, green: 0.898, blue: 0.2, alpha: 1 }]
    },
    'minecraft:yellow_stained_glass_pane': {
        hardness: 0.3,
        colors: [{ red: 0.898, green: 0.898, blue: 0.2, alpha: 1 }]
    },
    'minecraft:black_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.122, green: 0.122, blue: 0.137, alpha: 1 },
            { red: 0.09, green: 0.09, blue: 0.106, alpha: 1 },
            { red: 0.059, green: 0.063, blue: 0.082, alpha: 1 }
        ]
    },
    'minecraft:blue_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.2, green: 0.208, blue: 0.608, alpha: 1 },
            { red: 0.161, green: 0.169, blue: 0.537, alpha: 1 },
            { red: 0.196, green: 0.208, blue: 0.604, alpha: 1 }
        ]
    },
    'minecraft:brown_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.451, green: 0.282, blue: 0.157, alpha: 1 },
            { red: 0.404, green: 0.251, blue: 0.133, alpha: 1 },
            { red: 0.447, green: 0.278, blue: 0.157, alpha: 1 }
        ]
    },
    'minecraft:cyan_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.086, green: 0.529, blue: 0.573, alpha: 1 },
            { red: 0.082, green: 0.467, blue: 0.533, alpha: 1 },
            { red: 0.086, green: 0.525, blue: 0.569, alpha: 1 }
        ]
    },
    'minecraft:gray_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.243, green: 0.259, blue: 0.275, alpha: 1 },
            { red: 0.212, green: 0.224, blue: 0.239, alpha: 1 },
            { red: 0.239, green: 0.259, blue: 0.271, alpha: 1 }
        ]
    },
    'minecraft:green_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.329, green: 0.427, blue: 0.11, alpha: 1 },
            { red: 0.302, green: 0.38, blue: 0.133, alpha: 1 },
            { red: 0.329, green: 0.424, blue: 0.114, alpha: 1 }
        ]
    },
    'minecraft:light_blue_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.231, green: 0.706, blue: 0.859, alpha: 1 },
            { red: 0.173, green: 0.616, blue: 0.827, alpha: 1 },
            { red: 0.227, green: 0.702, blue: 0.855, alpha: 1 }
        ]
    },
    'minecraft:light_gray_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.549, green: 0.549, blue: 0.514, alpha: 1 },
            { red: 0.478, green: 0.478, blue: 0.439, alpha: 1 },
            { red: 0.545, green: 0.545, blue: 0.51, alpha: 1 }
        ]
    },
    'minecraft:lime_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.443, green: 0.737, blue: 0.094, alpha: 1 },
            { red: 0.38, green: 0.678, blue: 0.098, alpha: 1 },
            { red: 0.435, green: 0.733, blue: 0.094, alpha: 1 }
        ]
    },
    'minecraft:magenta_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.729, green: 0.247, blue: 0.686, alpha: 1 },
            { red: 0.671, green: 0.192, blue: 0.631, alpha: 1 },
            { red: 0.725, green: 0.243, blue: 0.682, alpha: 1 }
        ]
    },
    'minecraft:orange_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.961, green: 0.455, blue: 0.063, alpha: 1 },
            { red: 0.922, green: 0.408, blue: 0.016, alpha: 1 },
            { red: 0.957, green: 0.451, blue: 0.059, alpha: 1 }
        ]
    },
    'minecraft:pink_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.953, green: 0.545, blue: 0.667, alpha: 1 },
            { red: 0.894, green: 0.447, blue: 0.604, alpha: 1 },
            { red: 0.949, green: 0.537, blue: 0.659, alpha: 1 }
        ]
    },
    'minecraft:purple_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.455, green: 0.149, blue: 0.663, alpha: 1 },
            { red: 0.384, green: 0.118, blue: 0.604, alpha: 1 },
            { red: 0.447, green: 0.145, blue: 0.659, alpha: 1 }
        ]
    },
    'minecraft:red_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.612, green: 0.145, blue: 0.133, alpha: 1 },
            { red: 0.529, green: 0.114, blue: 0.118, alpha: 1 },
            { red: 0.604, green: 0.141, blue: 0.133, alpha: 1 }
        ]
    },
    'minecraft:undyed_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.592, green: 0.412, blue: 0.592, alpha: 1 },
            { red: 0.592, green: 0.404, blue: 0.592, alpha: 1 },
            { red: 0.592, green: 0.416, blue: 0.592, alpha: 1 }
        ]
    },
    'minecraft:white_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.902, green: 0.918, blue: 0.918, alpha: 1 },
            { red: 0.835, green: 0.855, blue: 0.859, alpha: 1 },
            { red: 0.894, green: 0.914, blue: 0.914, alpha: 1 }
        ]
    },
    'minecraft:yellow_shulker_box': {
        hardness: 2,
        colors: [
            { red: 0.988, green: 0.78, blue: 0.141, alpha: 1 },
            { red: 0.973, green: 0.725, blue: 0.102, alpha: 1 },
            { red: 0.988, green: 0.776, blue: 0.137, alpha: 1 }
        ]
    },
    'minecraft:black_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.102, green: 0.094, blue: 0.153, alpha: 1 },
            { red: 0.153, green: 0.149, blue: 0.239, alpha: 1 },
            { red: 0.22, green: 0.216, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:black_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:black_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.11, green: 0.11, blue: 0.125, alpha: 1 },
            { red: 0.145, green: 0.145, blue: 0.161, alpha: 1 },
            { red: 0.059, green: 0.063, blue: 0.082, alpha: 1 }
        ]
    },
    'minecraft:black_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.035, green: 0.043, blue: 0.063, alpha: 1 },
            { red: 0.031, green: 0.039, blue: 0.059, alpha: 1 },
            { red: 0.027, green: 0.035, blue: 0.055, alpha: 1 }
        ]
    },
    'minecraft:black_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.11, green: 0.118, blue: 0.133, alpha: 1 },
            { red: 0.098, green: 0.106, blue: 0.122, alpha: 1 },
            { red: 0.071, green: 0.082, blue: 0.106, alpha: 1 }
        ]
    },
    'minecraft:blue_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.208, green: 0.278, blue: 0.604, alpha: 1 },
            { red: 0.227, green: 0.302, blue: 0.647, alpha: 1 },
            { red: 0.271, green: 0.353, blue: 0.745, alpha: 1 }
        ]
    },
    'minecraft:blue_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:blue_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.243, green: 0.302, blue: 0.698, alpha: 1 },
            { red: 0.231, green: 0.251, blue: 0.651, alpha: 1 },
            { red: 0.192, green: 0.2, blue: 0.588, alpha: 1 }
        ]
    },
    'minecraft:blue_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.173, green: 0.18, blue: 0.561, alpha: 1 },
            { red: 0.176, green: 0.184, blue: 0.565, alpha: 1 },
            { red: 0.18, green: 0.188, blue: 0.565, alpha: 1 }
        ]
    },
    'minecraft:blue_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.271, green: 0.282, blue: 0.647, alpha: 1 },
            { red: 0.259, green: 0.271, blue: 0.631, alpha: 1 },
            { red: 0.259, green: 0.271, blue: 0.635, alpha: 1 }
        ]
    },
    'minecraft:brown_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.392, green: 0.239, blue: 0.129, alpha: 1 },
            { red: 0.447, green: 0.278, blue: 0.157, alpha: 1 },
            { red: 0.561, green: 0.357, blue: 0.208, alpha: 1 }
        ]
    },
    'minecraft:brown_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:brown_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.494, green: 0.314, blue: 0.184, alpha: 1 },
            { red: 0.514, green: 0.329, blue: 0.196, alpha: 1 },
            { red: 0.427, green: 0.267, blue: 0.149, alpha: 1 }
        ]
    },
    'minecraft:brown_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.38, green: 0.235, blue: 0.125, alpha: 1 },
            { red: 0.376, green: 0.231, blue: 0.122, alpha: 1 },
            { red: 0.373, green: 0.231, blue: 0.122, alpha: 1 }
        ]
    },
    'minecraft:brown_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.486, green: 0.322, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.318, blue: 0.196, alpha: 1 },
            { red: 0.475, green: 0.318, blue: 0.2, alpha: 1 }
        ]
    },
    'minecraft:candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:cyan_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.059, green: 0.412, blue: 0.408, alpha: 1 },
            { red: 0.063, green: 0.533, blue: 0.529, alpha: 1 },
            { red: 0.071, green: 0.62, blue: 0.616, alpha: 1 }
        ]
    },
    'minecraft:cyan_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:cyan_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.086, green: 0.588, blue: 0.596, alpha: 1 },
            { red: 0.086, green: 0.608, blue: 0.612, alpha: 1 },
            { red: 0.082, green: 0.498, blue: 0.549, alpha: 1 }
        ]
    },
    'minecraft:cyan_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.082, green: 0.467, blue: 0.533, alpha: 1 },
            { red: 0.086, green: 0.471, blue: 0.537, alpha: 1 },
            { red: 0.082, green: 0.463, blue: 0.529, alpha: 1 }
        ]
    },
    'minecraft:cyan_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.145, green: 0.549, blue: 0.604, alpha: 1 },
            { red: 0.145, green: 0.553, blue: 0.604, alpha: 1 },
            { red: 0.145, green: 0.565, blue: 0.608, alpha: 1 }
        ]
    },
    'minecraft:gray_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.29, green: 0.349, blue: 0.353, alpha: 1 },
            { red: 0.322, green: 0.38, blue: 0.384, alpha: 1 },
            { red: 0.384, green: 0.443, blue: 0.451, alpha: 1 }
        ]
    },
    'minecraft:gray_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:gray_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.278, green: 0.31, blue: 0.322, alpha: 1 },
            { red: 0.271, green: 0.298, blue: 0.31, alpha: 1 },
            { red: 0.267, green: 0.294, blue: 0.306, alpha: 1 }
        ]
    },
    'minecraft:gray_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.216, green: 0.227, blue: 0.243, alpha: 1 },
            { red: 0.212, green: 0.224, blue: 0.239, alpha: 1 },
            { red: 0.22, green: 0.231, blue: 0.247, alpha: 1 }
        ]
    },
    'minecraft:gray_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.298, green: 0.314, blue: 0.325, alpha: 1 },
            { red: 0.29, green: 0.302, blue: 0.318, alpha: 1 },
            { red: 0.314, green: 0.325, blue: 0.341, alpha: 1 }
        ]
    },
    'minecraft:green_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.247, green: 0.325, blue: 0.071, alpha: 1 },
            { red: 0.29, green: 0.388, blue: 0.075, alpha: 1 },
            { red: 0.376, green: 0.506, blue: 0.086, alpha: 1 }
        ]
    },
    'minecraft:green_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:green_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.396, green: 0.525, blue: 0.098, alpha: 1 },
            { red: 0.314, green: 0.4, blue: 0.118, alpha: 1 },
            { red: 0.318, green: 0.408, blue: 0.114, alpha: 1 }
        ]
    },
    'minecraft:green_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.286, green: 0.357, blue: 0.141, alpha: 1 },
            { red: 0.29, green: 0.361, blue: 0.145, alpha: 1 },
            { red: 0.286, green: 0.353, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:green_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.365, green: 0.443, blue: 0.188, alpha: 1 },
            { red: 0.365, green: 0.435, blue: 0.196, alpha: 1 },
            { red: 0.369, green: 0.447, blue: 0.184, alpha: 1 }
        ]
    },
    'minecraft:light_blue_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.125, green: 0.522, blue: 0.773, alpha: 1 },
            { red: 0.125, green: 0.553, blue: 0.804, alpha: 1 },
            { red: 0.161, green: 0.631, blue: 0.835, alpha: 1 }
        ]
    },
    'minecraft:light_blue_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:light_blue_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.306, green: 0.773, blue: 0.906, alpha: 1 },
            { red: 0.286, green: 0.761, blue: 0.894, alpha: 1 },
            { red: 0.192, green: 0.647, blue: 0.827, alpha: 1 }
        ]
    },
    'minecraft:light_blue_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.137, green: 0.537, blue: 0.78, alpha: 1 },
            { red: 0.141, green: 0.541, blue: 0.784, alpha: 1 },
            { red: 0.137, green: 0.533, blue: 0.776, alpha: 1 }
        ]
    },
    'minecraft:light_blue_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.29, green: 0.714, blue: 0.831, alpha: 1 },
            { red: 0.271, green: 0.682, blue: 0.82, alpha: 1 },
            { red: 0.263, green: 0.675, blue: 0.812, alpha: 1 }
        ]
    },
    'minecraft:light_gray_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.416, green: 0.427, blue: 0.384, alpha: 1 },
            { red: 0.49, green: 0.498, blue: 0.467, alpha: 1 },
            { red: 0.576, green: 0.584, blue: 0.549, alpha: 1 }
        ]
    },
    'minecraft:light_gray_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:light_gray_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.6, green: 0.6, blue: 0.576, alpha: 1 },
            { red: 0.616, green: 0.616, blue: 0.592, alpha: 1 },
            { red: 0.529, green: 0.529, blue: 0.498, alpha: 1 }
        ]
    },
    'minecraft:light_gray_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.49, green: 0.49, blue: 0.451, alpha: 1 },
            { red: 0.494, green: 0.494, blue: 0.455, alpha: 1 },
            { red: 0.486, green: 0.486, blue: 0.447, alpha: 1 }
        ]
    },
    'minecraft:light_gray_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.616, green: 0.616, blue: 0.592, alpha: 1 },
            { red: 0.576, green: 0.576, blue: 0.545, alpha: 1 },
            { red: 0.6, green: 0.6, blue: 0.573, alpha: 1 }
        ]
    },
    'minecraft:lime_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.353, green: 0.647, blue: 0.063, alpha: 1 },
            { red: 0.384, green: 0.714, blue: 0.094, alpha: 1 },
            { red: 0.482, green: 0.776, blue: 0.094, alpha: 1 }
        ]
    },
    'minecraft:lime_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:lime_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.525, green: 0.8, blue: 0.149, alpha: 1 },
            { red: 0.486, green: 0.765, blue: 0.106, alpha: 1 },
            { red: 0.404, green: 0.694, blue: 0.094, alpha: 1 }
        ]
    },
    'minecraft:lime_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.369, green: 0.663, blue: 0.094, alpha: 1 },
            { red: 0.373, green: 0.667, blue: 0.098, alpha: 1 },
            { red: 0.365, green: 0.659, blue: 0.094, alpha: 1 }
        ]
    },
    'minecraft:lime_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.478, green: 0.729, blue: 0.157, alpha: 1 },
            { red: 0.486, green: 0.737, blue: 0.157, alpha: 1 },
            { red: 0.494, green: 0.749, blue: 0.161, alpha: 1 }
        ]
    },
    'minecraft:magenta_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.612, green: 0.157, blue: 0.58, alpha: 1 },
            { red: 0.643, green: 0.173, blue: 0.612, alpha: 1 },
            { red: 0.741, green: 0.235, blue: 0.706, alpha: 1 }
        ]
    },
    'minecraft:magenta_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:magenta_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.839, green: 0.376, blue: 0.82, alpha: 1 },
            { red: 0.792, green: 0.322, blue: 0.757, alpha: 1 },
            { red: 0.698, green: 0.224, blue: 0.659, alpha: 1 }
        ]
    },
    'minecraft:magenta_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.663, green: 0.188, blue: 0.624, alpha: 1 },
            { red: 0.667, green: 0.192, blue: 0.627, alpha: 1 },
            { red: 0.667, green: 0.196, blue: 0.627, alpha: 1 }
        ]
    },
    'minecraft:magenta_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.773, green: 0.357, blue: 0.737, alpha: 1 },
            { red: 0.733, green: 0.286, blue: 0.698, alpha: 1 },
            { red: 0.733, green: 0.298, blue: 0.698, alpha: 1 }
        ]
    },
    'minecraft:orange_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.835, green: 0.349, blue: 0, alpha: 1 },
            { red: 0.902, green: 0.396, blue: 0, alpha: 1 },
            { red: 1, green: 0.506, blue: 0.094, alpha: 1 }
        ]
    },
    'minecraft:orange_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:orange_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.976, green: 0.576, blue: 0.169, alpha: 1 },
            { red: 0.976, green: 0.518, blue: 0.125, alpha: 1 },
            { red: 0.925, green: 0.427, blue: 0.043, alpha: 1 }
        ]
    },
    'minecraft:orange_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.882, green: 0.38, blue: 0, alpha: 1 },
            { red: 0.875, green: 0.376, blue: 0, alpha: 1 },
            { red: 0.882, green: 0.384, blue: 0.008, alpha: 1 }
        ]
    },
    'minecraft:orange_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.871, green: 0.475, blue: 0.075, alpha: 1 },
            { red: 0.894, green: 0.537, blue: 0.157, alpha: 1 },
            { red: 0.875, green: 0.49, blue: 0.098, alpha: 1 }
        ]
    },
    'minecraft:pink_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.773, green: 0.349, blue: 0.514, alpha: 1 },
            { red: 0.871, green: 0.396, blue: 0.58, alpha: 1 },
            { red: 0.965, green: 0.537, blue: 0.675, alpha: 1 }
        ]
    },
    'minecraft:pink_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:pink_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.957, green: 0.698, blue: 0.788, alpha: 1 },
            { red: 0.957, green: 0.655, blue: 0.753, alpha: 1 },
            { red: 0.925, green: 0.494, blue: 0.631, alpha: 1 }
        ]
    },
    'minecraft:pink_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.839, green: 0.396, blue: 0.561, alpha: 1 },
            { red: 0.835, green: 0.392, blue: 0.557, alpha: 1 },
            { red: 0.839, green: 0.4, blue: 0.565, alpha: 1 }
        ]
    },
    'minecraft:pink_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.902, green: 0.584, blue: 0.702, alpha: 1 },
            { red: 0.867, green: 0.522, blue: 0.659, alpha: 1 },
            { red: 0.898, green: 0.58, blue: 0.698, alpha: 1 }
        ]
    },
    'minecraft:purple_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.384, green: 0.11, blue: 0.612, alpha: 1 },
            { red: 0.416, green: 0.141, blue: 0.643, alpha: 1 },
            { red: 0.514, green: 0.173, blue: 0.706, alpha: 1 }
        ]
    },
    'minecraft:purple_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:purple_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.592, green: 0.263, blue: 0.804, alpha: 1 },
            { red: 0.525, green: 0.188, blue: 0.71, alpha: 1 },
            { red: 0.443, green: 0.141, blue: 0.647, alpha: 1 }
        ]
    },
    'minecraft:purple_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.396, green: 0.125, blue: 0.616, alpha: 1 },
            { red: 0.392, green: 0.122, blue: 0.612, alpha: 1 },
            { red: 0.396, green: 0.129, blue: 0.616, alpha: 1 }
        ]
    },
    'minecraft:purple_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.486, green: 0.2, blue: 0.675, alpha: 1 },
            { red: 0.502, green: 0.212, blue: 0.686, alpha: 1 },
            { red: 0.498, green: 0.204, blue: 0.686, alpha: 1 }
        ]
    },
    'minecraft:red_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.565, green: 0.129, blue: 0.125, alpha: 1 },
            { red: 0.635, green: 0.153, blue: 0.133, alpha: 1 },
            { red: 0.71, green: 0.192, blue: 0.161, alpha: 1 }
        ]
    },
    'minecraft:red_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:red_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.722, green: 0.204, blue: 0.173, alpha: 1 },
            { red: 0.6, green: 0.141, blue: 0.129, alpha: 1 },
            { red: 0.675, green: 0.173, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:red_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.557, green: 0.125, blue: 0.125, alpha: 1 },
            { red: 0.561, green: 0.129, blue: 0.129, alpha: 1 },
            { red: 0.561, green: 0.133, blue: 0.133, alpha: 1 }
        ]
    },
    'minecraft:red_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.643, green: 0.2, blue: 0.196, alpha: 1 },
            { red: 0.651, green: 0.204, blue: 0.196, alpha: 1 },
            { red: 0.647, green: 0.204, blue: 0.2, alpha: 1 }
        ]
    },
    'minecraft:white_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.78, green: 0.827, blue: 0.827, alpha: 1 },
            { red: 0.878, green: 0.898, blue: 0.898, alpha: 1 },
            { red: 0.973, green: 0.973, blue: 0.973, alpha: 1 }
        ]
    },
    'minecraft:white_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:white_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.996, green: 0.996, blue: 0.996, alpha: 1 },
            { red: 0.98, green: 0.98, blue: 0.98, alpha: 1 },
            { red: 0.871, green: 0.886, blue: 0.89, alpha: 1 }
        ]
    },
    'minecraft:white_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.812, green: 0.835, blue: 0.839, alpha: 1 },
            { red: 0.816, green: 0.839, blue: 0.843, alpha: 1 },
            { red: 0.808, green: 0.831, blue: 0.835, alpha: 1 }
        ]
    },
    'minecraft:white_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.878, green: 0.886, blue: 0.886, alpha: 1 },
            { red: 0.886, green: 0.894, blue: 0.894, alpha: 1 },
            { red: 0.894, green: 0.902, blue: 0.902, alpha: 1 }
        ]
    },
    'minecraft:yellow_candle': {
        hardness: 0.1,
        colors: [
            { red: 0.773, green: 0.596, blue: 0.145, alpha: 1 },
            { red: 0.855, green: 0.671, blue: 0.204, alpha: 1 },
            { red: 1, green: 0.8, blue: 0.294, alpha: 1 }
        ]
    },
    'minecraft:yellow_candle_cake': {
        hardness: 0.5,
        colors: [
            { red: 1, green: 0.992, blue: 0.996, alpha: 1 },
            { red: 0.553, green: 0.263, blue: 0.141, alpha: 1 },
            { red: 0.78, green: 0.38, blue: 0.141, alpha: 1 }
        ]
    },
    'minecraft:yellow_carpet': {
        hardness: 0.1,
        colors: [
            { red: 0.996, green: 0.851, blue: 0.247, alpha: 1 },
            { red: 0.992, green: 0.831, blue: 0.208, alpha: 1 },
            { red: 0.965, green: 0.741, blue: 0.122, alpha: 1 }
        ]
    },
    'minecraft:yellow_concrete': {
        hardness: 1.8,
        colors: [
            { red: 0.945, green: 0.686, blue: 0.082, alpha: 1 },
            { red: 0.949, green: 0.69, blue: 0.082, alpha: 1 },
            { red: 0.941, green: 0.686, blue: 0.082, alpha: 1 }
        ]
    },
    'minecraft:yellow_concrete_powder': {
        hardness: 0.5,
        colors: [
            { red: 0.929, green: 0.788, blue: 0.2, alpha: 1 },
            { red: 0.906, green: 0.765, blue: 0.196, alpha: 1 },
            { red: 0.89, green: 0.749, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:acacia_wood': {
        hardness: 2,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:birch_wood': {
        hardness: 2,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:cherry_wood': {
        hardness: 2,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:crimson_hyphae': {
        hardness: 2,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_wood': {
        hardness: 2,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:jungle_wood': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:mangrove_wood': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:oak_wood': {
        hardness: 2,
        colors: [
            { red: 0.455, green: 0.353, blue: 0.212, alpha: 1 },
            { red: 0.569, green: 0.443, blue: 0.259, alpha: 1 },
            { red: 0.373, green: 0.29, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_wood': {
        hardness: 2,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:spruce_wood': {
        hardness: 2,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:stripped_acacia_wood': {
        hardness: 2,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:stripped_birch_wood': {
        hardness: 2,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:stripped_cherry_wood': {
        hardness: 2,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:stripped_crimson_hyphae': {
        hardness: 2,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:stripped_dark_oak_wood': {
        hardness: 2,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:stripped_jungle_wood': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:stripped_mangrove_wood': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:stripped_oak_wood': {
        hardness: 2,
        colors: [
            { red: 0.725, green: 0.584, blue: 0.345, alpha: 1 },
            { red: 0.753, green: 0.616, blue: 0.384, alpha: 1 },
            { red: 0.682, green: 0.557, blue: 0.322, alpha: 1 }
        ]
    },
    'minecraft:stripped_pale_oak_wood': {
        hardness: 2,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:stripped_spruce_wood': {
        hardness: 2,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:stripped_warped_hyphae': {
        hardness: 2,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:warped_hyphae': {
        hardness: 2,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:planks_acacia': {
        hardness: 2,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:bamboo_planks': {
        hardness: 2,
        colors: [
            { red: 0.784, green: 0.694, blue: 0.302, alpha: 1 },
            { red: 0.89, green: 0.8, blue: 0.416, alpha: 1 },
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:planks_birch': {
        hardness: 2,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:cherry_planks': {
        hardness: 2,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:crimson_planks': {
        hardness: 2,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:planks_dark_oak': {
        hardness: 2,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:planks_jungle': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:mangrove_planks': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:oak_planks': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_planks': {
        hardness: 2,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:planks_spruce': {
        hardness: 2,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:warped_planks': {
        hardness: 2,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:acacia_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:acacia_standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:acacia_wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:bamboo_door': {
        hardness: 2,
        colors: [
            { red: 0.663, green: 0.596, blue: 0.275, alpha: 1 },
            { red: 0.784, green: 0.694, blue: 0.302, alpha: 1 },
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:bamboo_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.349, green: 0.565, blue: 0.012, alpha: 1 },
            { red: 0.325, green: 0.51, blue: 0.035, alpha: 1 },
            { red: 0.553, green: 0.761, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:bamboo_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.349, green: 0.565, blue: 0.012, alpha: 1 },
            { red: 0.325, green: 0.51, blue: 0.035, alpha: 1 },
            { red: 0.553, green: 0.761, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:bamboo_mosaic_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.784, green: 0.694, blue: 0.302, alpha: 1 },
            { red: 0.6, green: 0.529, blue: 0.255, alpha: 1 },
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:bamboo_pressure_plate': {
        hardness: 2,
        colors: [
            { red: 0.349, green: 0.565, blue: 0.012, alpha: 1 },
            { red: 0.325, green: 0.51, blue: 0.035, alpha: 1 },
            { red: 0.553, green: 0.761, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:bamboo_slab': {
        hardness: 2,
        colors: [
            { red: 0.349, green: 0.565, blue: 0.012, alpha: 1 },
            { red: 0.325, green: 0.51, blue: 0.035, alpha: 1 },
            { red: 0.553, green: 0.761, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:bamboo_stairs': {
        hardness: 2,
        colors: [
            { red: 0.349, green: 0.565, blue: 0.012, alpha: 1 },
            { red: 0.325, green: 0.51, blue: 0.035, alpha: 1 },
            { red: 0.553, green: 0.761, blue: 0.31, alpha: 1 }
        ]
    },
    'minecraft:bamboo_standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.784, green: 0.694, blue: 0.302, alpha: 1 },
            { red: 0.89, green: 0.8, blue: 0.416, alpha: 1 },
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:bamboo_trapdoor': {
        hardness: 2,
        colors: [
            { red: 0.89, green: 0.8, blue: 0.416, alpha: 1 },
            { red: 0.663, green: 0.596, blue: 0.275, alpha: 1 },
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:bamboo_wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.784, green: 0.694, blue: 0.302, alpha: 1 },
            { red: 0.89, green: 0.8, blue: 0.416, alpha: 1 },
            { red: 0.851, green: 0.761, blue: 0.369, alpha: 1 }
        ]
    },
    'minecraft:birch_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:birch_standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:birch_wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:cherry_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:cherry_standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:cherry_wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:crimson_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:crimson_standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:crimson_wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:darkoak_standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:darkoak_wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:jungle_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:jungle_standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:jungle_wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:mangrove_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:mangrove_standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:mangrove_wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:oak_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:spruce_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:spruce_standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:spruce_wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:warped_hanging_sign': {
        hardness: 1,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:warped_standing_sign': {
        hardness: 1,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:warped_wall_sign': {
        hardness: 1,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:brain_coral': {
        hardness: 0,
        colors: [
            { red: 0.616, green: 0.184, blue: 0.467, alpha: 1 },
            { red: 0.839, green: 0.329, blue: 0.608, alpha: 1 },
            { red: 0.91, green: 0.557, blue: 0.757, alpha: 1 }
        ]
    },
    'minecraft:brain_coral_block': {
        hardness: 1.5,
        colors: [
            { red: 0.749, green: 0.275, blue: 0.573, alpha: 1 },
            { red: 0.851, green: 0.384, blue: 0.639, alpha: 1 },
            { red: 0.894, green: 0.494, blue: 0.725, alpha: 1 }
        ]
    },
    'minecraft:brain_coral_fan': {
        hardness: 0,
        colors: [
            { red: 0.749, green: 0.275, blue: 0.573, alpha: 1 },
            { red: 0.839, green: 0.329, blue: 0.608, alpha: 1 },
            { red: 0.894, green: 0.494, blue: 0.725, alpha: 1 }
        ]
    },
    'minecraft:brain_coral_wall_fan': {
        hardness: 0,
        colors: [
            { red: 0.749, green: 0.275, blue: 0.573, alpha: 1 },
            { red: 0.839, green: 0.329, blue: 0.608, alpha: 1 },
            { red: 0.894, green: 0.494, blue: 0.725, alpha: 1 }
        ]
    },
    'minecraft:bubble_coral': {
        hardness: 0,
        colors: [
            { red: 0.647, green: 0.114, blue: 0.647, alpha: 1 },
            { red: 0.784, green: 0.098, blue: 0.729, alpha: 1 },
            { red: 0.494, green: 0.035, blue: 0.529, alpha: 1 }
        ]
    },
    'minecraft:bubble_coral_block': {
        hardness: 1.5,
        colors: [
            { red: 0.722, green: 0.137, blue: 0.722, alpha: 1 },
            { red: 0.647, green: 0.118, blue: 0.647, alpha: 1 },
            { red: 0.855, green: 0.114, blue: 0.796, alpha: 1 }
        ]
    },
    'minecraft:bubble_coral_fan': {
        hardness: 0,
        colors: [
            { red: 0.647, green: 0.114, blue: 0.647, alpha: 1 },
            { red: 0.804, green: 0.271, blue: 0.749, alpha: 1 },
            { red: 0.494, green: 0.035, blue: 0.529, alpha: 1 }
        ]
    },
    'minecraft:bubble_coral_wall_fan': {
        hardness: 0,
        colors: [
            { red: 0.647, green: 0.114, blue: 0.647, alpha: 1 },
            { red: 0.804, green: 0.271, blue: 0.749, alpha: 1 },
            { red: 0.494, green: 0.035, blue: 0.529, alpha: 1 }
        ]
    },
    'minecraft:dead_brain_coral': {
        hardness: 0,
        colors: [
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 },
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.643, green: 0.627, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:dead_brain_coral_block': {
        hardness: 1.5,
        colors: [
            { red: 0.408, green: 0.392, blue: 0.388, alpha: 1 },
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 }
        ]
    },
    'minecraft:dead_brain_coral_fan': {
        hardness: 0,
        colors: [
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 }
        ]
    },
    'minecraft:dead_brain_coral_wall_fan': {
        hardness: 0,
        colors: [
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 }
        ]
    },
    'minecraft:dead_bubble_coral': {
        hardness: 0,
        colors: [
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 },
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 }
        ]
    },
    'minecraft:dead_bubble_coral_block': {
        hardness: 1.5,
        colors: [
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 }
        ]
    },
    'minecraft:dead_bubble_coral_fan': {
        hardness: 0,
        colors: [
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 },
            { red: 0.643, green: 0.627, blue: 0.612, alpha: 1 },
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 }
        ]
    },
    'minecraft:dead_bubble_coral_wall_fan': {
        hardness: 0,
        colors: [
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 },
            { red: 0.643, green: 0.627, blue: 0.612, alpha: 1 },
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 }
        ]
    },
    'minecraft:dead_fire_coral': {
        hardness: 0,
        colors: [
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 },
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 }
        ]
    },
    'minecraft:dead_fire_coral_block': {
        hardness: 1.5,
        colors: [
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 },
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 }
        ]
    },
    'minecraft:dead_fire_coral_fan': {
        hardness: 0,
        colors: [
            { red: 0.365, green: 0.353, blue: 0.349, alpha: 1 },
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 }
        ]
    },
    'minecraft:dead_fire_coral_wall_fan': {
        hardness: 0,
        colors: [
            { red: 0.365, green: 0.353, blue: 0.349, alpha: 1 },
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 }
        ]
    },
    'minecraft:dead_horn_coral': {
        hardness: 0,
        colors: [
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 },
            { red: 0.541, green: 0.502, blue: 0.482, alpha: 1 },
            { red: 0.482, green: 0.447, blue: 0.431, alpha: 1 }
        ]
    },
    'minecraft:dead_horn_coral_block': {
        hardness: 1.5,
        colors: [
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 },
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.643, green: 0.627, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:dead_horn_coral_fan': {
        hardness: 0,
        colors: [
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 }
        ]
    },
    'minecraft:dead_horn_coral_wall_fan': {
        hardness: 0,
        colors: [
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 }
        ]
    },
    'minecraft:dead_tube_coral': {
        hardness: 0,
        colors: [
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 },
            { red: 0.365, green: 0.353, blue: 0.349, alpha: 1 },
            { red: 0.541, green: 0.502, blue: 0.482, alpha: 1 }
        ]
    },
    'minecraft:dead_tube_coral_block': {
        hardness: 1.5,
        colors: [
            { red: 0.525, green: 0.482, blue: 0.467, alpha: 1 },
            { red: 0.408, green: 0.392, blue: 0.388, alpha: 1 },
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 }
        ]
    },
    'minecraft:dead_tube_coral_fan': {
        hardness: 0,
        colors: [
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 },
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 },
            { red: 0.408, green: 0.392, blue: 0.388, alpha: 1 }
        ]
    },
    'minecraft:dead_tube_coral_wall_fan': {
        hardness: 0,
        colors: [
            { red: 0.6, green: 0.576, blue: 0.553, alpha: 1 },
            { red: 0.455, green: 0.416, blue: 0.4, alpha: 1 },
            { red: 0.408, green: 0.392, blue: 0.388, alpha: 1 }
        ]
    },
    'minecraft:fire_coral': {
        hardness: 0,
        colors: [
            { red: 0.475, green: 0.102, blue: 0.149, alpha: 1 },
            { red: 0.643, green: 0.133, blue: 0.184, alpha: 1 },
            { red: 0.776, green: 0.165, blue: 0.216, alpha: 1 }
        ]
    },
    'minecraft:fire_coral_block': {
        hardness: 1.5,
        colors: [
            { red: 0.643, green: 0.133, blue: 0.184, alpha: 1 },
            { red: 0.776, green: 0.165, blue: 0.216, alpha: 1 },
            { red: 0.549, green: 0.114, blue: 0.165, alpha: 1 }
        ]
    },
    'minecraft:fire_coral_fan': {
        hardness: 0,
        colors: [
            { red: 0.475, green: 0.102, blue: 0.149, alpha: 1 },
            { red: 0.643, green: 0.133, blue: 0.184, alpha: 1 },
            { red: 0.776, green: 0.165, blue: 0.216, alpha: 1 }
        ]
    },
    'minecraft:fire_coral_wall_fan': {
        hardness: 0,
        colors: [
            { red: 0.475, green: 0.102, blue: 0.149, alpha: 1 },
            { red: 0.643, green: 0.133, blue: 0.184, alpha: 1 },
            { red: 0.776, green: 0.165, blue: 0.216, alpha: 1 }
        ]
    },
    'minecraft:horn_coral': {
        hardness: 0,
        colors: [
            { red: 0.82, green: 0.702, blue: 0.255, alpha: 1 },
            { red: 0.714, green: 0.537, blue: 0.188, alpha: 1 },
            { red: 0.835, green: 0.796, blue: 0.243, alpha: 1 }
        ]
    },
    'minecraft:horn_coral_block': {
        hardness: 1.5,
        colors: [
            { red: 0.835, green: 0.796, blue: 0.243, alpha: 1 },
            { red: 0.82, green: 0.702, blue: 0.255, alpha: 1 },
            { red: 0.929, green: 0.925, blue: 0.298, alpha: 1 }
        ]
    },
    'minecraft:horn_coral_fan': {
        hardness: 0,
        colors: [
            { red: 0.82, green: 0.702, blue: 0.255, alpha: 1 },
            { red: 0.745, green: 0.627, blue: 0.208, alpha: 1 },
            { red: 0.835, green: 0.796, blue: 0.243, alpha: 1 }
        ]
    },
    'minecraft:horn_coral_wall_fan': {
        hardness: 0,
        colors: [
            { red: 0.82, green: 0.702, blue: 0.255, alpha: 1 },
            { red: 0.745, green: 0.627, blue: 0.208, alpha: 1 },
            { red: 0.835, green: 0.796, blue: 0.243, alpha: 1 }
        ]
    },
    'minecraft:tube_coral': {
        hardness: 0,
        colors: [
            { red: 0.192, green: 0.31, blue: 0.867, alpha: 1 },
            { red: 0.11, green: 0.216, blue: 0.533, alpha: 1 },
            { red: 0.247, green: 0.424, blue: 0.898, alpha: 1 }
        ]
    },
    'minecraft:tube_coral_block': {
        hardness: 1.5,
        colors: [
            { red: 0.192, green: 0.31, blue: 0.867, alpha: 1 },
            { red: 0.129, green: 0.263, blue: 0.643, alpha: 1 },
            { red: 0.247, green: 0.424, blue: 0.898, alpha: 1 }
        ]
    },
    'minecraft:tube_coral_fan': {
        hardness: 0,
        colors: [
            { red: 0.247, green: 0.424, blue: 0.898, alpha: 1 },
            { red: 0.192, green: 0.31, blue: 0.867, alpha: 1 },
            { red: 0.129, green: 0.263, blue: 0.643, alpha: 1 }
        ]
    },
    'minecraft:tube_coral_wall_fan': {
        hardness: 0,
        colors: [
            { red: 0.247, green: 0.424, blue: 0.898, alpha: 1 },
            { red: 0.192, green: 0.31, blue: 0.867, alpha: 1 },
            { red: 0.129, green: 0.263, blue: 0.643, alpha: 1 }
        ]
    },
    'minecraft:acacia_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:acacia_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:acacia_slab': {
        hardness: 2,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:acacia_stairs': {
        hardness: 2,
        colors: [
            { red: 0.729, green: 0.388, blue: 0.216, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:acacia_trapdoor': {
        hardness: 2,
        colors: [
            { red: 0.533, green: 0.278, blue: 0.157, alpha: 1 },
            { red: 0.678, green: 0.365, blue: 0.196, alpha: 1 },
            { red: 0.729, green: 0.408, blue: 0.231, alpha: 1 }
        ]
    },
    'minecraft:birch_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:birch_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:birch_slab': {
        hardness: 2,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:birch_stairs': {
        hardness: 2,
        colors: [
            { red: 0.843, green: 0.757, blue: 0.522, alpha: 1 },
            { red: 0.784, green: 0.718, blue: 0.478, alpha: 1 },
            { red: 0.722, green: 0.659, blue: 0.459, alpha: 1 }
        ]
    },
    'minecraft:birch_trapdoor': {
        hardness: 2,
        colors: [
            { red: 0.62, green: 0.545, blue: 0.38, alpha: 1 },
            { red: 0.647, green: 0.58, blue: 0.404, alpha: 1 },
            { red: 0.843, green: 0.796, blue: 0.553, alpha: 1 }
        ]
    },
    'minecraft:cherry_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:crimson_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:crimson_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:crimson_slab': {
        hardness: 2,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:crimson_stairs': {
        hardness: 2,
        colors: [
            { red: 0.494, green: 0.227, blue: 0.337, alpha: 1 },
            { red: 0.416, green: 0.204, blue: 0.294, alpha: 1 },
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:crimson_trapdoor': {
        hardness: 2,
        colors: [
            { red: 0.361, green: 0.188, blue: 0.259, alpha: 1 },
            { red: 0.294, green: 0.153, blue: 0.216, alpha: 1 },
            { red: 0.573, green: 0.255, blue: 0.376, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_slab': {
        hardness: 2,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_stairs': {
        hardness: 2,
        colors: [
            { red: 0.31, green: 0.196, blue: 0.094, alpha: 1 },
            { red: 0.286, green: 0.184, blue: 0.09, alpha: 1 },
            { red: 0.243, green: 0.161, blue: 0.071, alpha: 1 }
        ]
    },
    'minecraft:dark_oak_trapdoor': {
        hardness: 2,
        colors: [
            { red: 0.286, green: 0.192, blue: 0.086, alpha: 1 },
            { red: 0.325, green: 0.212, blue: 0.102, alpha: 1 },
            { red: 0.161, green: 0.102, blue: 0.047, alpha: 1 }
        ]
    },
    'minecraft:jungle_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:jungle_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:jungle_slab': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:jungle_stairs': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.529, blue: 0.392, alpha: 1 },
            { red: 0.667, green: 0.475, blue: 0.329, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:jungle_trapdoor': {
        hardness: 2,
        colors: [
            { red: 0.694, green: 0.502, blue: 0.361, alpha: 1 },
            { red: 0.624, green: 0.443, blue: 0.29, alpha: 1 },
            { red: 0.447, green: 0.314, blue: 0.208, alpha: 1 }
        ]
    },
    'minecraft:mangrove_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:mangrove_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:mangrove_slab': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:mangrove_stairs': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 },
            { red: 0.467, green: 0.224, blue: 0.204, alpha: 1 },
            { red: 0.459, green: 0.192, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:mangrove_trapdoor': {
        hardness: 2,
        colors: [
            { red: 0.392, green: 0.141, blue: 0.137, alpha: 1 },
            { red: 0.365, green: 0.11, blue: 0.118, alpha: 1 },
            { red: 0.498, green: 0.259, blue: 0.204, alpha: 1 }
        ]
    },
    'minecraft:oak_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:oak_slab': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:oak_stairs': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_door': {
        hardness: 2,
        colors: [
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 },
            { red: 0.78, green: 0.722, blue: 0.722, alpha: 1 },
            { red: 0.69, green: 0.643, blue: 0.643, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_slab': {
        hardness: 2,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_stairs': {
        hardness: 2,
        colors: [
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.906, green: 0.89, blue: 0.882, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:pale_oak_trapdoor': {
        hardness: 2,
        colors: [
            { red: 1, green: 0.984, blue: 0.973, alpha: 1 },
            { red: 0.98, green: 0.937, blue: 0.933, alpha: 1 },
            { red: 0.867, green: 0.808, blue: 0.804, alpha: 1 }
        ]
    },
    'minecraft:petrified_oak_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:spruce_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:spruce_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:spruce_slab': {
        hardness: 2,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:spruce_stairs': {
        hardness: 2,
        colors: [
            { red: 0.51, green: 0.38, blue: 0.227, alpha: 1 },
            { red: 0.478, green: 0.353, blue: 0.204, alpha: 1 },
            { red: 0.439, green: 0.322, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:spruce_trapdoor': {
        hardness: 2,
        colors: [
            { red: 0.4, green: 0.302, blue: 0.157, alpha: 1 },
            { red: 0.42, green: 0.325, blue: 0.196, alpha: 1 },
            { red: 0.502, green: 0.369, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:warped_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:warped_pressure_plate': {
        hardness: 0.5,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:warped_slab': {
        hardness: 2,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:warped_stairs': {
        hardness: 2,
        colors: [
            { red: 0.224, green: 0.514, blue: 0.51, alpha: 1 },
            { red: 0.157, green: 0.439, blue: 0.404, alpha: 1 },
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:warped_trapdoor': {
        hardness: 2,
        colors: [
            { red: 0.18, green: 0.373, blue: 0.318, alpha: 1 },
            { red: 0.212, green: 0.616, blue: 0.569, alpha: 1 },
            { red: 0.122, green: 0.341, blue: 0.322, alpha: 1 }
        ]
    },
    'minecraft:light_block_0': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_1': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_10': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_11': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_12': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_13': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_14': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_15': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_2': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_3': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_4': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_5': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_6': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_7': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_8': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:light_block_9': {
        hardness: -1,
        colors: [
            { red: 0.992, green: 0.757, blue: 0.204, alpha: 1 },
            { red: 0.98, green: 0.671, blue: 0.11, alpha: 1 },
            { red: 1, green: 0.808, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:standing_banner': {
        hardness: 1,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:wall_banner': {
        hardness: 1,
        colors: [
            { red: 0.722, green: 0.58, blue: 0.373, alpha: 1 },
            { red: 0.686, green: 0.561, blue: 0.333, alpha: 1 },
            { red: 0.624, green: 0.518, blue: 0.302, alpha: 1 }
        ]
    },
    'minecraft:andesite_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.541, green: 0.541, blue: 0.557, alpha: 1 },
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.612, green: 0.612, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:chipped_anvil': {
        hardness: 5,
        colors: [
            { red: 0.239, green: 0.239, blue: 0.239, alpha: 1 },
            { red: 0.259, green: 0.259, blue: 0.259, alpha: 1 },
            { red: 0.29, green: 0.29, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:damaged_anvil': {
        hardness: 5,
        colors: [
            { red: 0.239, green: 0.239, blue: 0.239, alpha: 1 },
            { red: 0.259, green: 0.259, blue: 0.259, alpha: 1 },
            { red: 0.29, green: 0.29, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:deprecated_anvil': {
        hardness: 5,
        colors: [
            { red: 0.239, green: 0.239, blue: 0.239, alpha: 1 },
            { red: 0.259, green: 0.259, blue: 0.259, alpha: 1 },
            { red: 0.29, green: 0.29, blue: 0.29, alpha: 1 }
        ]
    },
    'minecraft:diorite_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.914, green: 0.914, blue: 0.914, alpha: 1 },
            { red: 0.643, green: 0.635, blue: 0.635, alpha: 1 },
            { red: 0.745, green: 0.749, blue: 0.757, alpha: 1 }
        ]
    },
    'minecraft:polished_andesite_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.525, green: 0.533, blue: 0.529, alpha: 1 },
            { red: 0.486, green: 0.498, blue: 0.502, alpha: 1 },
            { red: 0.541, green: 0.565, blue: 0.565, alpha: 1 }
        ]
    },
    'minecraft:polished_diorite_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.784, green: 0.788, blue: 0.784, alpha: 1 },
            { red: 0.851, green: 0.847, blue: 0.851, alpha: 1 },
            { red: 0.729, green: 0.733, blue: 0.753, alpha: 1 }
        ]
    },
    'minecraft:cherry_door': {
        hardness: 2,
        colors: [
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:cherry_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:cherry_slab': {
        hardness: 2,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:cherry_stairs': {
        hardness: 2,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 }
        ]
    },
    'minecraft:cherry_trapdoor': {
        hardness: 2,
        colors: [
            { red: 0.906, green: 0.761, blue: 0.733, alpha: 1 },
            { red: 0.902, green: 0.702, blue: 0.678, alpha: 1 },
            { red: 0.906, green: 0.729, blue: 0.706, alpha: 1 }
        ]
    },
    'minecraft:end_brick_stairs': {
        hardness: 3,
        colors: [
            { red: 0.91, green: 0.957, blue: 0.698, alpha: 1 },
            { red: 0.867, green: 0.894, blue: 0.647, alpha: 1 },
            { red: 0.839, green: 0.839, blue: 0.584, alpha: 1 }
        ]
    },
    'minecraft:end_bricks': {
        hardness: 3,
        colors: [
            { red: 0.91, green: 0.957, blue: 0.698, alpha: 1 },
            { red: 0.867, green: 0.894, blue: 0.647, alpha: 1 },
            { red: 0.839, green: 0.839, blue: 0.584, alpha: 1 }
        ]
    },
    'minecraft:end_stone_brick_double_slab': {
        hardness: 3,
        colors: [
            { red: 0.91, green: 0.957, blue: 0.698, alpha: 1 },
            { red: 0.867, green: 0.894, blue: 0.647, alpha: 1 },
            { red: 0.839, green: 0.839, blue: 0.584, alpha: 1 }
        ]
    },
    'minecraft:blackstone_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 },
            { red: 0.125, green: 0.075, blue: 0.11, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 }
        ]
    },
    'minecraft:colored_torch_blue': {
        hardness: 0,
        colors: [
            { red: 0.624, green: 0.498, blue: 0.314, alpha: 1 },
            { red: 0.427, green: 0.341, blue: 0.212, alpha: 1 },
            { red: 0.333, green: 0.271, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:colored_torch_green': {
        hardness: 0,
        colors: [
            { red: 0.624, green: 0.498, blue: 0.314, alpha: 1 },
            { red: 0.427, green: 0.341, blue: 0.212, alpha: 1 },
            { red: 0.333, green: 0.271, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:colored_torch_purple': {
        hardness: 0,
        colors: [
            { red: 0.624, green: 0.498, blue: 0.314, alpha: 1 },
            { red: 0.427, green: 0.341, blue: 0.212, alpha: 1 },
            { red: 0.333, green: 0.271, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:colored_torch_red': {
        hardness: 0,
        colors: [
            { red: 0.624, green: 0.498, blue: 0.314, alpha: 1 },
            { red: 0.427, green: 0.341, blue: 0.212, alpha: 1 },
            { red: 0.333, green: 0.271, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:lit_blast_furnace': {
        hardness: 3.5,
        colors: [
            { red: 0.349, green: 0.345, blue: 0.345, alpha: 1 },
            { red: 0.286, green: 0.282, blue: 0.282, alpha: 1 },
            { red: 0.247, green: 0.243, blue: 0.259, alpha: 1 }
        ]
    },
    'minecraft:lit_furnace': {
        hardness: 3.5,
        colors: [
            { red: 0.314, green: 0.306, blue: 0.306, alpha: 1 },
            { red: 0.408, green: 0.408, blue: 0.408, alpha: 1 },
            { red: 0.522, green: 0.522, blue: 0.522, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone_brick_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:polished_blackstone_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.235, green: 0.224, blue: 0.278, alpha: 1 },
            { red: 0.192, green: 0.173, blue: 0.212, alpha: 1 },
            { red: 0.153, green: 0.133, blue: 0.11, alpha: 1 }
        ]
    },
    'minecraft:powered_comparator': {
        hardness: 0,
        colors: [
            { red: 0.733, green: 0.733, blue: 0.733, alpha: 1 },
            { red: 0.545, green: 0.553, blue: 0.545, alpha: 1 },
            { red: 0.773, green: 0.792, blue: 0.773, alpha: 1 }
        ]
    },
    'minecraft:powered_repeater': {
        hardness: 0,
        colors: [
            { red: 0.545, green: 0.553, blue: 0.545, alpha: 1 },
            { red: 0.733, green: 0.733, blue: 0.733, alpha: 1 },
            { red: 0.675, green: 0.667, blue: 0.675, alpha: 1 }
        ]
    },
    'minecraft:quartz_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.933, green: 0.918, blue: 0.902, alpha: 1 },
            { red: 0.933, green: 0.902, blue: 0.871, alpha: 1 },
            { red: 0.918, green: 0.886, blue: 0.855, alpha: 1 }
        ]
    },
    'minecraft:smooth_quartz': {
        hardness: 2,
        colors: [
            { red: 0.933, green: 0.918, blue: 0.902, alpha: 1 },
            { red: 0.933, green: 0.902, blue: 0.871, alpha: 1 },
            { red: 0.918, green: 0.886, blue: 0.855, alpha: 1 }
        ]
    },
    'minecraft:smooth_quartz_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.933, green: 0.918, blue: 0.902, alpha: 1 },
            { red: 0.933, green: 0.902, blue: 0.871, alpha: 1 },
            { red: 0.918, green: 0.886, blue: 0.855, alpha: 1 }
        ]
    },
    'minecraft:torchflower_crop': {
        hardness: 0,
        colors: [
            { red: 0.153, green: 0.518, blue: 0.365, alpha: 1 },
            { red: 0.075, green: 0.271, blue: 0.196, alpha: 1 },
            { red: 0.11, green: 0.357, blue: 0.227, alpha: 1 }
        ]
    },
    'minecraft:unlit_redstone_torch': {
        hardness: 0,
        colors: [
            { red: 0.624, green: 0.498, blue: 0.314, alpha: 1 },
            { red: 0.427, green: 0.341, blue: 0.212, alpha: 1 },
            { red: 0.333, green: 0.271, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:unpowered_comparator': {
        hardness: 0,
        colors: [
            { red: 0.733, green: 0.733, blue: 0.733, alpha: 1 },
            { red: 0.545, green: 0.553, blue: 0.545, alpha: 1 },
            { red: 0.773, green: 0.792, blue: 0.773, alpha: 1 }
        ]
    },
    'minecraft:unpowered_repeater': {
        hardness: 0,
        colors: [
            { red: 0.545, green: 0.553, blue: 0.545, alpha: 1 },
            { red: 0.733, green: 0.733, blue: 0.733, alpha: 1 },
            { red: 0.675, green: 0.667, blue: 0.675, alpha: 1 }
        ]
    },
    'minecraft:cave_vines_body_with_berries': {
        hardness: 0,
        colors: [
            { red: 0.314, green: 0.447, blue: 0.2, alpha: 1 },
            { red: 0.282, green: 0.38, blue: 0.141, alpha: 1 },
            { red: 0.439, green: 0.573, blue: 0.176, alpha: 1 }
        ]
    },
    'minecraft:cave_vines_head_with_berries': {
        hardness: 0,
        colors: [
            { red: 0.314, green: 0.447, blue: 0.2, alpha: 1 },
            { red: 0.282, green: 0.38, blue: 0.141, alpha: 1 },
            { red: 0.439, green: 0.573, blue: 0.176, alpha: 1 }
        ]
    },
    'minecraft:double_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:exposed_chiseled_copper': {
        hardness: 3,
        colors: [
            { red: 0.58, green: 0.463, blue: 0.38, alpha: 1 },
            { red: 0.659, green: 0.467, blue: 0.384, alpha: 1 },
            { red: 0.49, green: 0.435, blue: 0.353, alpha: 1 }
        ]
    },
    'minecraft:exposed_copper_bulb': {
        hardness: 3,
        colors: [
            { red: 0.329, green: 0.302, blue: 0.239, alpha: 1 },
            { red: 0.475, green: 0.392, blue: 0.329, alpha: 1 },
            { red: 0.42, green: 0.345, blue: 0.294, alpha: 1 }
        ]
    },
    'minecraft:exposed_copper_door': {
        hardness: 3,
        colors: [
            { red: 0.58, green: 0.463, blue: 0.38, alpha: 1 },
            { red: 0.69, green: 0.486, blue: 0.424, alpha: 1 },
            { red: 0.475, green: 0.392, blue: 0.329, alpha: 1 }
        ]
    },
    'minecraft:exposed_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.498, green: 0.447, blue: 0.341, alpha: 1 },
            { red: 0.58, green: 0.463, blue: 0.38, alpha: 1 },
            { red: 0.729, green: 0.51, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:exposed_cut_copper_stairs': {
        hardness: 3,
        colors: [
            { red: 0.498, green: 0.447, blue: 0.341, alpha: 1 },
            { red: 0.58, green: 0.463, blue: 0.38, alpha: 1 },
            { red: 0.729, green: 0.51, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:exposed_double_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:normal_stone_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 }
        ]
    },
    'minecraft:normal_stone_slab': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 }
        ]
    },
    'minecraft:normal_stone_stairs': {
        hardness: 2,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.455, green: 0.455, blue: 0.455, alpha: 1 },
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 }
        ]
    },
    'minecraft:oxidized_chiseled_copper': {
        hardness: 3,
        colors: [
            { red: 0.349, green: 0.698, blue: 0.573, alpha: 1 },
            { red: 0.431, green: 0.773, blue: 0.624, alpha: 1 },
            { red: 0.235, green: 0.451, blue: 0.365, alpha: 1 }
        ]
    },
    'minecraft:oxidized_copper_bulb': {
        hardness: 3,
        colors: [
            { red: 0.231, green: 0.4, blue: 0.333, alpha: 1 },
            { red: 0.192, green: 0.329, blue: 0.275, alpha: 1 },
            { red: 0.224, green: 0.431, blue: 0.349, alpha: 1 }
        ]
    },
    'minecraft:oxidized_copper_door': {
        hardness: 3,
        colors: [
            { red: 0.31, green: 0.671, blue: 0.565, alpha: 1 },
            { red: 0.349, green: 0.698, blue: 0.573, alpha: 1 },
            { red: 0.298, green: 0.58, blue: 0.518, alpha: 1 }
        ]
    },
    'minecraft:oxidized_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.318, green: 0.643, blue: 0.545, alpha: 1 },
            { red: 0.298, green: 0.58, blue: 0.518, alpha: 1 },
            { red: 0.325, green: 0.631, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:oxidized_cut_copper_stairs': {
        hardness: 3,
        colors: [
            { red: 0.318, green: 0.643, blue: 0.545, alpha: 1 },
            { red: 0.298, green: 0.58, blue: 0.518, alpha: 1 },
            { red: 0.325, green: 0.631, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:oxidized_double_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:vine': {
        hardness: 0.2,
        colors: [
            { red: 0.514, green: 0.514, blue: 0.514, alpha: 1 },
            { red: 0.329, green: 0.329, blue: 0.329, alpha: 1 },
            { red: 0.42, green: 0.42, blue: 0.42, alpha: 1 }
        ]
    },
    'minecraft:waxed_chiseled_copper': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_copper_bulb': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_copper_door': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_cut_copper_stairs': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_double_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_exposed_chiseled_copper': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_exposed_copper_bulb': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_exposed_copper_door': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_exposed_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_exposed_cut_copper_stairs': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_exposed_double_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_oxidized_chiseled_copper': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_oxidized_copper_bulb': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_oxidized_copper_door': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_oxidized_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_oxidized_cut_copper_stairs': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_oxidized_double_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_weathered_chiseled_copper': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_weathered_copper_bulb': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_weathered_copper_door': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_weathered_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_weathered_cut_copper_stairs': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_weathered_double_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:weathered_chiseled_copper': {
        hardness: 3,
        colors: [
            { red: 0.4, green: 0.663, blue: 0.467, alpha: 1 },
            { red: 0.478, green: 0.718, blue: 0.6, alpha: 1 },
            { red: 0.286, green: 0.443, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:weathered_copper_bulb': {
        hardness: 3,
        colors: [
            { red: 0.31, green: 0.322, blue: 0.282, alpha: 1 },
            { red: 0.286, green: 0.443, blue: 0.392, alpha: 1 },
            { red: 0.255, green: 0.388, blue: 0.345, alpha: 1 }
        ]
    },
    'minecraft:weathered_copper_door': {
        hardness: 3,
        colors: [
            { red: 0.455, green: 0.553, blue: 0.341, alpha: 1 },
            { red: 0.392, green: 0.627, blue: 0.467, alpha: 1 },
            { red: 0.424, green: 0.592, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:weathered_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.392, green: 0.627, blue: 0.467, alpha: 1 },
            { red: 0.553, green: 0.529, blue: 0.439, alpha: 1 },
            { red: 0.416, green: 0.443, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:weathered_cut_copper_stairs': {
        hardness: 3,
        colors: [
            { red: 0.392, green: 0.627, blue: 0.467, alpha: 1 },
            { red: 0.553, green: 0.529, blue: 0.439, alpha: 1 },
            { red: 0.416, green: 0.443, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:weathered_double_cut_copper_slab': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:exposed_copper_trapdoor': {
        hardness: 3,
        colors: [
            { red: 0.498, green: 0.447, blue: 0.341, alpha: 1 },
            { red: 0.808, green: 0.553, blue: 0.514, alpha: 1 },
            { red: 0.659, green: 0.467, blue: 0.384, alpha: 1 }
        ]
    },
    'minecraft:flowing_lava': {
        hardness: 100,
        colors: [
            { red: 0.784, green: 0.224, blue: 0.024, alpha: 1 },
            { red: 0.988, green: 0.988, blue: 0.498, alpha: 1 },
            { red: 0.886, green: 0.596, blue: 0.18, alpha: 1 }
        ]
    },
    'minecraft:glowingobsidian': { hardness: 50 },
    'minecraft:oxidized_copper_trapdoor': {
        hardness: 3,
        colors: [
            { red: 0.349, green: 0.698, blue: 0.573, alpha: 1 },
            { red: 0.431, green: 0.773, blue: 0.624, alpha: 1 },
            { red: 0.298, green: 0.58, blue: 0.518, alpha: 1 }
        ]
    },
    'minecraft:polished_tuff_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.388, green: 0.424, blue: 0.427, alpha: 1 },
            { red: 0.357, green: 0.384, blue: 0.369, alpha: 1 },
            { red: 0.424, green: 0.443, blue: 0.42, alpha: 1 }
        ]
    },
    'minecraft:slime': {
        hardness: 0,
        colors: [
            { red: 0.451, green: 0.761, blue: 0.384, alpha: 1 },
            { red: 0.384, green: 0.714, blue: 0.29, alpha: 1 },
            { red: 0.482, green: 0.792, blue: 0.384, alpha: 1 }
        ]
    },
    'minecraft:tuff_brick_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.522, green: 0.514, blue: 0.478, alpha: 1 },
            { red: 0.424, green: 0.443, blue: 0.42, alpha: 1 },
            { red: 0.322, green: 0.353, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:tuff_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.416, green: 0.431, blue: 0.435, alpha: 1 },
            { red: 0.365, green: 0.365, blue: 0.322, alpha: 1 },
            { red: 0.522, green: 0.514, blue: 0.482, alpha: 1 }
        ]
    },
    'minecraft:waterlily': {
        hardness: 0,
        colors: [
            { red: 0.588, green: 0.588, blue: 0.588, alpha: 1 },
            { red: 0.361, green: 0.361, blue: 0.361, alpha: 1 },
            { red: 0.639, green: 0.639, blue: 0.639, alpha: 1 }
        ]
    },
    'minecraft:waxed_copper_trapdoor': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_exposed_copper_trapdoor': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_oxidized_copper_trapdoor': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_weathered_copper_trapdoor': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:weathered_copper_trapdoor': {
        hardness: 3,
        colors: [
            { red: 0.478, green: 0.718, blue: 0.6, alpha: 1 },
            { red: 0.455, green: 0.553, blue: 0.341, alpha: 1 },
            { red: 0.4, green: 0.663, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:daylight_detector_inverted': {
        hardness: 0.2,
        colors: [
            { red: 0.235, green: 0.2, blue: 0.133, alpha: 1 },
            { red: 0.2, green: 0.169, blue: 0.106, alpha: 1 },
            { red: 0.337, green: 0.271, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:exposed_copper': {
        hardness: 3,
        colors: [
            { red: 0.659, green: 0.467, blue: 0.384, alpha: 1 },
            { red: 0.596, green: 0.549, blue: 0.412, alpha: 1 },
            { red: 0.729, green: 0.51, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:exposed_copper_grate': {
        hardness: 3,
        colors: [
            { red: 0.659, green: 0.467, blue: 0.384, alpha: 1 },
            { red: 0.596, green: 0.549, blue: 0.412, alpha: 1 },
            { red: 0.729, green: 0.51, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:exposed_cut_copper': {
        hardness: 3,
        colors: [
            { red: 0.498, green: 0.447, blue: 0.341, alpha: 1 },
            { red: 0.58, green: 0.463, blue: 0.38, alpha: 1 },
            { red: 0.729, green: 0.51, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:oxidized_copper': {
        hardness: 3,
        colors: [
            { red: 0.349, green: 0.698, blue: 0.573, alpha: 1 },
            { red: 0.31, green: 0.671, blue: 0.565, alpha: 1 },
            { red: 0.325, green: 0.631, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:oxidized_copper_grate': {
        hardness: 3,
        colors: [
            { red: 0.349, green: 0.698, blue: 0.573, alpha: 1 },
            { red: 0.31, green: 0.671, blue: 0.565, alpha: 1 },
            { red: 0.325, green: 0.631, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:oxidized_cut_copper': {
        hardness: 3,
        colors: [
            { red: 0.318, green: 0.643, blue: 0.545, alpha: 1 },
            { red: 0.298, green: 0.58, blue: 0.518, alpha: 1 },
            { red: 0.325, green: 0.631, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:waxed_copper': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_copper_grate': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_cut_copper': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_exposed_copper': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_exposed_copper_grate': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_exposed_cut_copper': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_oxidized_copper': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_oxidized_copper_grate': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_oxidized_cut_copper': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:waxed_weathered_copper': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_weathered_copper_grate': {
        hardness: 3,
        colors: [
            { red: 0.784, green: 0.455, blue: 0.337, alpha: 1 },
            { red: 0.761, green: 0.42, blue: 0.298, alpha: 1 },
            { red: 0.839, green: 0.482, blue: 0.357, alpha: 1 }
        ]
    },
    'minecraft:waxed_weathered_cut_copper': {
        hardness: 3,
        colors: [
            { red: 0.89, green: 0.51, blue: 0.424, alpha: 1 },
            { red: 0.655, green: 0.353, blue: 0.251, alpha: 1 },
            { red: 0.698, green: 0.384, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:weathered_copper': {
        hardness: 3,
        colors: [
            { red: 0.392, green: 0.627, blue: 0.467, alpha: 1 },
            { red: 0.4, green: 0.663, blue: 0.467, alpha: 1 },
            { red: 0.424, green: 0.592, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:weathered_copper_grate': {
        hardness: 3,
        colors: [
            { red: 0.392, green: 0.627, blue: 0.467, alpha: 1 },
            { red: 0.424, green: 0.592, blue: 0.361, alpha: 1 },
            { red: 0.4, green: 0.663, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:weathered_cut_copper': {
        hardness: 3,
        colors: [
            { red: 0.392, green: 0.627, blue: 0.467, alpha: 1 },
            { red: 0.553, green: 0.529, blue: 0.439, alpha: 1 },
            { red: 0.416, green: 0.443, blue: 0.278, alpha: 1 }
        ]
    },
    'minecraft:cobbled_deepslate_double_slab': {
        hardness: 3.5,
        colors: [
            { red: 0.29, green: 0.29, blue: 0.31, alpha: 1 },
            { red: 0.247, green: 0.247, blue: 0.271, alpha: 1 },
            { red: 0.208, green: 0.208, blue: 0.224, alpha: 1 }
        ]
    },
    'minecraft:deepslate_brick_double_slab': {
        hardness: 3.5,
        colors: [
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 },
            { red: 0.239, green: 0.239, blue: 0.263, alpha: 1 },
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:deepslate_lapis_ore': {
        hardness: 4.5,
        colors: [
            { red: 0.392, green: 0.392, blue: 0.392, alpha: 1 },
            { red: 0.475, green: 0.475, blue: 0.475, alpha: 1 },
            { red: 0.318, green: 0.318, blue: 0.318, alpha: 1 }
        ]
    },
    'minecraft:deepslate_tile_double_slab': {
        hardness: 3.5,
        colors: [
            { red: 0.176, green: 0.176, blue: 0.176, alpha: 1 },
            { red: 0.22, green: 0.216, blue: 0.216, alpha: 1 },
            { red: 0.255, green: 0.255, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:jigsaw': {
        hardness: -1,
        colors: [
            { red: 0.063, green: 0.063, blue: 0.063, alpha: 1 },
            { red: 0.149, green: 0.114, blue: 0.165, alpha: 1 },
            { red: 0.2, green: 0.2, blue: 0.2, alpha: 1 }
        ]
    },
    'minecraft:lit_deepslate_redstone_ore': {
        hardness: 4.5,
        colors: [
            { red: 0.902, green: 0.125, blue: 0.031, alpha: 1 },
            { red: 0.451, green: 0.047, blue: 0, alpha: 1 },
            { red: 0.643, green: 0.094, blue: 0.031, alpha: 1 }
        ]
    },
    'minecraft:polished_deepslate_double_slab': {
        hardness: 3.5,
        colors: [
            { red: 0.345, green: 0.345, blue: 0.345, alpha: 1 },
            { red: 0.294, green: 0.298, blue: 0.31, alpha: 1 },
            { red: 0.255, green: 0.255, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:grass_path': {
        hardness: 0.5,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.349, green: 0.239, blue: 0.161, alpha: 1 }
        ]
    },
    'minecraft:brick_block': {
        hardness: 2,
        colors: [
            { red: 0.608, green: 0.337, blue: 0.263, alpha: 1 },
            { red: 0.545, green: 0.431, blue: 0.404, alpha: 1 },
            { red: 0.635, green: 0.525, blue: 0.49, alpha: 1 }
        ]
    },
    'minecraft:brick_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.608, green: 0.337, blue: 0.263, alpha: 1 },
            { red: 0.545, green: 0.431, blue: 0.404, alpha: 1 },
            { red: 0.635, green: 0.525, blue: 0.49, alpha: 1 }
        ]
    },
    'minecraft:dirt_with_roots': {
        hardness: 0.5,
        colors: [
            { red: 0.475, green: 0.333, blue: 0.227, alpha: 1 },
            { red: 0.588, green: 0.424, blue: 0.29, alpha: 1 },
            { red: 0.678, green: 0.49, blue: 0.396, alpha: 1 }
        ]
    },
    'minecraft:golden_rail': {
        hardness: 0.7,
        colors: [
            { red: 0.612, green: 0.612, blue: 0.612, alpha: 1 },
            { red: 0.408, green: 0.408, blue: 0.408, alpha: 1 },
            { red: 0.361, green: 0.302, blue: 0.188, alpha: 1 }
        ]
    },
    'minecraft:magma': {
        hardness: 0.5,
        colors: [
            { red: 0.396, green: 0.157, blue: 0.157, alpha: 1 },
            { red: 0.314, green: 0.106, blue: 0.106, alpha: 1 },
            { red: 0.902, green: 0.392, blue: 0.063, alpha: 1 }
        ]
    },
    'minecraft:mossy_stone_brick_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 }
        ]
    },
    'minecraft:mud_brick_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.584, green: 0.443, blue: 0.314, alpha: 1 },
            { red: 0.494, green: 0.365, blue: 0.282, alpha: 1 },
            { red: 0.616, green: 0.471, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:nether_brick': {
        hardness: 2,
        colors: [
            { red: 0.188, green: 0.094, blue: 0.11, alpha: 1 },
            { red: 0.098, green: 0.051, blue: 0.063, alpha: 1 },
            { red: 0.129, green: 0.067, blue: 0.078, alpha: 1 }
        ]
    },
    'minecraft:nether_brick_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.188, green: 0.094, blue: 0.11, alpha: 1 },
            { red: 0.098, green: 0.051, blue: 0.063, alpha: 1 },
            { red: 0.129, green: 0.067, blue: 0.078, alpha: 1 }
        ]
    },
    'minecraft:prismarine_brick_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.431, green: 0.725, blue: 0.682, alpha: 1 },
            { red: 0.353, green: 0.686, blue: 0.643, alpha: 1 },
            { red: 0.38, green: 0.647, blue: 0.604, alpha: 1 }
        ]
    },
    'minecraft:prismarine_bricks_stairs': {
        hardness: 1.5,
        colors: [
            { red: 0.431, green: 0.725, blue: 0.682, alpha: 1 },
            { red: 0.353, green: 0.686, blue: 0.643, alpha: 1 },
            { red: 0.38, green: 0.647, blue: 0.604, alpha: 1 }
        ]
    },
    'minecraft:red_nether_brick': {
        hardness: 2,
        colors: [
            { red: 0.267, green: 0.02, blue: 0.027, alpha: 1 },
            { red: 0.18, green: 0, blue: 0.004, alpha: 1 },
            { red: 0.204, green: 0.004, blue: 0.012, alpha: 1 }
        ]
    },
    'minecraft:red_nether_brick_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.267, green: 0.02, blue: 0.027, alpha: 1 },
            { red: 0.18, green: 0, blue: 0.004, alpha: 1 },
            { red: 0.204, green: 0.004, blue: 0.012, alpha: 1 }
        ]
    },
    'minecraft:resin_brick_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.78, green: 0.286, blue: 0.039, alpha: 1 },
            { red: 0.89, green: 0.384, blue: 0.086, alpha: 1 },
            { red: 0.702, green: 0.243, blue: 0.075, alpha: 1 }
        ]
    },
    'minecraft:stone_brick_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.498, green: 0.498, blue: 0.498, alpha: 1 },
            { red: 0.545, green: 0.537, blue: 0.545, alpha: 1 },
            { red: 0.471, green: 0.463, blue: 0.471, alpha: 1 }
        ]
    },
    'minecraft:beetroot': {
        hardness: 0,
        colors: [
            { red: 0.29, green: 0.561, blue: 0.157, alpha: 1 },
            { red: 0.333, green: 0.671, blue: 0.176, alpha: 1 },
            { red: 0.149, green: 0.388, blue: 0.145, alpha: 1 }
        ]
    },
    'minecraft:carrots': {
        hardness: 0,
        colors: [
            { red: 0.169, green: 0.439, blue: 0.165, alpha: 1 },
            { red: 0.149, green: 0.388, blue: 0.145, alpha: 1 },
            { red: 0.29, green: 0.561, blue: 0.157, alpha: 1 }
        ]
    },
    'minecraft:cobblestone_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.533, green: 0.529, blue: 0.533, alpha: 1 },
            { red: 0.38, green: 0.38, blue: 0.38, alpha: 1 },
            { red: 0.431, green: 0.427, blue: 0.427, alpha: 1 }
        ]
    },
    'minecraft:cut_red_sandstone_double_slab': {
        hardness: 0.8,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 },
            { red: 0.824, green: 0.459, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:cut_sandstone_double_slab': {
        hardness: 0.8,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 },
            { red: 0.906, green: 0.894, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:deadbush': {
        hardness: 0,
        colors: [
            { red: 0.318, green: 0.239, blue: 0.141, alpha: 1 },
            { red: 0.404, green: 0.314, blue: 0.173, alpha: 1 },
            { red: 0.58, green: 0.392, blue: 0.157, alpha: 1 }
        ]
    },
    'minecraft:frame': {
        hardness: 0,
        colors: [
            { red: 0.514, green: 0.282, blue: 0.161, alpha: 1 },
            { red: 0.482, green: 0.267, blue: 0.161, alpha: 1 },
            { red: 0.643, green: 0.333, blue: 0.192, alpha: 1 }
        ]
    },
    'minecraft:frog_spawn': {
        hardness: 0,
        colors: [
            { red: 0.494, green: 0.435, blue: 0.404, alpha: 1 },
            { red: 0.451, green: 0.388, blue: 0.357, alpha: 1 },
            { red: 0.592, green: 0.529, blue: 0.498, alpha: 1 }
        ]
    },
    'minecraft:glow_frame': {
        hardness: 0,
        colors: [
            { red: 0.514, green: 0.282, blue: 0.161, alpha: 1 },
            { red: 0.482, green: 0.267, blue: 0.161, alpha: 1 },
            { red: 0.643, green: 0.333, blue: 0.192, alpha: 1 }
        ]
    },
    'minecraft:granite_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.624, green: 0.42, blue: 0.345, alpha: 1 },
            { red: 0.498, green: 0.337, blue: 0.275, alpha: 1 },
            { red: 0.663, green: 0.467, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:lit_pumpkin': {
        hardness: 1,
        colors: [
            { red: 0.89, green: 0.541, blue: 0.114, alpha: 1 },
            { red: 0.627, green: 0.337, blue: 0.043, alpha: 1 },
            { red: 0.769, green: 0.435, blue: 0.078, alpha: 1 }
        ]
    },
    'minecraft:lit_redstone_lamp': {
        hardness: 0.3,
        colors: [
            { red: 0.192, green: 0.102, blue: 0.067, alpha: 1 },
            { red: 0.525, green: 0.306, blue: 0.161, alpha: 1 },
            { red: 0.373, green: 0.2, blue: 0.082, alpha: 1 }
        ]
    },
    'minecraft:lit_redstone_ore': {
        hardness: 3,
        colors: [
            { red: 0.902, green: 0.125, blue: 0.031, alpha: 1 },
            { red: 0.451, green: 0.047, blue: 0, alpha: 1 },
            { red: 0.643, green: 0.094, blue: 0.031, alpha: 1 }
        ]
    },
    'minecraft:lit_smoker': {
        hardness: 3.5,
        colors: [
            { red: 0.404, green: 0.314, blue: 0.173, alpha: 1 },
            { red: 0.318, green: 0.239, blue: 0.141, alpha: 1 },
            { red: 0.522, green: 0.522, blue: 0.522, alpha: 1 }
        ]
    },
    'minecraft:mossy_cobblestone_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.322, green: 0.365, blue: 0.224, alpha: 1 },
            { red: 0.533, green: 0.529, blue: 0.533, alpha: 1 },
            { red: 0.384, green: 0.475, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:noteblock': {
        hardness: 0.8,
        colors: [
            { red: 0.161, green: 0.157, blue: 0.125, alpha: 1 },
            { red: 0.255, green: 0.157, blue: 0.094, alpha: 1 },
            { red: 0.58, green: 0.365, blue: 0.255, alpha: 1 }
        ]
    },
    'minecraft:polished_granite_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.624, green: 0.42, blue: 0.345, alpha: 1 },
            { red: 0.573, green: 0.384, blue: 0.318, alpha: 1 },
            { red: 0.663, green: 0.467, blue: 0.392, alpha: 1 }
        ]
    },
    'minecraft:sweet_berry_bush': {
        hardness: 0,
        colors: [
            { red: 0.161, green: 0.322, blue: 0.188, alpha: 1 },
            { red: 0.235, green: 0.431, blue: 0.259, alpha: 1 },
            { red: 0.157, green: 0.384, blue: 0.251, alpha: 1 }
        ]
    },
    'minecraft:pitcher_crop': {
        hardness: 0,
        colors: [
            { red: 0.624, green: 0.376, blue: 0.247, alpha: 1 },
            { red: 0.78, green: 0.647, blue: 0.408, alpha: 1 },
            { red: 0.769, green: 0.612, blue: 0.388, alpha: 1 }
        ]
    },
    'minecraft:red_sandstone_double_slab': {
        hardness: 0.8,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 },
            { red: 0.824, green: 0.459, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:reeds': {
        hardness: 0,
        colors: [
            { red: 0.51, green: 0.659, blue: 0.349, alpha: 1 },
            { red: 0.667, green: 0.859, blue: 0.455, alpha: 1 },
            { red: 0.898, green: 0.937, blue: 0.855, alpha: 1 }
        ]
    },
    'minecraft:sandstone_double_slab': {
        hardness: 0.8,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 },
            { red: 0.906, green: 0.894, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:smooth_red_sandstone_double_slab': {
        hardness: 0.8,
        colors: [
            { red: 0.753, green: 0.408, blue: 0.133, alpha: 1 },
            { red: 0.675, green: 0.341, blue: 0.071, alpha: 1 },
            { red: 0.824, green: 0.459, blue: 0.169, alpha: 1 }
        ]
    },
    'minecraft:smooth_sandstone_double_slab': {
        hardness: 0.8,
        colors: [
            { red: 0.855, green: 0.824, blue: 0.639, alpha: 1 },
            { red: 0.82, green: 0.729, blue: 0.541, alpha: 1 },
            { red: 0.906, green: 0.894, blue: 0.733, alpha: 1 }
        ]
    },
    'minecraft:smooth_stone_double_slab': {
        hardness: 2,
        colors: [
            { red: 0.659, green: 0.659, blue: 0.659, alpha: 1 },
            { red: 0.639, green: 0.639, blue: 0.639, alpha: 1 },
            { red: 0.69, green: 0.69, blue: 0.69, alpha: 1 }
        ]
    },
    'minecraft:trip_wire': {
        hardness: 0,
        colors: [
            { red: 0.561, green: 0.561, blue: 0.561, alpha: 1 },
            { red: 0.357, green: 0.357, blue: 0.357, alpha: 1 },
            { red: 0.467, green: 0.467, blue: 0.467, alpha: 1 }
        ]
    },
    'minecraft:dark_prismarine_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.192, green: 0.314, blue: 0.255, alpha: 1 },
            { red: 0.153, green: 0.243, blue: 0.212, alpha: 1 },
            { red: 0.247, green: 0.427, blue: 0.361, alpha: 1 }
        ]
    },
    'minecraft:dried_ghast': {
        hardness: 0,
        colors: [
            { red: 0.616, green: 0.561, blue: 0.561, alpha: 1 },
            { red: 0.443, green: 0.439, blue: 0.439, alpha: 1 },
            { red: 0.682, green: 0.612, blue: 0.612, alpha: 1 }
        ]
    },
    'minecraft:piston_arm_collision': {
        hardness: 1.5,
        colors: [
            { red: 0.369, green: 0.612, blue: 0.31, alpha: 1 },
            { red: 0.518, green: 0.78, blue: 0.455, alpha: 1 },
            { red: 0.42, green: 0.725, blue: 0.349, alpha: 1 }
        ]
    },
    'minecraft:prismarine_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.369, green: 0.643, blue: 0.557, alpha: 1 },
            { red: 0.608, green: 0.796, blue: 0.749, alpha: 1 },
            { red: 0.369, green: 0.522, blue: 0.643, alpha: 1 }
        ]
    },
    'minecraft:purpur_double_slab': {
        hardness: 1.5,
        colors: [
            { red: 0.698, green: 0.525, blue: 0.698, alpha: 1 },
            { red: 0.675, green: 0.482, blue: 0.675, alpha: 1 },
            { red: 0.643, green: 0.447, blue: 0.639, alpha: 1 }
        ]
    },
    'minecraft:sticky_piston_arm_collision': {
        hardness: 1.5,
        colors: [
            { red: 0.369, green: 0.612, blue: 0.31, alpha: 1 },
            { red: 0.518, green: 0.78, blue: 0.455, alpha: 1 },
            { red: 0.42, green: 0.725, blue: 0.349, alpha: 1 }
        ]
    }
}