import { EquipmentSlot, GameMode, Player } from "@minecraft/server";

/**
 * Gets the block located relative to an origin position,
 * based on a given facing direction and a side offset (front, back, right, left).
 *
 * This function rotates the side-offset vector according to the provided direction,
 * then adds it to the origin position to find the target block.
 *
 * @param {mc.Dimension} dimension - The Minecraft dimension to query.
 * @param {{x: number, y: number, z: number}} origin - The starting block position.
 * @param {string} direction - The facing direction used to rotate the offset (e.g., "north", "south", "east", "west").
 * @param {"front" | "back" | "right" | "left"} side - The relative side to check from the origin.
 * @returns {mc.Block | undefined} The block at the computed relative position, or undefined if out of bounds.
 */
export function getRelativeBlock(dimension, origin, direction, side) {
    const offset = rotateVectorByDirection({
        front: { x: 0, y: 0, z: 1 },
        back: { x: 0, y: 0, z: -1 },
        right: { x: 1, y: 0, z: 0 },
        left: { x: -1, y: 0, z: 0 }
    }[side], direction);

    return dimension.getBlock(sumVectors(origin, offset));
}

/**
 * Adds two 3D vectors and returns the resulting vector.
 *
 * @param {{x: number, y: number, z: number}} vectorA - The first vector to compare.
 * @param {{x: number, y: number, z: number}} vectorB - The second vector to compare.
 * @returns {{x: number, y: number, z: number}} A new vector representing the sum of both input vectors.
 */
export function sumVectors(vectorA, vectorB) {
    return {
        x: vectorA.x + vectorB.x,
        y: vectorA.y + vectorB.y,
        z: vectorA.z + vectorB.z
    }
}

/**
 * Compares two vectors to determine if they have the same coordinates.
 *
 * @param {{x: number, y: number, z: number}} vectorA - The first vector to compare.
 * @param {{x: number, y: number, z: number}} vectorB - The second vector to compare.
 * @returns {boolean} True if both vectors have identical x, y, and z values; otherwise, false.
 */
export function compareVectors(vectorA, vectorB) {
    return (vectorA.x == vectorB.x && vectorA.y == vectorB.y && vectorA.z == vectorB.z);
}

/**
 * Returns the distance between two vectors
 * @param {{x: number, y: number, z: number}} pointA - First vector.
 * @param {{x: number, y: number, z: number}} pointB - Second vector
 * @returns {number} - The distance between the two vectors.
 */
export function distanceBetween(pointA, pointB) {
    const dx = pointA.x - pointB.x
    const dy = pointA.y - pointB.y
    const dz = pointA.z - pointB.z
    return Math.sqrt(dx * dx + dy * dy + dz * dz)
}

/**
 * Returns the opposite cardinal direction (180° rotation).
 * @param {'north' | 'south' | 'east' | 'west'} dir - The original direction.
 * @returns {'north' | 'south' | 'east' | 'west'} - The opposite direction.
 */
export function oppositeDirection(dir) {
    switch (dir) {
        case 'north': return 'South';
        case 'south': return 'North';
        case 'east': return 'West';
        case 'west': return 'East';
        default:
            throw new Error("Invalid direction. Use 'north', 'south', 'east', or 'west'.");
    }
}

/**
 * Rotates a cardinal direction around the Y-axis by a given angle.
 * @param {'north' | 'south' | 'east' | 'west'} direction - The starting direction.
 * @param {number} angle - The angle in degrees (clockwise).
 * @returns {'north' | 'south' | 'east' | 'west'} - The resulting direction after rotation.
 */
export function rotateDirection(direction, angle) {
    const directions = ['north', 'east', 'south', 'west'];

    const index = directions.indexOf(direction);
    if (index === -1) {
        throw new Error("Invalid direction. Use 'north', 'south', 'east', or 'west'.");
    }

    // Calculate how many 90-degree steps to rotate
    const steps = Math.round(angle / 90) % 4;

    // Ensure the index stays within bounds (handle negative angles)
    const newIndex = (index + steps + 4) % 4;

    return directions[newIndex];
}

/**
 * Rotates a 3D vector around the Y-axis based on a cardinal direction.
 * @param {{x: number, y: number, z: number}} vector - The vector to be rotated.
 * @param {'north' | 'south' | 'east' | 'west'} direction - The direction to rotate towards.
 * @returns {{x: number, y: number, z: number}} - The rotated vector.
 */
export function rotateVectorByDirection(vector, direction) {
    const degreesMap = {
        north: 0,
        east: 90,
        south: 180,
        west: 270,
    };

    const degrees = degreesMap[direction];
    if (degrees === undefined) {
        throw new Error("Invalid direction. Use 'north', 'south', 'east', or 'west'.");
    }

    const radians = (degrees * Math.PI) / 180;
    const cos = Math.cos(radians);
    const sin = Math.sin(radians);

    const x = vector.x * cos - vector.z * sin;
    const z = vector.x * sin + vector.z * cos;

    return { x, y: vector.y, z };
}

/**
 * Gets the item equipped in a player's main hand.
 * @param {Player} player The target player.
 * @returns {Item|null} The item in the main hand, or null if there isn't one.
 */
export function getMainHandItem(player) {
    if (!player) return null;

    const comp = player.getComponent("equippable");
    if (!comp) return null;

    const mainHand = comp.getEquipmentSlot(EquipmentSlot.Mainhand);
    return mainHand.getItem() || null;
}

/**
 * Decreases the item stack size in the player's main hand by one. Doesn't work on creative mode.
 * 
 * @param {Player} player The target player.
 */
export function decrementStack(player) {
    if (!player) return null;

    const comp = player.getComponent("equippable");
    if (!comp) return null;

    const mainHand = comp.getEquipmentSlot(EquipmentSlot.Mainhand);
    if (!mainHand) return null;

    if (player.getGameMode() !== GameMode.Creative) {
        if (mainHand.amount > 1) {
            mainHand.amount--;
        } else {
            mainHand.setItem(undefined);
        }
    }
}

/**
 * Applies durability damage to an item held by the player.
 * 
 * @param {Player} player - The player holding the item.
 * @param {ItemStack} itemStack - The item stack to be damaged.
 * @param {number} amount - The number of durability points to attempt to remove.
 */
export function damageDurability(player, itemStack, amount) {
    if (!player || !itemStack || amount <= 0) return;

    const equippable = player.getComponent("minecraft:equippable");
    if (!equippable) return;

    const mainhand = equippable.getEquipmentSlot(EquipmentSlot.Mainhand);
    if (!mainhand.hasItem()) return;

    const durability = itemStack.getComponent("minecraft:durability");
    if (!durability) return;

    const enchantable = itemStack.getComponent("minecraft:enchantable");
    const unbreakingLevel = enchantable?.getEnchantment("unbreaking")?.level ?? 0;

    const damageChance = durability.getDamageChance(unbreakingLevel) / 100;

    let actualDamage = 0;

    for (let i = 0; i < amount; i++) {
        if (Math.random() < damageChance) {
            actualDamage++;
        }
    }

    if (actualDamage === 0) return;

    if ((durability.damage + actualDamage) >= durability.maxDurability) {
        mainhand.setItem(undefined);
        player.playSound("random.break");
    } else {
        durability.damage += actualDamage;
        mainhand.setItem(itemStack);
    }
}
