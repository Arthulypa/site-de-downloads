import * as mc from "@minecraft/server";
/** Bit mask to make a layer on the cube entity all visible. To make it be fully visible, apply this to every `cubes_half` property of it */
export const ALL_VISIBLE = 0b1111111111111111;


/**
* Calculates the Bit the must be set to one based on x and y, and the property it must be assigned to(The name is mask because it is used as a bit Mask)
* The values must be all between 0..4, except by `z` which is 0..3
* @param {number} x
* @param {number} y
* @param {number} z 
* @returns {{mask: number, prop: string}}
*/
export function calculateVisible(gridSize, x, y, z) {
    if (gridSize === 4) {
        z -= 3;
    } else {
        x = Math.floor(x);
        z = Math.floor(z);
    }
    x = Math.min(Math.max(0, Math.floor(Math.abs(x))), gridSize - 1);
    y = Math.min(Math.max(0, Math.floor(Math.abs(y))), gridSize - 1);
    z = Math.min(Math.max(0, Math.floor(Math.abs(z))), gridSize - 1);

    if (gridSize === 2) {
        const bitIndex = x + y * 2 + z * 2 * 2; // 0..7
        return {
            mask: 1 << bitIndex,
            prop: 'vtng_mb:bits'
        };
    }


    // fallback pro 4x4x4
    if (y > gridSize) y = gridSize;
    if (y == gridSize) x = 0;

    return {
        mask: 1 << Math.min(15, (y * gridSize + x)),
        prop: 'vtng_mb:cubes_half_' + z
    };
}
/**
 * Decodes the mask and prop back into x, y, z automatically detecting gridSize
 * @param {{mask: number, prop: string}} data 
 * @returns {{x: number, y: number, z: number, gridSize: number}}
 */
export function decodeVisible(data) {
    const { mask, prop } = data;

    // determina qual bit está ativo
    const bitIndex = Math.floor(Math.log2(mask));

    let x = 0, y = 0, z = 0, gridSize = 4;

    if (prop === 'vtng_mb:bits') {
        // gridSize 2 (2x2x2)
        gridSize = 2;
        z = Math.floor(bitIndex / 4);
        const rem = bitIndex % 4;
        y = Math.floor(rem / 2);
        x = rem % 2;
    } else if (prop.startsWith('vtng_mb:cubes_half_')) {
        // gridSize 4 (4x4x4)
        gridSize = 4;
        z = parseInt(prop.replace('vtng_mb:cubes_half_', ''), 10) || 0;
        const index = Math.min(15, bitIndex);
        y = Math.floor(index / gridSize);
        x = index % gridSize;
    } else {
        throw new Error(`Unknown property: ${prop}`);
    }

    return { x, y, z, gridSize };
}


/**
* Adds the active positions of `mask` on the `entity` on the given `prop` variable 
* @param {import("@minecraft/server").Entity} entity
* @param {number} mask
* @param {string} prop
*/
export function addVisible(entity, mask, prop) {
    entity.setProperty(prop, entity.getProperty(prop) | mask);
}

/**
* Removes the active positions of `mask` on the `entity` on the given `prop` variable 
* @param {import("@minecraft/server").Entity} entity
* @param {number} mask
* @param {string} prop
*/
export function removeVisible(entity, mask, prop) {
    entity.setProperty(prop, entity.getProperty(prop) & ~mask);

    mc.system.runTimeout(() => {
        if (!entity.isValid) return;

        const miniblockConditions = (entity.getProperty("vtng_mb:cubes_half_0") === 0 && entity.getProperty("vtng_mb:cubes_half_1") === 0 && entity.getProperty("vtng_mb:cubes_half_2") === 0 && entity.getProperty("vtng_mb:cubes_half_3") === 0);
        const microblockConditions = entity.getProperty("vtng_mb:bits") === 0;

        if (miniblockConditions || microblockConditions) { entity.remove(); };
    }, 5);
}

export function isJSONParsable(str) {
    try {
        return JSON.parse(str);
    } catch (e) {
        return false;
    }
}

export function calculateRelativeVector(vector1, vector2) {
    return {
        x: vector2.x - vector1.x,
        y: vector2.y - vector1.y,
        z: vector2.z - vector1.z
    };
}


export function blockFaceToDirection(face) {
    if (face == 'Up') return 'above'; else
        if (face == 'Down') return 'below'; else
            if (face?.includes('up')) return 'above'; else
                if (face?.includes('down')) return 'below'; else
                    if (face == 'North') return 'north'; else
                        if (face == 'South') return 'south'; else
                            if (face == 'West') return 'west'; else
                                if (face == 'East') return 'east'; else return (face)
}

export function blockFaceToTraits(face) {
    if (face == 'above') return 'up'; else
        if (face == 'below') return 'down'; else
            if (face == 'Up') return 'up'; else
                if (face == 'Down') return 'down'; else
                    if (face == 'North') return 'north'; else
                        if (face == 'South') return 'south'; else
                            if (face == 'West') return 'west'; else
                                if (face == 'East') return 'east'; else return (face)
}

export function relativeToAbsolute(base, relative) {
    return {
        x: base.x + relative.x,
        y: base.y + relative.y,
        z: base.z + relative.z
    };
}

export function createDashedLine(viewDirection, playerPosition, numSegments, segmentLength, segmentStart) {
    const directionMagnitude = Math.sqrt(viewDirection.x * viewDirection.x + viewDirection.y * viewDirection.y + viewDirection.z * viewDirection.z);
    viewDirection.x /= directionMagnitude;
    viewDirection.y /= directionMagnitude;
    viewDirection.z /= directionMagnitude;
    let points = [];
    for (let i = segmentStart; i < numSegments; i++) {
        let distance = i * segmentLength;
        let point = {
            x: playerPosition.x + viewDirection.x * distance,
            y: playerPosition.y + viewDirection.y * distance,
            z: playerPosition.z + viewDirection.z * distance
        };
        points.push(point);
    }
    return points;
}