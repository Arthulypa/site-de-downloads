import * as mc from "@minecraft/server";

import * as racoAPI from "./utils/raco-API";
import * as vikAPI from "./utils/vikAPI";
import { blockBit } from "./classes/BlockBit";
import { worldGrid } from "./classes/WorldGrid";

import {
    placeSounds,
    blocksTypeIds,
    unBuildableBlocks,
} from "./consts/miniblocksConfig";

mc.world.beforeEvents.playerBreakBlock.subscribe((event) => {
    const { block, itemStack } = event;

    if (block.typeId != "vtng_mb:phantom_block" || (itemStack && itemStack.typeId == "vtng_mb:hammer")) return;

    mc.world.sendMessage({ translate: "miniblocks.warning.cant_break" })
    event.cancel = true;
})

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe((event) => {
    const { entity, eventId } = event;
    if (eventId !== "vtng_mb:update_collision" || !entity.isValid) return;

    const { dimension, location } = entity;

    let collisionType;
    let grid;

    if (entity.typeId === "vtng_mb:miniblock") {
        collisionType = "vtng_mb:quarter_collision";
        grid = 2;
    } else if (
        entity.typeId === "vtng_mb:microblock" ||
        entity.typeId === "vtng_mb:nanoblock"
    ) {
        collisionType = "vtng_mb:subquarter_collision";
        grid = 4;
    } else {
        return;
    }

    const variant = entity.getProperty("vtng_mb:variant");
    if (variant === undefined) return;

    const nanoPart =
        entity.typeId === "vtng_mb:nanoblock"
            ? entity.getProperty("vtng_mb:part")
            : undefined;

    let hasNearbyPlayer = false;
    for (const player of mc.world.getAllPlayers()) {
        if (vikAPI.distanceBetween(player.location, location) <= 4) {
            hasNearbyPlayer = true;
            break;
        }
    }

    if (!hasNearbyPlayer) {
        for (const e of dimension.getEntities({
            location,
            maxDistance: 0.5,
            type: collisionType
        })) {
            if (e.getDynamicProperty("vtng_mb:variant") !== variant) continue;
            if (nanoPart !== undefined && e.getDynamicProperty("vtng_mb:part") !== nanoPart) continue;
            e.remove();
        }

        entity.setDynamicProperty("last_properties", undefined);
        return;
    }

    const props =
        entity.typeId === "vtng_mb:miniblock"
            ? { variant, bits: entity.getProperty("vtng_mb:bits") }
            : entity.typeId === "vtng_mb:microblock"
                ? {
                    variant,
                    h0: entity.getProperty("vtng_mb:cubes_half_0"),
                    h1: entity.getProperty("vtng_mb:cubes_half_1"),
                    h2: entity.getProperty("vtng_mb:cubes_half_2"),
                    h3: entity.getProperty("vtng_mb:cubes_half_3")
                }
                : {
                    variant,
                    part: nanoPart,
                    h0: entity.getProperty("vtng_mb:cubes_half_0"),
                    h1: entity.getProperty("vtng_mb:cubes_half_1"),
                    h2: entity.getProperty("vtng_mb:cubes_half_2"),
                    h3: entity.getProperty("vtng_mb:cubes_half_3")
                };

    const serialized = JSON.stringify(props);
    if (entity.getDynamicProperty("last_properties") === serialized) return;
    entity.setDynamicProperty("last_properties", serialized);

    for (const e of dimension.getEntities({
        location,
        maxDistance: 0.75,
        type: collisionType
    })) {
        if (e.getDynamicProperty("vtng_mb:variant") !== variant) continue;
        if (nanoPart !== undefined && e.getDynamicProperty("vtng_mb:part") !== nanoPart) continue;
        e.remove();
    }

    let cubes;

    if (entity.typeId === "vtng_mb:nanoblock") {
        cubes = blockBit
            .parseNanoblock(entity)
            .flatMap(c => blockBit.convertCube(c, 8, 4));
    } else if (entity.typeId === "vtng_mb:microblock") {
        cubes = blockBit.parseMicroblock(entity);
    } else {
        cubes = blockBit.parseMiniblock(entity);
    }

    if (!cubes || cubes.length === 0) return;

    const gridOffset = 1 / (grid * 2);
    const base = {
        x: Math.floor(location.x) + gridOffset,
        y: Math.floor(location.y),
        z: Math.floor(location.z) + gridOffset
    };

    for (const cube of cubes) {
        const collision = dimension.spawnEntity(
            collisionType,
            vikAPI.sumVectors(cube, base)
        );

        collision.setDynamicProperty("vtng_mb:variant", variant);
        if (nanoPart !== undefined) {
            collision.setDynamicProperty("vtng_mb:part", nanoPart);
        }
    }
});

//Place little block
mc.world.afterEvents.playerInteractWithEntity.subscribe((event) => {
    const { player, target, itemStack } = event;

    const { dimension } = player;
    const typeId = itemStack.typeId
        .replace("vtng_mb:nanoblock_", "")
        .replace("vtng_mb:microblock_", "")
        .replace("vtng_mb:miniblock_", "");

    if (
        (target.typeId !== "vtng_mb:view_blocker" &&
            target.typeId !== "vtng_mb:nanoblock") ||
        (!itemStack.typeId.startsWith("vtng_mb:nanoblock") &&
            !itemStack.typeId.startsWith("vtng_mb:microblock") &&
            !itemStack.typeId.startsWith("vtng_mb:miniblock"))
    )
        return;

    const gridSize = itemStack.typeId?.startsWith("vtng_mb:nanoblock")
        ? 8
        : itemStack.typeId?.startsWith("vtng_mb:microblock")
            ? 4
            : 2;

    const offset = 1 / (gridSize * 2);
    const vectors = {
        above: { x: 0, y: offset, z: 0 },
        below: { x: 0, y: -offset, z: 0 },
        north: { x: 0, y: 0, z: -offset },
        south: { x: 0, y: 0, z: offset },
        west: { x: -offset, y: 0, z: 0 },
        east: { x: offset, y: 0, z: 0 },
    };
    const vectors2 = {
        above: { x: 0, y: offset * 2, z: 0 },
        below: { x: 0, y: -offset * 2, z: 0 },
        north: { x: 0, y: 0, z: -offset * 2 },
        south: { x: 0, y: 0, z: offset * 2 },
        west: { x: -offset * 2, y: 0, z: 0 },
        east: { x: offset * 2, y: 0, z: 0 },
    };

    const allBlockBits = blockBit.allBlockBits(player, gridSize);
    if (allBlockBits.length > 0) {
        const hit = worldGrid.blockBitRaycastHit(
            player,
            allBlockBits,
            gridSize
        );

        if (hit) {
            const thisPoint = allBlockBits[hit.index];
            const newPoint = racoAPI.relativeToAbsolute(
                thisPoint,
                vectors2[hit.face]
            );
            const block = dimension.getBlock(newPoint);

            if (block.typeId != "vtng_mb:phantom_block" && !block.isAir && (unBuildableBlocks.includes(block.typeId) || block.canContainLiquid("Water") || !block.canBeDestroyedByLiquidSpread("Water"))) {
                mc.world.sendMessage({ translate: "miniblocks.warning.cant_place_here" })
                return;
            };

            blockBit.placeBlockBit(
                block,
                blocksTypeIds.indexOf(typeId),
                newPoint,
                gridSize
            );
            vikAPI.decrementStack(player);
            dimension.playSound(placeSounds.get(typeId), newPoint);
            return;
        }
    }

    const grid = worldGrid.getSnappedGridPosition(player, gridSize);
    if (!grid) return;

    const newPoint = {
        x: grid.loc.x + vectors[grid.blockFace].x,
        y: grid.loc.y + vectors[grid.blockFace].y,
        z: grid.loc.z + vectors[grid.blockFace].z,
    };

    const block = dimension.getBlock(newPoint);

    if (block.typeId != "vtng_mb:phantom_block" && !block.isAir && (unBuildableBlocks.includes(block.typeId) || block.canContainLiquid("Water") || !block.canBeDestroyedByLiquidSpread("Water"))) {
        mc.world.sendMessage({ translate: "miniblocks.warning.cant_place_here" })
        return;
    };

    blockBit.placeBlockBit(
        block,
        blocksTypeIds.indexOf(typeId),
        newPoint,
        gridSize
    );
    vikAPI.decrementStack(player);
    dimension.playSound(placeSounds.get(typeId), newPoint);
});

mc.world.afterEvents.entityHitEntity.subscribe((event) => {
    const { damagingEntity, hitEntity } = event;
    const { dimension } = damagingEntity;

    if (
        damagingEntity.typeId !== "minecraft:player" ||
        hitEntity.typeId !== "vtng_mb:view_blocker"
    )
        return;

    const selectedItem = damagingEntity
        .getComponent("equippable")
        .getEquipment("Mainhand");

    if (selectedItem.typeId !== "vtng_mb:chisel") return;

    let playerProperties = damagingEntity.getDynamicProperty(
        "vtng_mb:player_properties"
    );

    const { selectedGridSize } = JSON.parse(playerProperties);

    const gridSize = selectedGridSize;

    const offset = 1 / (gridSize * 2);
    const vectors = {
        above: { x: 0, y: offset, z: 0 },
        below: { x: 0, y: -offset, z: 0 },
        north: { x: 0, y: 0, z: -offset },
        south: { x: 0, y: 0, z: offset },
        west: { x: -offset, y: 0, z: 0 },
        east: { x: offset, y: 0, z: 0 },
    };

    const allBlockBits = blockBit.allBlockBits(damagingEntity, gridSize);
    const hit = worldGrid.blockBitRaycastHit(
        damagingEntity,
        allBlockBits,
        gridSize
    );

    if (!hit || !allBlockBits) {
        const grid = worldGrid.getSnappedGridPosition(damagingEntity, gridSize);
        if (!grid) return;

        if (!blocksTypeIds.includes(grid.block.typeId.replace("minecraft:", ""))) {
            mc.world.sendMessage({ translate: "miniblocks.warning.cant_transform" })
            return;
        };

        const index = blocksTypeIds.indexOf(grid.block.typeId.split(":")[1]);
        if (index === -1) return;

        const pillarAxis = grid.block.permutation.getState('pillar_axis');
        if (pillarAxis && pillarAxis != "y") {
            mc.world.sendMessage({ translate: "miniblocks.warning.cant_transform_due_to_limitations" })
            return;
        };

        let littleBlock;

        littleBlock = dimension.spawnEntity(
            "vtng_mb:miniblock",
            grid.block.center()
        );

        littleBlock.setProperty("vtng_mb:bits", 0xffff);
        littleBlock.setProperty("vtng_mb:variant", index);

        const newPoint = {
            x: grid.loc.x - vectors[grid.blockFace].x,
            y: grid.loc.y - vectors[grid.blockFace].y,
            z: grid.loc.z - vectors[grid.blockFace].z,
        };

        dimension.setBlockType(grid.block.location, "vtng_mb:phantom_block");
        mc.system.waitTicks(1).then((_) => {
            blockBit.removeBlockBit(grid.block, newPoint, gridSize);
            dimension.spawnParticle("vtng_mb:dust_particle", grid.block.center());
        });
    } else {
        const thisPoint = allBlockBits[hit.index];
        const block = dimension.getBlock(thisPoint);

        blockBit.removeBlockBit(block, thisPoint, gridSize);

        mc.system.runTimeout(() => {
            if (dimension.getEntitiesAtBlockLocation(block.location).filter(e => e.typeId == "vtng_mb:miniblock" || e.typeId == "vtng_mb:microblock" || e.typeId == "vtng_mb:nanoblock").length == 0) {
                dimension.setBlockType(block.location, "air")
            }
        }, 5)
    }
});

mc.world.afterEvents.playerSpawn.subscribe((event) => {
    if (!event.player.getDynamicProperty("has_guide_book")) {
        event.player.setDynamicProperty("has_guide_book", true);

        event.player.runCommand("give @s vtng_mb:guide_book");
    }
});