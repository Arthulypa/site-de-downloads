import * as mc from "@minecraft/server";

import * as racoAPI from "../utils/raco-API";
import { blocksTypeIds, unBuildableBlocks } from "../consts/miniblocksConfig";

class WorldGrid {
    /**
     * Casts a ray through a list of boxes and returns the nearest *visible* face it hits.
     * Performs per-face intersection checks and ray occlusion tests against world blocks.
     * 
     * @param {mc.Dimension} dimension - Dimension to check visibility and block collisions.
     * @param {Array} boxes - Array of boxes, each defined by 8 vertex objects {x, y, z}.
     * @param {Object} rayOrigin - Starting position of the ray.
     * @param {Object} rayDirection - Normalized direction vector of the ray.
     * @returns {{ index: number, face: string, point: Object } | null}
     */
    raycastToBoxes(dimension, boxes, rayOrigin, rayDirection) {
        let closestHit = null;
        let closestDistance = Infinity;

        function intersectPlane(planeCoord, axis, min, max, faceName) {
            const denom = rayDirection[axis];
            if (denom === 0) return null;

            const t = (planeCoord - rayOrigin[axis]) / denom;
            if (t < 0) return null;

            const px = rayOrigin.x + rayDirection.x * t;
            const py = rayOrigin.y + rayDirection.y * t;
            const pz = rayOrigin.z + rayDirection.z * t;

            if (
                (axis === "x" &&
                    (py < min.y || py > max.y || pz < min.z || pz > max.z)) ||
                (axis === "y" &&
                    (px < min.x || px > max.x || pz < min.z || pz > max.z)) ||
                (axis === "z" &&
                    (px < min.x || px > max.x || py < min.y || py > max.y))
            )
                return null;

            return {
                point: { x: px, y: py, z: pz },
                face: faceName,
                distance: t,
            };
        }

        function isFaceVisible(origin, target, dim) {
            let x0 = origin.x,
                y0 = origin.y,
                z0 = origin.z;

            const dx = target.x - x0;
            const dy = target.y - y0;
            const dz = target.z - z0;

            const stepX = dx > 0 ? 1 : -1;
            const stepY = dy > 0 ? 1 : -1;
            const stepZ = dz > 0 ? 1 : -1;

            const tDeltaX = dx === 0 ? Infinity : Math.abs(1 / dx);
            const tDeltaY = dy === 0 ? Infinity : Math.abs(1 / dy);
            const tDeltaZ = dz === 0 ? Infinity : Math.abs(1 / dz);

            let voxelX = Math.floor(x0);
            let voxelY = Math.floor(y0);
            let voxelZ = Math.floor(z0);

            const startX = voxelX;
            const startY = voxelY;
            const startZ = voxelZ;

            const endX = Math.floor(target.x);
            const endY = Math.floor(target.y);
            const endZ = Math.floor(target.z);

            let tMaxX =
                dx === 0
                    ? Infinity
                    : (stepX > 0 ? voxelX + 1 - x0 : x0 - voxelX) * tDeltaX;
            let tMaxY =
                dy === 0
                    ? Infinity
                    : (stepY > 0 ? voxelY + 1 - y0 : y0 - voxelY) * tDeltaY;
            let tMaxZ =
                dz === 0
                    ? Infinity
                    : (stepZ > 0 ? voxelZ + 1 - z0 : z0 - voxelZ) * tDeltaZ;

            while (true) {
                if (
                    !(voxelX === startX && voxelY === startY && voxelZ === startZ)
                ) {
                    const block = dim.getBlock({ x: voxelX, y: voxelY, z: voxelZ });

                    if (
                        block &&
                        block.typeId !== "vtng_mb:phantom_block" &&
                        !block.isAir &&
                        block.isLiquidBlocking("Water")
                    ) {
                        return false;
                    }
                }

                if (voxelX === endX && voxelY === endY && voxelZ === endZ)
                    break;

                if (tMaxX < tMaxY) {
                    if (tMaxX < tMaxZ) {
                        voxelX += stepX;
                        tMaxX += tDeltaX;
                    } else {
                        voxelZ += stepZ;
                        tMaxZ += tDeltaZ;
                    }
                } else {
                    if (tMaxY < tMaxZ) {
                        voxelY += stepY;
                        tMaxY += tDeltaY;
                    } else {
                        voxelZ += stepZ;
                        tMaxZ += tDeltaZ;
                    }
                }
            }

            return true;
        }

        for (let index = 0; index < boxes.length; index++) {
            const verts = boxes[index];

            let min = { x: verts[0].x, y: verts[0].y, z: verts[0].z };
            let max = { ...min };
            for (let i = 1; i < verts.length; i++) {
                const v = verts[i];
                if (v.x < min.x) min.x = v.x;
                if (v.x > max.x) max.x = v.x;
                if (v.y < min.y) min.y = v.y;
                if (v.y > max.y) max.y = v.y;
                if (v.z < min.z) min.z = v.z;
                if (v.z > max.z) max.z = v.z;
            }

            const candidates = [
                intersectPlane(min.x, "x", min, max, "west"),
                intersectPlane(max.x, "x", min, max, "east"),
                intersectPlane(min.y, "y", min, max, "below"),
                intersectPlane(max.y, "y", min, max, "above"),
                intersectPlane(min.z, "z", min, max, "north"),
                intersectPlane(max.z, "z", min, max, "south"),
            ];

            for (const hit of candidates) {
                if (hit && hit.distance < closestDistance) {
                    if (isFaceVisible(rayOrigin, hit.point, dimension)) {
                        closestHit = {
                            index,
                            face: hit.face,
                            point: hit.point,
                        };
                        closestDistance = hit.distance;
                    }
                }
            }
        }

        return closestHit;
    }

    /**
     * Performs a raycast from the player's view to detect which blockBit face is being targeted.
     * 
     * @param {mc.Player} player - The player performing the raycast.
     * @param {Array} blockBits - Array of blockBit center positions.
     * @param {Number} gridSize - Subdivision size (e.g., 2, 4, 8).
     * @returns {{ index: number, face: string, point: Object } | null}
     */
    blockBitRaycastHit(player, blockBits, gridSize) {
        if (blockBits?.length == 0) return;

        const origin = player.getHeadLocation();
        origin.y += 0.1005;

        const viewDirection = player.getViewDirection();

        const half = 1 / (gridSize * 2);

        const cubeVertices = [
            { x: half, y: -half, z: half },
            { x: -half, y: -half, z: -half },
            { x: -half, y: -half, z: half },
            { x: half, y: -half, z: -half },
            { x: half, y: half, z: half },
            { x: -half, y: half, z: -half },
            { x: -half, y: half, z: half },
            { x: half, y: half, z: -half },
        ];

        const boxes = [];
        for (const center of blockBits) {
            const cube = [];
            for (const relative of cubeVertices) {
                cube.push(racoAPI.relativeToAbsolute(center, relative));
            }
            boxes.push(cube);
        }

        return this.raycastToBoxes(player.dimension, boxes, origin, viewDirection);
    }

    /**
     * Returns the snapped grid position on the face of the block the player is targeting.
     * Useful for placing blockBits aligned to a specific grid size.
     * 
     * @param {mc.Player} player - The player performing the raycast.
     * @param {Number} gridSize - The grid subdivision size (e.g., 2, 4, 8).
     * @returns {{ loc: Object, blockFace: string, block: mc.Block } | false}
     */
    getSnappedGridPosition(player, gridSize) {
        const { dimension } = player;

        const playerHeadLoc = player.getHeadLocation();
        playerHeadLoc.y += 0.1005;

        const playerViewDir = player.getViewDirection();
        const cellSize = 1 / gridSize;

        const playerRaycastHit = dimension.getBlockFromRay(
            playerHeadLoc,
            playerViewDir,
            { maxDistance: 8, includePassableBlocks: true, excludeTypes: ["vtng_mb:phantom_block"] }
        );
        if (!playerRaycastHit) return false;

        const { block, face, faceLocation } = playerRaycastHit;

        if (!blocksTypeIds.includes(block.typeId.replace("minecraft:", "")) && (block.canContainLiquid("Water") || !block.isLiquidBlocking("Water"))) return false;

        const blockFace = racoAPI.blockFaceToDirection(face);

        const snap = (value) =>
            Math.floor(value / cellSize) * cellSize + cellSize / 2;

        let snapX, snapY;
        switch (blockFace) {
            case "above":
            case "below":
                snapX = snap(faceLocation.x);
                snapY = snap(faceLocation.z);
                break;
            case "north":
            case "south":
                snapX = snap(faceLocation.x);
                snapY = snap(faceLocation.y);
                break;
            case "west":
            case "east":
                snapX = snap(faceLocation.z);
                snapY = snap(faceLocation.y);
                break;
        }

        const snappedFaceLocation = (() => {
            switch (blockFace) {
                case "above":
                    return { x: snapX, y: 1, z: snapY };
                case "below":
                    return { x: snapX, y: 0, z: snapY };
                case "north":
                    return { x: snapX, y: snapY, z: faceLocation.z };
                case "south":
                    return { x: snapX, y: snapY, z: faceLocation.z + 1 };
                case "west":
                    return { x: faceLocation.x, y: snapY, z: snapX };
                case "east":
                    return { x: faceLocation.x + 1, y: snapY, z: snapX };
                default:
                    return faceLocation;
            }
        })();

        const worldPos = racoAPI.relativeToAbsolute(block, snappedFaceLocation);

        if (!unBuildableBlocks.includes(block?.typeId)) {
            return { loc: worldPos, blockFace, block: block };
        } else return false;
    }

}

export const worldGrid = new WorldGrid();