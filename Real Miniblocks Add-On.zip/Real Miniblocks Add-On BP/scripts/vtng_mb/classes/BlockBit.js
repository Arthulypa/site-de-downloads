import * as mc from "@minecraft/server";

import * as racoAPI from "../utils/raco-API";
import * as vikAPI from "../utils/vikAPI";
import { breakSounds, blocksTypeIds, destructionParticles, miniBlocksTypes } from "../consts/miniblocksConfig";

class BlockBit {
    /**
     * Rebuilds a blockBit entity at a given grid size by re-adding all cubes except the removed one.
     * Creates the correct bit masks for the entity and ensures visual consistency.
     * 
     * @param {mc.Block} block - The base block that holds the blockBit entity.
     * @param {Array<Object>} cubes - Array of cube positions to restore (each with x, y, z, gridSize).
     * @param {string} variant - Variant identifier (used for textures or types).
     * @param {{x: number, y: number, z: number}} point - The cube position that was removed (to skip).
     * @param {number} toGrid - The target grid size (2, 4, or 8).
     * @returns {Array<Object>} The cubes that matched the removed point (skipped during rebuild).
     */
    replaceCubes(block, cubes, variant, point, toGrid) {
        const { dimension } = block;
        const center = block.center();

        const typeToPlace =
            toGrid === 8 ? "vtng_mb:nanoblock" :
                toGrid === 4 ? "vtng_mb:microblock" :
                    "vtng_mb:miniblock";

        let cubesToConvert = [];

        if (toGrid === 8) {
            /** @type {Map<number, {cubes_half_0:number,cubes_half_1:number,cubes_half_2:number,cubes_half_3:number}>} */
            const masksByPart = new Map();

            for (const cube of cubes) {
                const relativeLoc = {
                    x: (cube.x % 1) * cube.gridSize,
                    y: (cube.y % 1) * cube.gridSize,
                    z: (cube.z % 1) * cube.gridSize,
                };

                if (
                    relativeLoc.x === point.x &&
                    relativeLoc.y === point.y &&
                    relativeLoc.z === point.z
                ) {
                    cubesToConvert.push(cube);
                    continue;
                }

                const mantissa = {
                    x: Math.floor(relativeLoc.x),
                    y: Math.floor(relativeLoc.y),
                    z: Math.floor(relativeLoc.z),
                };

                const part = this.getNanoblockPart(mantissa);
                const local = this.getNanoblockLocalPoint(mantissa);
                const bit = this.calcBitVisibility(4, local);

                if (!masksByPart.has(part)) {
                    masksByPart.set(part, {
                        cubes_half_0: 0,
                        cubes_half_1: 0,
                        cubes_half_2: 0,
                        cubes_half_3: 0
                    });
                }

                masksByPart.get(part)[bit.property] |= bit.mask;
            }

            for (const [part, masks] of masksByPart.entries()) {
                let nanoPart = dimension.getEntities({
                    type: "vtng_mb:nanoblock",
                    location: center,
                    maxDistance: 0.5
                }).find(e =>
                    e.getProperty("vtng_mb:variant") === variant &&
                    e.getProperty("vtng_mb:part") === part
                );

                if (!nanoPart) {
                    nanoPart = dimension.spawnEntity("vtng_mb:nanoblock", center);
                    nanoPart.setProperty("vtng_mb:variant", variant);
                    nanoPart.setProperty("vtng_mb:part", part);
                }

                for (const property in masks) {
                    if (masks[property] !== 0) {
                        this.addBit(nanoPart, {
                            property,
                            mask: masks[property]
                        });
                    }
                }
            }

            return cubesToConvert;
        }

        let cubeToSpawn = dimension
            .getEntities({ location: center, maxDistance: 0.5 })
            .find(e =>
                e.typeId === typeToPlace &&
                e.getProperty("vtng_mb:variant") === variant
            );

        if (!cubeToSpawn) {
            cubeToSpawn = dimension.spawnEntity(typeToPlace, center);
            cubeToSpawn.setProperty("vtng_mb:variant", variant);
        }

        const masks = {
            cubes_half_0: 0,
            cubes_half_1: 0,
            cubes_half_2: 0,
            cubes_half_3: 0
        };

        for (const cube of cubes) {
            const relativeLoc = {
                x: (cube.x % 1) * cube.gridSize,
                y: (cube.y % 1) * cube.gridSize,
                z: (cube.z % 1) * cube.gridSize,
            };

            if (
                relativeLoc.x === point.x &&
                relativeLoc.y === point.y &&
                relativeLoc.z === point.z
            ) {
                cubesToConvert.push(cube);
                continue;
            }

            const bit = this.calcBitVisibility(cube.gridSize, relativeLoc);
            masks[bit.property] |= bit.mask;
        }

        for (const property in masks) {
            if (masks[property] !== 0) {
                this.addBit(cubeToSpawn, {
                    property,
                    mask: masks[property]
                });
            }
        }

        return cubesToConvert;
    }

    /**
     * Converts a cube's position between two different grid resolutions.
     * Expands or merges cubes depending on whether the target grid is larger or smaller.
     * 
     * @param {{ x: number, y: number, z: number, gridSize: number }} cube - Cube position and source grid size.
     * @param {number} fromGrid - Original grid size (e.g., 2, 4, 8).
     * @param {number} toGrid - Target grid size to convert to.
     * @returns {Array<{ x: number, y: number, z: number, gridSize: number }>} Converted cube(s) in the target grid.
     */
    convertCube(cube, fromGrid, toGrid) {
        if (fromGrid === toGrid) return [cube];

        const factor = toGrid / fromGrid;

        if (factor > 1) {
            const results = [];
            const mx = Math.floor(cube.x * toGrid);
            const my = Math.floor(cube.y * toGrid);
            const mz = Math.floor(cube.z * toGrid);
            for (let dx = 0; dx < factor; dx++) {
                for (let dy = 0; dy < factor; dy++) {
                    for (let dz = 0; dz < factor; dz++) {
                        results.push({
                            x: (mx + dx) / toGrid,
                            y: (my + dy) / toGrid,
                            z: (mz + dz) / toGrid,
                            gridSize: toGrid
                        });
                    }
                }
            }
            return results;
        }

        const mx = Math.floor(cube.x * toGrid);
        const my = Math.floor(cube.y * toGrid);
        const mz = Math.floor(cube.z * toGrid);

        return [{
            x: mx / toGrid,
            y: my / toGrid,
            z: mz / toGrid,
            gridSize: toGrid
        }];
    }

    /**
     * Parses a nanoblock entity (8×8×8 grid) and returns its cube position within the parent block.
     * 
     * @param {mc.Entity} blockBit - The nanoblock entity to parse.
     * @returns {Array<{ x: number, y: number, z: number, gridSize: number }>} The nanoblock's cube position.
     */
    parseNanoblock(blockBit) {
        const cubes = [];

        const part = blockBit.getProperty("vtng_mb:part");
        const offset = [
            { x: 0, y: 0, z: 0 },
            { x: 4, y: 0, z: 0 },
            { x: 0, y: 4, z: 0 },
            { x: 4, y: 4, z: 0 },
            { x: 0, y: 0, z: 4 },
            { x: 4, y: 0, z: 4 },
            { x: 0, y: 4, z: 4 },
            { x: 4, y: 4, z: 4 },
        ][part];

        const bits = [
            blockBit.getProperty("vtng_mb:cubes_half_0"),
            blockBit.getProperty("vtng_mb:cubes_half_1"),
            blockBit.getProperty("vtng_mb:cubes_half_2"),
            blockBit.getProperty("vtng_mb:cubes_half_3")
        ];

        for (let h = 0; h < 4; h++) {
            const mask = bits[h];
            const z = (3 - h); // igual microblock

            for (let i = 0; i < 16; i++) {
                if ((mask >> i) & 1) {
                    const x = (i % 4);
                    const y = Math.floor(i / 4);

                    cubes.push({
                        x: (offset.x + x) / 8,
                        y: (offset.y + y) / 8,
                        z: (offset.z + z) / 8,
                        gridSize: 8
                    });
                }
            }
        }

        return cubes;
    }

    /**
     * Parses a 4×4×4 microblock entity and returns all active cube positions.
     * 
     * @param {mc.Entity} blockBit - The microblock entity to parse.
     * @returns {Array<{ x: number, y: number, z: number, gridSize: number }>} List of active cubes.
     */
    parseMicroblock(blockBit) {
        const cubes = [];
        const bits = [
            blockBit.getProperty("vtng_mb:cubes_half_0"),
            blockBit.getProperty("vtng_mb:cubes_half_1"),
            blockBit.getProperty("vtng_mb:cubes_half_2"),
            blockBit.getProperty("vtng_mb:cubes_half_3")
        ];
        for (let h = 0; h < 4; h++) {
            const mask = bits[h];
            const z = (3 - h) * 0.25;
            for (let i = 0; i < 16; i++) {
                if ((mask >> i) & 1) {
                    const x = (i % 4) * 0.25;
                    const y = Math.floor(i / 4) * 0.25;
                    cubes.push({ x, y, z, gridSize: 4 });
                }
            }
        }
        return cubes;
    }

    /**
     * Parses a 2×2×2 miniblock entity and returns all active cube positions.
     * 
     * @param {mc.Entity} blockBit - The miniblock entity to parse.
     * @returns {Array<{ x: number, y: number, z: number, gridSize: number }>} List of active cubes.
     */
    parseMiniblock(blockBit) {
        const cubes = [];
        const mask = blockBit.getProperty("vtng_mb:bits");
        for (let i = 0; i < 8; i++) {
            if ((mask >> i) & 1) {
                const x = (i % 2) * 0.5;
                const y = Math.floor(i / 2) % 2 * 0.5;
                const z = Math.floor(i / 4) * 0.5;
                cubes.push({ x, y, z, gridSize: 2 });
            }
        }
        return cubes;
    }

    /**
     * Collects all visible blockBit entities along the player's line of sight,
     * converting their cube data to a unified grid size.
     * 
     * @param {mc.Player} player - The player whose view direction is used for scanning.
     * @param {number} gridSize - Target grid size to normalize all blockBits to.
     * @returns {Array<{ x: number, y: number, z: number, gridSize: number }>} List of all converted cubes.
     */
    allBlockBits(player, gridSize) {
        const playerHeadLoc = player.getHeadLocation();
        playerHeadLoc.y += 0.1005;

        const dashedLine = racoAPI.createDashedLine(player.getViewDirection(), playerHeadLoc, 30, 0.3, 0);
        const blockBits = [];
        const seenBits = new Set();

        for (const point of dashedLine) {
            for (const blockBit of player.dimension.getEntities({ families: ["blockBit"], location: point, maxDistance: 1 })) {
                const { location, typeId, id } = blockBit;

                if (seenBits.has(id)) continue;
                seenBits.add(id);

                let cubes = [];

                switch (typeId) {
                    case "vtng_mb:nanoblock":
                        cubes = this.parseNanoblock(blockBit);
                        break;
                    case "vtng_mb:microblock":
                        cubes = this.parseMicroblock(blockBit);
                        break;
                    case "vtng_mb:miniblock":
                        cubes = this.parseMiniblock(blockBit);
                        break;
                }

                const converted = cubes.flatMap(c => this.convertCube(c, c.gridSize, gridSize));

                const base = {
                    x: Math.floor(location.x) + 1 / (gridSize * 2),
                    y: Math.floor(location.y) + 1 / (gridSize * 2),
                    z: Math.floor(location.z) + 1 / (gridSize * 2)
                }

                for (const v of converted) {
                    v.x += base.x;
                    v.y += base.y;
                    v.z += base.z;
                }

                blockBits.push(...converted);
            }
        }

        return blockBits;
    }

    /**
     * Converts a point from one grid to another, returning all possible matching points
     * if the grids don't align 1:1.
     * 
     * @param {{x:number, y:number, z:number}} point - Point in the source grid.
     * @param {number} sourceGridSize - The original grid size (e.g., 2,4,8)
     * @param {number} targetGridSize - The target grid size (e.g., 2,4,8)
     * @returns {Array<{x:number,y:number,z:number}>} - All possible points in the target grid
    */
    convertMantissaPoint(point, sourceGridSize, targetGridSize) {
        const factor = targetGridSize / sourceGridSize;

        if (factor === 1) {
            return [{ ...point }];
        } else if (factor > 1) {
            const points = [];
            for (let dx = 0; dx < factor; dx++) {
                for (let dy = 0; dy < factor; dy++) {
                    for (let dz = 0; dz < factor; dz++) {
                        points.push({
                            x: point.x * factor + dx,
                            y: point.y * factor + dy,
                            z: point.z * factor + dz
                        });
                    }
                }
            }
            return points;
        } else {
            return [{
                x: Math.floor(point.x * factor),
                y: Math.floor(point.y * factor),
                z: Math.floor(point.z * factor)
            }];
        }
    }

    /**
     * Calculates the local fractional position (mantissa) of a point within a subdivided grid cell.
     * 
     * @param {mc.Vector3} point - World position of the hit or target point.
     * @param {number} gridOffset - Offset value used to align the grid correctly.
     * @param {number} gridSize - Number of subdivisions per block (e.g., 2, 4, 8).
     * @returns {{ x: number, y: number, z: number }} Local point within the grid.
     */
    calcMantissaPoint(point, gridOffset, gridSize) {
        return {
            x:
                (Math.abs(point.x - Math.floor(point.x)) - gridOffset) *
                gridSize,
            y:
                (Math.abs(point.y - Math.floor(point.y)) - gridOffset) *
                gridSize,
            z:
                (Math.abs(point.z - Math.floor(point.z)) - gridOffset) *
                gridSize,
        }
    }

    /**
     * Determines which bit (mask and property) corresponds to the given local point.
     * 
     * @param {number} gridSize - Grid subdivision size (e.g., 2, 4, 8).
     * @param {mc.Vector3} point - Local position within the block grid.
     * @returns {{ property: string, mask: number }} The target property and bit mask.
     */
    calcBitVisibility(gridSize, point) {
        let { x, y, z } = point;

        if (gridSize == 4) {
            z -= 3;
        } else {
            x = Math.floor(x);
            z = Math.floor(z);
        }

        x = Math.min(Math.max(0, Math.floor(Math.abs(x))), gridSize - 1);
        y = Math.min(Math.max(0, Math.floor(Math.abs(y))), gridSize - 1);
        z = Math.min(Math.max(0, Math.floor(Math.abs(z))), gridSize - 1);

        if (gridSize == 2) {
            const bitIndex = x + y * 2 + z * 2 * 2;
            return {
                property: "vtng_mb:bits",
                mask: 1 << bitIndex,
            }
        }

        if (y > gridSize) y = gridSize;
        if (y == gridSize) x = 0;

        return {
            property: "vtng_mb:cubes_half_" + z,
            mask: 1 << Math.min(15, y * gridSize + x),
        }
    }
    /**
     * Calcula a máscara final de miniblock (2x2x2) baseada
     * em TODOS os blockBits presentes no bloco (nano/micro/mini).
     *
     * @param {mc.Block} block
     * @returns {number} miniMask (8 bits)
     */
    computeMiniMask(block) {
        const { dimension } = block;
        const center = block.center();

        let miniMask = 0;

        const entities = dimension
            .getEntitiesAtBlockLocation(block.location)
            .filter(e => [
                "vtng_mb:nanoblock",
                "vtng_mb:microblock",
                "vtng_mb:miniblock"
            ].includes(e.typeId));

        for (const e of entities) {
            let cubes = [];

            switch (e.typeId) {
                case "vtng_mb:nanoblock":
                    cubes = this.parseNanoblock(e);
                    break;

                case "vtng_mb:microblock":
                    cubes = this.parseMicroblock(e);
                    break;

                case "vtng_mb:miniblock":
                    cubes = this.parseMiniblock(e);
                    break;
            }

            const miniCubes = cubes.flatMap(c =>
                this.convertCube(c, c.gridSize, 2)
            );

            for (const cube of miniCubes) {
                const mx = Math.floor(cube.x * 2);
                const my = Math.floor(cube.y * 2);
                const mz = Math.floor(cube.z * 2);

                const bitIndex = mx + my * 2 + mz * 4;
                miniMask |= (1 << bitIndex);
            }
        }

        return miniMask;
    }

    updateCollision(blockBit) {
        if (!blockBit || !blockBit.isValid) return;

        blockBit.triggerEvent("vtng_mb:update_collision");

        const block = blockBit.dimension.getBlock(blockBit.location);
        if (block?.typeId === "vtng_mb:phantom_block") {
            const miniMask = this.computeMiniMask(block);

            if (miniMask == 0) {
                blockBit.dimension.setBlockType(block.location, "minecraft:air");

                for (const entity of blockBit.dimension.getEntitiesAtBlockLocation(block.location).filter(e => miniBlocksTypes.includes(e.typeId) || e.typeId == "vtng_mb:quarter_collision" || e.typeId == "vtng_mb:subquarter_collision")) entity.remove();
            } else {
                this.updatePhantomSelection(block, miniMask);
            }
        }
    }

    updatePhantomSelection(block, miniMask) {
        let permutation = block.permutation;

        for (let i = 0; i < 8; i++) {
            permutation = permutation.withState(
                `vtng_mb:cube_${i}`,
                Boolean(miniMask & (1 << i))
            );
        }

        block.setPermutation(permutation);
    }

    /**
     * Sets (activates) the specified bit in the given blockBit's bit properties.
     * 
     * @param {mc.Entity} blockBit - The blockBit entity to modify.
     * @param {{ property: string, mask: number }} bitVisibility - Target property and bit mask.
     */
    addBit(blockBit, bitVisibility) {
        let { property, mask } = bitVisibility;

        blockBit.setProperty(property, blockBit.getProperty(property) | mask);

        mc.system.waitTicks(1).then(() => {
            this.updateCollision(blockBit);
        });
    }

    /**
     * Clears (deactivates) the specified bit from the given blockBit's properties.
     * If all bits become empty, the entity will automatically be removed.
     * 
     * @param {mc.Entity} blockBit - The blockBit entity to modify.
     * @param {{ property: string, mask: number }} bitVisibility - Target property and bit mask.
     */
    removeBit(blockBit, bitVisibility) {
        const { property, mask } = bitVisibility;

        if (!blockBit) return;

        const current = blockBit.getProperty(property);
        blockBit.setProperty(property, current & ~mask);

        mc.system.waitTicks(1).then(() => {
            this.updateCollision(blockBit);
        });
    }

    getNanoblockPart(mantissaPoint) {
        const px = Math.floor(mantissaPoint.x / 4);
        const py = Math.floor(mantissaPoint.y / 4);
        const pz = Math.floor(mantissaPoint.z / 4);
        return px + py * 2 + pz * 4;
    }

    getNanoblockLocalPoint(mantissaPoint) {
        return {
            x: mantissaPoint.x % 4,
            y: mantissaPoint.y % 4,
            z: mantissaPoint.z % 4
        };
    }

    isMicroCubeCompleteFromNano(nanoParts) {
        for (const p of nanoParts) {
            if (
                p.getProperty("vtng_mb:cubes_half_0") !== 0xFFFF ||
                p.getProperty("vtng_mb:cubes_half_1") !== 0xFFFF ||
                p.getProperty("vtng_mb:cubes_half_2") !== 0xFFFF ||
                p.getProperty("vtng_mb:cubes_half_3") !== 0xFFFF
            ) return false;
        }
        return true;
    }

    isMiniCubeCompleteFromMicro(microBlock, microPoints) {
        for (const p of microPoints) {
            const v = this.calcBitVisibility(4, p);
            if (!(microBlock.getProperty(v.property) & v.mask)) return false;
        }
        return true;
    }

    /**
     * Places or updates a blockBit entity at the specified location based on the grid size.
     * Handles correct variant type (miniblock/microblock/nanoblock),
     * sets UV offsets, and applies the appropriate bit mask.
     * 
     * @param {mc.Block} block - The block used as placement reference.
     * @param {number} variant - Variant ID of the blockBit type.
     * @param {mc.Vector3} point - World position where the blockBit should be placed.
     * @param {number} gridSize - Grid subdivision size (e.g., 2, 4, 8).
     */
    placeBlockBit(block, variant, point, gridSize) {
        const { dimension } = block;
        const blockCenter = block.center();

        const gridOffset = 1 / (gridSize * 2);
        const mantissaPoint = this.calcMantissaPoint(
            point,
            gridOffset,
            gridSize
        );
        const bitVisibility = this.calcBitVisibility(gridSize, mantissaPoint);

        const typeToPlace =
            gridSize == 8
                ? "vtng_mb:nanoblock"
                : gridSize == 4
                    ? "vtng_mb:microblock"
                    : "vtng_mb:miniblock";
        let blockBit;

        mc.system.runTimeout(() => {
            let allCubes = [];

            for (const e of dimension.getEntitiesAtBlockLocation(block.location).filter(e => miniBlocksTypes.includes(e.typeId))) {
                let cubes = [];

                switch (e.typeId) {
                    case "vtng_mb:nanoblock":
                        cubes = this.parseNanoblock(e);
                        break;
                    case "vtng_mb:microblock":
                        cubes = this.parseMicroblock(e);
                        break;
                    case "vtng_mb:miniblock":
                        cubes = this.parseMiniblock(e);
                        break;
                };

                let convertedCubes = cubes.flatMap(c => this.convertCube(c, c.gridSize, 8));

                for (const cube of convertedCubes) {
                    if (e.getProperty("vtng_mb:variant") == variant) {
                        allCubes.push(cube);
                    }
                }
            }

            if (allCubes.length == 512) {
                for (const e of dimension.getEntitiesAtBlockLocation(block.location).filter(e => miniBlocksTypes.includes(e.typeId) || e.typeId == "vtng_mb:quarter_collision" || e.typeId == "vtng_mb:subquarter_collision")) {
                    e.remove();
                };

                dimension.setBlockType(block.location, "minecraft:" + blocksTypeIds[variant])
            }
        }, 5)

        if (gridSize === 8) {
            const part = this.getNanoblockPart(mantissaPoint);
            const localPoint = this.getNanoblockLocalPoint(mantissaPoint);
            const nanoVisibility = this.calcBitVisibility(4, localPoint);

            let nanoblock = dimension.getEntities({
                type: "vtng_mb:nanoblock",
                location: blockCenter,
                maxDistance: 0.5
            }).find(e =>
                e.getProperty("vtng_mb:variant") === variant &&
                e.getProperty("vtng_mb:part") === part
            );

            if (!nanoblock) {
                nanoblock = dimension.spawnEntity("vtng_mb:nanoblock", blockCenter);
                nanoblock.setProperty("vtng_mb:variant", variant);
                nanoblock.setProperty("vtng_mb:part", part);
            }

            this.addBit(nanoblock, nanoVisibility);

            const convertedMantissaPoint = this.convertMantissaPoint(mantissaPoint, 8, 4)[0];
            const thisMantissaPoints = this.convertMantissaPoint(convertedMantissaPoint, 4, 8);

            let placedBits = 0;

            const nanoMasks = new Map();

            for (const thisMantissaPoint of thisMantissaPoints) {
                const part = this.getNanoblockPart(thisMantissaPoint);
                const local = this.getNanoblockLocalPoint(thisMantissaPoint);
                const thisBitVisibility = this.calcBitVisibility(4, local);

                const nanoPart = dimension.getEntities({
                    type: "vtng_mb:nanoblock",
                    location: blockCenter,
                    maxDistance: 0.5
                }).find(e =>
                    e.getProperty("vtng_mb:variant") === variant &&
                    e.getProperty("vtng_mb:part") === part
                );

                if (
                    (
                        part === this.getNanoblockPart(mantissaPoint) &&
                        thisBitVisibility.property === nanoVisibility.property &&
                        thisBitVisibility.mask === nanoVisibility.mask
                    ) ||
                    (
                        nanoPart &&
                        nanoPart.isValid &&
                        (nanoPart.getProperty(thisBitVisibility.property) & thisBitVisibility.mask)
                    )
                ) {
                    placedBits++;

                    if (!nanoMasks.has(nanoPart)) {
                        nanoMasks.set(nanoPart, {
                            cubes_half_0: 0,
                            cubes_half_1: 0,
                            cubes_half_2: 0,
                            cubes_half_3: 0
                        });
                    }

                    nanoMasks.get(nanoPart)[thisBitVisibility.property] |= thisBitVisibility.mask;
                }
            }

            if (placedBits === 8) {
                for (const [nanoPart, masks] of nanoMasks.entries()) {

                    if (!nanoPart || !nanoPart.isValid) continue;

                    for (const property in masks) {
                        if (masks[property] !== 0) {
                            const current = nanoPart.getProperty(property);
                            nanoPart.setProperty(property, current & ~masks[property]);
                        }
                    }

                    const stillHasBits =
                        nanoPart.getProperty("vtng_mb:cubes_half_0") |
                        nanoPart.getProperty("vtng_mb:cubes_half_1") |
                        nanoPart.getProperty("vtng_mb:cubes_half_2") |
                        nanoPart.getProperty("vtng_mb:cubes_half_3");

                    if (stillHasBits === 0) {
                        nanoPart.remove();
                    }
                }

                let microBlock = dimension.getEntities({
                    type: "vtng_mb:microblock",
                    location: blockCenter,
                    maxDistance: 0.5
                }).find(e => e.getProperty("vtng_mb:variant") === variant);

                if (!microBlock) {
                    microBlock = dimension.spawnEntity("vtng_mb:microblock", blockCenter);
                    microBlock.setProperty("vtng_mb:variant", variant);
                }

                const microVisibility = this.calcBitVisibility(4, convertedMantissaPoint);
                this.addBit(microBlock, microVisibility);

                const microMantissaPoint = convertedMantissaPoint;
                const miniConvertedPoint = this.convertMantissaPoint(microMantissaPoint, 4, 2)[0];
                const microMantissaPoints = this.convertMantissaPoint(miniConvertedPoint, 2, 4);

                let microPlacedBits = 0;

                const microMasks = {
                    cubes_half_0: 0,
                    cubes_half_1: 0,
                    cubes_half_2: 0,
                    cubes_half_3: 0
                };

                for (const mp of microMantissaPoints) {
                    const microBitVisibility = this.calcBitVisibility(4, mp);

                    if (
                        (microBitVisibility.property === microVisibility.property &&
                            microBitVisibility.mask === microVisibility.mask) ||
                        (microBlock.getProperty(microBitVisibility.property) &
                            microBitVisibility.mask)
                    ) {
                        microPlacedBits++;
                        microMasks[microBitVisibility.property] |= microBitVisibility.mask;
                    }
                }

                if (microPlacedBits === 8) {
                    for (const property in microMasks) {
                        if (microMasks[property] !== 0) {
                            this.removeBit(microBlock, {
                                property,
                                mask: microMasks[property]
                            });
                        }
                    }

                    let miniBlock = dimension.getEntities({
                        type: "vtng_mb:miniblock",
                        location: blockCenter,
                        maxDistance: 0.5
                    }).find(e => e.getProperty("vtng_mb:variant") === variant);

                    if (!miniBlock) {
                        miniBlock = dimension.spawnEntity("vtng_mb:miniblock", blockCenter);
                        miniBlock.setProperty("vtng_mb:variant", variant);
                    }

                    const miniVisibility = this.calcBitVisibility(2, miniConvertedPoint);
                    this.addBit(miniBlock, miniVisibility);

                    return;
                }

                return;
            }
        } else {
            blockBit = dimension
                .getEntitiesAtBlockLocation(blockCenter)
                .find(
                    (e) =>
                        e.getProperty("vtng_mb:variant") == variant &&
                        e.typeId == typeToPlace
                );
            if (!blockBit) {
                blockBit = dimension.spawnEntity(typeToPlace, blockCenter);
                blockBit.setProperty("vtng_mb:variant", variant);
            } else if (blockBit && typeToPlace == "vtng_mb:microblock") {
                const convertedMantissaPoint = this.convertMantissaPoint(mantissaPoint, 4, 2)[0];
                const thisMantissaPoints = this.convertMantissaPoint(convertedMantissaPoint, 2, 4);

                let placedBits = 0;

                const masks = {
                    cubes_half_0: 0,
                    cubes_half_1: 0,
                    cubes_half_2: 0,
                    cubes_half_3: 0
                }

                for (const thisMantissaPoint of thisMantissaPoints) {
                    const thisBitVisibility = this.calcBitVisibility(gridSize, thisMantissaPoint);

                    if ((thisBitVisibility.property == bitVisibility.property && thisBitVisibility.mask == bitVisibility.mask) || (blockBit.getProperty(thisBitVisibility.property) & thisBitVisibility.mask)) {
                        placedBits++;

                        masks[thisBitVisibility.property] |= thisBitVisibility.mask;
                    }
                }

                if (placedBits == 8) {
                    for (const property in masks) {
                        if (masks[property] !== 0) this.removeBit(blockBit, { mask: masks[property], property: property });
                    }

                    let cubeToSpawn = dimension
                        .getEntities({ location: blockCenter, maxDistance: 0.5 })
                        .find(e =>
                            e.typeId === "vtng_mb:miniblock" &&
                            e.getProperty("vtng_mb:variant") === variant
                        );
                    if (!cubeToSpawn) {
                        cubeToSpawn = dimension.spawnEntity("vtng_mb:miniblock", blockCenter);

                        cubeToSpawn.setProperty("vtng_mb:variant", variant);
                    }

                    const thisBitVisibility = this.calcBitVisibility(2, convertedMantissaPoint);
                    this.addBit(cubeToSpawn, thisBitVisibility);

                    return;
                }
            }

            this.addBit(blockBit, bitVisibility);
        }

        block.setType("vtng_mb:phantom_block");
    }

    /**
     * Converts a mantissaPoint into a real-world position (center of the cube).
     * 
     * @param {mc.Block} block - The base block where the grid is located.
     * @param {{x:number, y:number, z:number}} mantissaPoint - The local grid point (ranging from 0 to gridSize).
     * @param {number} gridSize - The grid subdivision size (2, 4, or 8).
     * @returns {{x:number, y:number, z:number}} - The world-space position of the cube's center.
     */
    mantissaToWorld(block, mantissaPoint, gridSize) {
        const gridOffset = 1 / (gridSize * 2);

        return {
            x: block.location.x + (mantissaPoint.x / gridSize) + gridOffset,
            y: block.location.y + (mantissaPoint.y / gridSize) + gridOffset,
            z: block.location.z + (mantissaPoint.z / gridSize) + gridOffset,
        }
    }

    /**
     * Spawns the corresponding item after a block bit is broken.
     * 
     * @param {mc.Dimension} dimension - The dimension where the item will be spawned.
     * @param {{x: number, y: number, z: number}} location - The world position where the item should appear.
     * @param {string} type - The base item type identifier.
     * @param {number} variant - The block variant index used to determine the correct item type and sound.
     */
    spawnItemAfterBreak(dimension, location, type = false, variant) {
        let itemType;

        if (type == "vtng_mb:miniblock" || type == "vtng_mb:microblock" || type == "vtng_mb:nanoblock") {
            itemType = type + "_" + blocksTypeIds[variant];
        } else itemType = type;

        const item = dimension.spawnItem(new mc.ItemStack(itemType), location);
        dimension.playSound(breakSounds.get(blocksTypeIds[variant]), location);

        item.teleport(location);

        try {
            const destructionParticle = destructionParticles[itemType.replace("vtng_mb:miniblock_", "minecraft:").replace("vtng_mb:microblock_", "minecraft:").replace("vtng_mb:nanoblock_", "minecraft:")];
            const map = new mc.MolangVariableMap();
            map.setColorRGBA("color", {
                red: destructionParticle.colors[0].red,
                green: destructionParticle.colors[0].green,
                blue: destructionParticle.colors[0].blue,
                alpha: destructionParticle.colors[0].alpha
            });
            map.setFloat("size", type == "vtng_mb:miniblock" ? 0.0375 : type == "vtng_mb:microblock" ? 0.0275 : 0.0175);
            dimension.spawnParticle("vtng_mb:mini_block_destruction", location, map);
        } catch { };
    }

    /**
     * Calculates the base position (center offset) for a subdivided cube grid at a given location.
     * Used to align points to the center of the smallest grid units.
     *
     * @param {{x: number, y: number, z: number}} location - The original world position.
     * @param {number} gridSize - The subdivision size (e.g., 2, 4, 8).
     * @returns {{x: number, y: number, z: number}} The base position aligned to the grid center.
     */
    getBase(location, gridSize) {
        return {
            x: Math.floor(location.x) + 1 / (gridSize * 2),
            y: Math.floor(location.y) + 1 / (gridSize * 2),
            z: Math.floor(location.z) + 1 / (gridSize * 2)
        }
    }

    /**
     * Converts a point between two different grid resolutions (e.g., from 2x2x2 to 4x4x4).
     * Keeps the point’s relative position consistent within the base cube space.
     *
     * @param {{x: number, y: number, z: number}} point - The point to convert.
     * @param {{x: number, y: number, z: number}} location - The base world location of the cube.
     * @param {number} fromGrid - The source grid resolution (e.g., 2, 4, 8).
     * @param {number} toGrid - The target grid resolution (e.g., 2, 4, 8).
     * @returns {{x: number, y: number, z: number}} The converted point position in the new grid.
     */
    convertPoint(point, location, fromGrid, toGrid) {
        const pointToCube = {
            x: point.x - location.x,
            y: point.y - location.y,
            z: point.z - location.z,
        };

        const convertedCube = this.convertCube(pointToCube, fromGrid, toGrid)[0];
        const thisBase = this.getBase(location, toGrid);

        return {
            x: convertedCube.x + thisBase.x,
            y: convertedCube.y + thisBase.y,
            z: convertedCube.z + thisBase.z,
        };
    }
    /**
     * Removes a small block ("blockBit") at a specific grid position within a base block.
     * Handles mixed grid sizes (2x2x2, 4x4x4, 8x8x8) by converting and rebuilding
     * lower- or higher-resolution blocks when necessary.
     * 
     * @param {mc.Block} block - The base block containing the bit.
     * @param {{x: number, y: number, z: number}} point - The hit position within the block (0–1 normalized).
     * @param {number} gridSize - The subdivision size of the bit (e.g., 2, 4, 8).
     */
    removeBlockBit(block, point, gridSize) {
        const { dimension } = block;
        const blockCenter = block.center();

        const gridOffset = 1 / (gridSize * 2);
        const mantissaPoint = this.calcMantissaPoint(point, gridOffset, gridSize);
        const bitVisibility = this.calcBitVisibility(gridSize, mantissaPoint);

        const typeToRemove = gridSize == 8 ? "vtng_mb:nanoblock" : gridSize == 4 ? "vtng_mb:microblock" : "vtng_mb:miniblock";

        let entitiesAtBlock = dimension.getEntitiesAtBlockLocation(blockCenter);
        let blockBit;

        if (gridSize === 8) {
            const part = this.getNanoblockPart(mantissaPoint);
            const local = this.getNanoblockLocalPoint(mantissaPoint);
            const nanoVisibility = this.calcBitVisibility(4, local);

            blockBit = dimension.getEntities({
                type: "vtng_mb:nanoblock",
                location: blockCenter,
                maxDistance: 0.5
            }).find(e =>
                e.getProperty("vtng_mb:part") === part &&
                (e.getProperty(nanoVisibility.property) & nanoVisibility.mask)
            );

            if (blockBit) {
                this.spawnItemAfterBreak(
                    dimension,
                    point,
                    "vtng_mb:nanoblock",
                    blockBit.getProperty("vtng_mb:variant")
                );

                this.removeBit(blockBit, nanoVisibility);
            }
        }
        else {
            blockBit = dimension.getEntities({
                location: blockCenter,
                maxDistance: 0.5
            }).find(e =>
                e.typeId === typeToRemove &&
                (e.getProperty(bitVisibility.property) & bitVisibility.mask)
            );

            if (blockBit) {
                this.spawnItemAfterBreak(dimension, point, typeToRemove, blockBit.getProperty("vtng_mb:variant"));
                this.removeBit(blockBit, bitVisibility);
            }
        }

        if (!blockBit) {
            for (const type of ["vtng_mb:miniblock", "vtng_mb:microblock", "vtng_mb:nanoblock"]) {
                const blockBits = entitiesAtBlock.filter(e => e.typeId === type);

                const thisGridSize = {
                    "vtng_mb:miniblock": 2,
                    "vtng_mb:microblock": 4,
                    "vtng_mb:nanoblock": 8
                }[type];

                for (const blockBit of blockBits) {
                    const thisPoint = this.convertPoint(point, block.location, gridSize, thisGridSize);

                    const thisGridOffset = 1 / (thisGridSize * 2);
                    const thisMantissaPoint = this.calcMantissaPoint(thisPoint, thisGridOffset, thisGridSize);
                    const convertedMantissaPoint = this.convertMantissaPoint(mantissaPoint, gridSize, thisGridSize)[0];
                    const thisBitVisibility = this.calcBitVisibility(thisGridSize, convertedMantissaPoint);

                    if ((blockBit.getProperty(thisBitVisibility.property) & thisBitVisibility.mask) && vikAPI.compareVectors(thisMantissaPoint, convertedMantissaPoint)) {
                        const variant = blockBit.getProperty("vtng_mb:variant");
                        const itemType = typeToRemove + "_" + blocksTypeIds[variant];
                        if (thisGridSize < gridSize) {
                            let cubes = [];

                            switch (type) {
                                case "vtng_mb:nanoblock":
                                    cubes = this.parseNanoblock(blockBit);
                                    break;
                                case "vtng_mb:microblock":
                                    cubes = this.parseMicroblock(blockBit);
                                    break;
                                case "vtng_mb:miniblock":
                                    cubes = this.parseMiniblock(blockBit);
                                    break;
                            }

                            cubes = cubes.filter(cube => {
                                const relativeLoc = {
                                    x: (cube.x % 1) * cube.gridSize,
                                    y: (cube.y % 1) * cube.gridSize,
                                    z: (cube.z % 1) * cube.gridSize
                                };

                                return (
                                    convertedMantissaPoint.x === relativeLoc.x &&
                                    convertedMantissaPoint.y === relativeLoc.y &&
                                    convertedMantissaPoint.z === relativeLoc.z
                                );
                            });

                            if (gridSize == 8) {
                                let convertedCubes;

                                if (thisGridSize == 2) {
                                    const microBlockPoint = this.convertPoint(point, block.location, gridSize, 4);
                                    const microBlockMantissaPoint = this.convertMantissaPoint(thisMantissaPoint, thisGridSize, 4).filter(mp => vikAPI.compareVectors(mp, this.calcMantissaPoint(microBlockPoint, 1 / (4 * thisGridSize), 4)))[0];

                                    convertedCubes = cubes.flatMap(c => this.convertCube(c, c.gridSize, 4));

                                    this.replaceCubes(block, convertedCubes, variant, microBlockMantissaPoint, 4);

                                    convertedCubes = convertedCubes.filter(cube => {
                                        const relativeLoc = {
                                            x: (cube.x % 1) * cube.gridSize,
                                            y: (cube.y % 1) * cube.gridSize,
                                            z: (cube.z % 1) * cube.gridSize
                                        };

                                        return (
                                            microBlockMantissaPoint.x == relativeLoc.x &&
                                            microBlockMantissaPoint.y == relativeLoc.y &&
                                            microBlockMantissaPoint.z == relativeLoc.z
                                        );
                                    });
                                } else convertedCubes = cubes.flatMap(c => this.convertCube(c, c.gridSize, gridSize));

                                this.replaceCubes(block, convertedCubes.flatMap(c => this.convertCube(c, c.gridSize, 8)), variant, mantissaPoint, gridSize);
                            } else {
                                let convertedCubes = cubes.flatMap(c => this.convertCube(c, c.gridSize, gridSize));

                                this.replaceCubes(block, convertedCubes, variant, mantissaPoint, gridSize);
                            }
                        }

                        this.removeBit(blockBit, thisBitVisibility);
                        this.spawnItemAfterBreak(dimension, thisPoint, itemType, variant);
                    }
                }
            }
        }
    }
}

export const blockBit = new BlockBit();
