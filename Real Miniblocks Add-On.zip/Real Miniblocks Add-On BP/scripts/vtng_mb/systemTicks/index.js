import { world, system } from "@minecraft/server";

import displayBoxes from "./runIntervals/displayBoxes";

const jobs = [
    displayBoxes
];

system.runInterval(() => {
    for (const job of jobs) job.code();
}, 0);