import * as mc from "@minecraft/server";
import { blockBit } from "../../classes/BlockBit";
import { worldGrid } from "../../classes/WorldGrid";
import { unBuildableBlocks, blocksTypeIds } from "../../consts/miniblocksConfig";
import * as vikAPI from "../../utils/vikAPI";

function computePlayerBitData(player, gridSize) {
    const allBlockBits = blockBit.allBlockBits(player, gridSize);
    const hit = worldGrid.blockBitRaycastHit(player, allBlockBits, gridSize);
    const gridPos = worldGrid.getSnappedGridPosition(player, gridSize);

    return { allBlockBits, hit, gridPos };
}

function displayConstructionBox(player, entities, isHolding, gridSize, bitData) {
    const dimension = player.dimension;

    const cellSize = 1 / gridSize;
    const halfCell = cellSize / 2;
    const cell1_5 = cellSize * 1.5;

    const { allBlockBits, hit, gridPos } = bitData;

    let displayAt;

    if (hit) {
        const bitPos = allBlockBits[hit.index];

        switch (hit.face) {
            case "above": displayAt = { x: bitPos.x, y: bitPos.y + halfCell, z: bitPos.z }; break;
            case "below": displayAt = { x: bitPos.x, y: bitPos.y - cell1_5, z: bitPos.z }; break;
            case "north": displayAt = { x: bitPos.x, y: bitPos.y - halfCell, z: bitPos.z - cellSize }; break;
            case "south": displayAt = { x: bitPos.x, y: bitPos.y - halfCell, z: bitPos.z + cellSize }; break;
            case "west": displayAt = { x: bitPos.x - cellSize, y: bitPos.y - halfCell, z: bitPos.z }; break;
            case "east": displayAt = { x: bitPos.x + cellSize, y: bitPos.y - halfCell, z: bitPos.z }; break;
            default: displayAt = bitPos; break;
        }
    } else if (!hit && gridPos) {
        const bitPos = gridPos.loc;

        switch (gridPos.blockFace) {
            case "below": displayAt = { x: bitPos.x, y: bitPos.y - cellSize, z: bitPos.z }; break;
            case "north": displayAt = { x: bitPos.x, y: bitPos.y - halfCell, z: bitPos.z - halfCell }; break;
            case "south": displayAt = { x: bitPos.x, y: bitPos.y - halfCell, z: bitPos.z + halfCell }; break;
            case "west": displayAt = { x: bitPos.x - halfCell, y: bitPos.y - halfCell, z: bitPos.z }; break;
            case "east": displayAt = { x: bitPos.x + halfCell, y: bitPos.y - halfCell, z: bitPos.z }; break;
            default: displayAt = bitPos; break;
        }
    }

    if (!displayAt) {
        for (const entity of entities.filter(e => e?.isValid !== false && e.typeId == "vtng_mb:construction_box" && e.getDynamicProperty("owner") === player.nameTag)) {
            if (!entity?.isValid) continue;
            entity.remove();
        }
        return;
    }

    {
        const ownedBoxes = entities.filter(e =>
            e?.isValid !== false &&
            e.typeId == "vtng_mb:construction_box" &&
            e.getDynamicProperty("owner") === player.nameTag
        );

        if (ownedBoxes.length > 0) {
            let closest = ownedBoxes[0];
            let minDist = vikAPI.distanceBetween(closest.location, displayAt);

            for (const b of ownedBoxes) {
                if (!b?.isValid) continue;
                const d = vikAPI.distanceBetween(b.location, displayAt);
                if (d < minDist) { minDist = d; closest = b; }
            }

            for (const b of ownedBoxes) {
                if (!b?.isValid) continue;
                const d = vikAPI.distanceBetween(b.location, displayAt);

                if (b !== closest && d > 0.01) {
                    if (b?.isValid) b.remove();
                } else if (d > 0.75) {
                    if (b?.isValid) b.remove();
                }
            }
        }
    }

    const block = dimension.getBlock(displayAt);

    let box = entities
        .filter(e => e?.isValid !== false && e.typeId == "vtng_mb:construction_box" && e.getDynamicProperty("owner") === player.nameTag)
        .find(e => vikAPI.distanceBetween(e.location, displayAt) <= 1);

    if (box && box.getDynamicProperty("owner") === player.nameTag) {
        if (
            vikAPI.distanceBetween(box.location, displayAt) > 0.01 ||
            isHolding === "none"
        ) {
            if (box?.isValid) box.remove();
            box = null;
        }
    }

    if (!box && isHolding !== "none") {
        box = dimension.spawnEntity("vtng_mb:construction_box", displayAt);
        box.setDynamicProperty("owner", player.nameTag);
        box.setProperty("vtng_mb:size", gridSize);
        player.setPropertyOverrideForEntity(box, "vtng_mb:is_visible", true);
    }

    if (block &&
        block.typeId != "vtng_mb:phantom_block" &&
        !block.isAir &&
        (unBuildableBlocks.includes(block.typeId) ||
            block.canContainLiquid("Water") ||
            !block.canBeDestroyedByLiquidSpread("Water"))
    ) {
        if (box?.isValid) box.setProperty("vtng_mb:color", "red");
    }
}

function displaySelectionBox(player, entities, isHolding, gridSize, bitData) {
    const dimension = player.dimension;
    const cellSize = 1 / gridSize;
    const halfCell = cellSize / 2;
    const cell1_5 = cellSize * 1.5;

    const { allBlockBits, hit, gridPos } = bitData;

    let displayAt = null;

    if (hit) {
        const p = allBlockBits[hit.index];
        switch (hit.face) {
            case "above": displayAt = { x: p.x, y: p.y - halfCell, z: p.z }; break;
            case "below": displayAt = { x: p.x, y: p.y - cell1_5, z: p.z }; break;
            case "north":
            case "south":
            case "west":
            case "east":
                displayAt = { x: p.x, y: p.y - halfCell, z: p.z };
                break;
            default: displayAt = p; break;
        }
    } else if (gridPos) {
        const { x, y, z } = gridPos.loc;

        switch (gridPos.blockFace) {
            case "above": displayAt = { x, y: y - cellSize, z }; break;
            case "north": displayAt = { x, y: y - halfCell, z: z + halfCell }; break;
            case "south": displayAt = { x, y: y - halfCell, z: z - halfCell }; break;
            case "west": displayAt = { x: x + halfCell, y: y - halfCell, z }; break;
            case "east": displayAt = { x: x - halfCell, y: y - halfCell, z }; break;
            default: displayAt = gridPos.loc; break;
        }
    } else if (gridPos === false) {
        for (const entity of entities.filter(e =>
            e?.isValid !== false &&
            e.typeId == "vtng_mb:selection_box" &&
            e.getDynamicProperty("owner") === player.nameTag
        )) {
            if (!entity?.isValid) continue;
            entity.remove();
        }
        return;
    }

    if (!displayAt) {
        for (const entity of entities.filter(e =>
            e?.isValid !== false &&
            e.typeId == "vtng_mb:selection_box" &&
            e.getDynamicProperty("owner") === player.nameTag
        )) {
            if (!entity?.isValid) continue;
            entity.remove();
        }
        return;
    }

    {
        const ownedBoxes = entities.filter(e =>
            e?.isValid !== false &&
            e.typeId == "vtng_mb:selection_box" &&
            e.getDynamicProperty("owner") === player.nameTag
        );

        if (ownedBoxes.length > 0) {
            let closest = ownedBoxes[0];
            let minDist = vikAPI.distanceBetween(closest.location, displayAt);

            for (const b of ownedBoxes) {
                if (!b?.isValid) continue;
                const d = vikAPI.distanceBetween(b.location, displayAt);
                if (d < minDist) { minDist = d; closest = b; }
            }

            for (const b of ownedBoxes) {
                if (!b?.isValid) continue;

                const d = vikAPI.distanceBetween(b.location, displayAt);
                if (b !== closest && d > 0.01) {
                    if (b?.isValid) b.remove();
                } else if (d > 0.75) {
                    if (b?.isValid) b.remove();
                }
            }
        }
    }

    let box = entities
        .filter(e => e?.isValid !== false && e.typeId == "vtng_mb:selection_box" && e.getDynamicProperty("owner") === player.nameTag)
        .find(e => vikAPI.distanceBetween(e.location, displayAt) <= 1);

    if (box && box.getDynamicProperty("owner") === player.nameTag) {
        if (
            vikAPI.distanceBetween(box.location, displayAt) > 0.01 ||
            isHolding === "none"
        ) {
            if (box?.isValid) box.remove();
            box = null;
        }
    }

    if (!box && isHolding !== "none") {
        box = dimension.spawnEntity("vtng_mb:selection_box", displayAt);
        box.setDynamicProperty("owner", player.nameTag);
        box.setProperty("vtng_mb:size", gridSize);
        player.setPropertyOverrideForEntity(box, "vtng_mb:is_visible", true);
    }

    const block = dimension.getBlock(displayAt);

    if (box?.isValid) {
        let invalid = false;

        if (block && !block.isAir) {
            const typeId = block.typeId.replace("minecraft:", "");

            if (block.typeId != "vtng_mb:phantom_block" && !blocksTypeIds.includes(typeId) || block.isAir) {
                invalid = true;
            }
        }

        box.setProperty("vtng_mb:color", invalid ? "red" : "black");
    }
}

/**
 * Main system tick
 */
export default {
    id: "displayBoxes",
    code: () => {
        const allPlayers = mc.world.getAllPlayers();

        for (const player of allPlayers) {
            const dimension = player.dimension;
            const entities = dimension.getEntities();

            const headLoc = player.getHeadLocation();
            headLoc.y += 0.005;

            const selectedItem = player.getComponent("equippable")?.getEquipment("Mainhand");
            const itemTypeId = selectedItem?.typeId;

            let playerProperties = player.getDynamicProperty("vtng_mb:player_properties");

            if (!playerProperties) {
                playerProperties = { hasBlockedView: false, selectedGridSize: 2 };
                player.setDynamicProperty(
                    "vtng_mb:player_properties",
                    JSON.stringify(playerProperties)
                );
            } else {
                playerProperties = JSON.parse(playerProperties);
            }

            let { hasBlockedView, selectedGridSize } = playerProperties;
            let shouldSave = false;

            const workingGridSize =
                itemTypeId === "vtng_mb:chisel" ? selectedGridSize :
                    itemTypeId?.startsWith("vtng_mb:nanoblock") ? 8 :
                        itemTypeId?.startsWith("vtng_mb:microblock") ? 4 :
                            itemTypeId?.startsWith("vtng_mb:miniblock") ? 2 :
                                selectedGridSize;

            const isHolding =
                itemTypeId === "vtng_mb:chisel" ? "chisel" :
                    itemTypeId?.startsWith("vtng_mb:nanoblock") ||
                        itemTypeId?.startsWith("vtng_mb:microblock") ||
                        itemTypeId?.startsWith("vtng_mb:miniblock")
                        ? "mini_block"
                        : "none";

            if (!selectedItem || isHolding === "none") {
                for (const entity of entities.filter(
                    e => e.getDynamicProperty("owner") === player.nameTag
                )) {
                    entity.remove();

                    if (entity.typeId === "vtng_mb:view_blocker" && hasBlockedView) {
                        hasBlockedView = false;
                        shouldSave = true;
                    }
                }

                if (shouldSave) {
                    player.setDynamicProperty(
                        "vtng_mb:player_properties",
                        JSON.stringify({ hasBlockedView, selectedGridSize })
                    );
                }

                continue;
            }

            const bitData = computePlayerBitData(player, workingGridSize);
            const { hit, gridPos } = bitData;

            if (
                (isHolding === "chisel" && player.isSneaking) ||
                (!hit && !gridPos)
            ) {
                for (const entity of entities.filter(
                    e => e.getDynamicProperty("owner") === player.nameTag
                )) {
                    entity.remove();

                    if (entity.typeId === "vtng_mb:view_blocker" && hasBlockedView) {
                        hasBlockedView = false;
                        shouldSave = true;
                    }
                }

                if (shouldSave) {
                    player.setDynamicProperty(
                        "vtng_mb:player_properties",
                        JSON.stringify({ hasBlockedView, selectedGridSize })
                    );
                }

                continue;
            }

            let blocker = entities
                .filter(e => e.typeId === "vtng_mb:view_blocker")
                .find(e => vikAPI.distanceBetween(e.location, headLoc) <= 1);

            if (!blocker || blocker.getDynamicProperty("owner") !== player.nameTag) {
                blocker = dimension.spawnEntity("vtng_mb:view_blocker", headLoc);
                blocker.setDynamicProperty("owner", player.nameTag);

                hasBlockedView = true;
                shouldSave = true;
            } else {
                blocker.teleport(headLoc);

                let typeId;

                switch (isHolding) {
                    case "mini_block":
                        typeId = "vtng_mb:selection_box";
                        displayConstructionBox(player, entities, isHolding, workingGridSize, bitData);
                        break;

                    case "chisel":
                        typeId = "vtng_mb:construction_box";
                        displaySelectionBox(player, entities, isHolding, workingGridSize, bitData);
                        break;
                }

                for (const entity of entities.filter(
                    e => e.typeId === typeId && e.getDynamicProperty("owner") === player.nameTag
                )) {
                    entity.remove();
                }

                continue;
            }

            if (shouldSave) {
                player.setDynamicProperty(
                    "vtng_mb:player_properties",
                    JSON.stringify({ hasBlockedView, selectedGridSize })
                );
            }
        }
    },
};
