import * as mc from "@minecraft/server";

export default {
    name: "vtng_mb:chisel_interaction",
    code: {
        /**
         * @param {mc.ItemComponentUseEvent} event
        */
        onUse: (event) => {
            const { source } = event;

            if (!source.isSneaking) return;

            let playerminiBlocks = source.getDynamicProperty("vtng_mb:player_properties");
            if (!playerminiBlocks) {
                source.setDynamicProperty("vtng_mb:player_properties", JSON.stringify({ hasBlockedView: false, selectedGridSize: 2 }));
                playerminiBlocks = source.getDynamicProperty("vtng_mb:player_properties");
            }

            let { hasBlockedView, selectedGridSize } = JSON.parse(playerminiBlocks);

            if (selectedGridSize === 2) selectedGridSize = 4;
            else if (selectedGridSize === 4) selectedGridSize = 8;
            else selectedGridSize = 2;

            source.setDynamicProperty("vtng_mb:player_properties", JSON.stringify({
                hasBlockedView,
                selectedGridSize
            }));

            mc.world.sendMessage(`§7Your grid size has been changed to: §r${selectedGridSize}x${selectedGridSize}x${selectedGridSize}`);
            source.playSound("vault.insert_item_fail");
        },
    },
};