import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";

/**
 * Tipos de itens do formulário
 * - button: botão normal
 * - divider: separador visual
 */

const forms = [
    {
        id: "howToPlay",
        title: "vtng_mb.form.how_to_play",
        body: "vtng_mb.form.how_to_play.body",
        buttons: [
            { type: "divider" },
            {
                type: "button",
                name: "vtng_mb.form.miniblocks",
                icon: "textures/vtng_mb/common/ui/blocks_icon",
                onUse: (player) => {
                    openForm(player, "miniblocks");
                },
            },
            {
                type: "button",
                name: "vtng_mb.form.items",
                icon: "textures/vtng_mb/common/items/chisel",
                onUse: (player) => {
                    openForm(player, "items");
                },
            },
        ],
    },
    {
        id: "miniblocks",
        title: "vtng_mb.form.miniblocks",
        buttons: [
            {
                type: "label",
                text: "vtng_mb.form.miniblocks.about",
            },
            { type: "divider" },
            {
                type: "label",
                text: "vtng_mb.form.miniblocks.sizes",
            },
            { type: "divider" },
            {
                type: "label",
                text: "vtng_mb.form.miniblocks.how_to_craft",
            },
            { type: "divider" },
            {
                type: "label",
                text: "vtng_mb.form.miniblocks.supported_blocks",
            },
            { type: "divider" },
            {
                type: "label",
                text: "vtng_mb.form.miniblocks.limitations",
            },
            { type: "divider" },
            {
                type: "button",
                name: "Back",
                icon: "textures/vtng_mb/common/ui/back_icon",
                onUse: (player) => openForm(player, "howToPlay"),
            },
        ],
    },
    {
        id: "items",
        title: "vtng_mb.form.items",
        buttons: [
            { type: "divider" },
            {
                type: "label",
                text: "vtng_mb.form.items.chisel",
            },
            { type: "divider" },
            {
                type: "label",
                text: "vtng_mb.form.items.hammer",
            },
            { type: "divider" },
            {
                type: "button",
                name: "Back",
                icon: "textures/vtng_mb/common/ui/back_icon",
                onUse: (player) => openForm(player, "howToPlay"),
            },
        ],
    },
];

/**
 * @param {mc.Player} player
 * @param {string} formId
 */
function openForm(player, formId) {
    const formData = forms.find(f => f.id === formId);
    if (!formData) {
        player.sendMessage(`§cForm '${formId}' não encontrado!`);
        return;
    }

    const form = new ui.ActionFormData()
        .title(formData.title)
        .body(formData.body ?? "");

    /** Apenas botões clicáveis entram aqui */
    const clickableButtons = [];

    for (const item of formData.buttons) {
        switch (item.type) {
            case "divider":
                form.divider();
                break;

            case "label":
                form.label(item.text);
                break;

            case "header":
                form.header(item.text);
                break;

            case "button":
                form.button(item.name, item.icon);
                clickableButtons.push(item);
                break;
        }
    }

    form.show(player).then(response => {
        if (response.canceled) return;

        const button = clickableButtons[response.selection];
        if (button?.onUse) {
            button.onUse(player);
        }
    });
}

export default {
    name: "vtng_mb:guide_book_interaction",
    code: {
        /**
         * @param {mc.ItemComponentUseEvent} event
         */
        onUse: (event) => {
            const { source: player } = event;
            if (!(player instanceof mc.Player)) return;

            openForm(player, "howToPlay");
        },
    },
};