import * as mc from "@minecraft/server";

import bitsComponent from "./blocks/bitsComponent.js";

import chiselInteractionComponent from "./items/chiselInteractionComponent.js";
import guideBookInteractionComponent from "./items/guideBookInteractionComponent.js";

const blockComponents = [
    bitsComponent
];
const itemComponents = [
    guideBookInteractionComponent,
    chiselInteractionComponent
];

mc.system.beforeEvents.startup.subscribe(({ itemComponentRegistry, blockComponentRegistry }) => {
    for (const component of blockComponents) {
        blockComponentRegistry.registerCustomComponent(component.name, component.code)
    }
    for (const component of itemComponents) {
        itemComponentRegistry.registerCustomComponent(component.name, component.code)
    }
})