import * as mc from "@minecraft/server";

import * as racoAPI from "../../utils/raco-API";
import * as vikAPI from "../../utils/vikAPI";

import { blockBit } from "../../classes/BlockBit";
import { worldGrid } from "../../classes/WorldGrid";

import {
    destructionParticles,
    blocksTypeIds,
    miniBlocksTypes,
} from "../../consts/miniblocksConfig";

function spawnItems(dimension, itemLocation, particleLocation, type = false, variant, byPlayer) {
    let itemType;

    if (type == "vtng_mb:miniblock" || type == "vtng_mb:microblock" || type == "vtng_mb:nanoblock") {
        itemType = type + "_" + blocksTypeIds[variant];
    } else itemType = type;

    const item = dimension.spawnItem(new mc.ItemStack(itemType), itemLocation);
    if (byPlayer) dimension.playSound("random.anvil_land", itemLocation, { volume: 0.25 });

    item.teleport(itemLocation);

    try {
        const destructionParticle = destructionParticles[itemType.replace("vtng_mb:miniblock_", "minecraft:").replace("vtng_mb:microblock_", "minecraft:").replace("vtng_mb:nanoblock_", "minecraft:")];
        const map = new mc.MolangVariableMap();
        map.setColorRGBA("color", {
            red: destructionParticle.colors[0].red,
            green: destructionParticle.colors[0].green,
            blue: destructionParticle.colors[0].blue,
            alpha: destructionParticle.colors[0].alpha
        });
        map.setFloat("size", type == "vtng_mb:miniblock" ? 0.0375 : type == "vtng_mb:microblock" ? 0.0275 : 0.0175);
        dimension.spawnParticle("vtng_mb:mini_block_destruction", particleLocation, map);
    } catch { };
}

export default {
    name: "vtng_mb:bits",
    code: {
        /**
         * Removes the block disguise from the builder's frame.
         * @param {mc.BlockComponentBlockBreakEvent} event 
         */
        onBreak(event) {
            const { dimension, block, entitySource } = event;

            if (entitySource?.typeId == "minecraft:player") {
                const playerContainer = entitySource.getComponent("inventory").container;
                const selectedItem = playerContainer.getItem(entitySource.selectedSlotIndex);

                if (selectedItem.typeId != "vtng_mb:hammer") return;
            };

            const entities = dimension
                .getEntitiesAtBlockLocation(block.location)
                .filter(e => miniBlocksTypes.includes(e.typeId) || e.typeId == "vtng_mb:quarter_collision" || e.typeId == "vtng_mb:subquarter_collision");

            if (entities.length === 0) return;

            let allCubes = [];

            for (const e of entities) {
                if (!miniBlocksTypes.includes(e.typeId)) continue;

                let cubes = [];

                switch (e.typeId) {
                    case "vtng_mb:nanoblock":
                        cubes = blockBit.parseNanoblock(e);
                        break;

                    case "vtng_mb:microblock":
                        cubes = blockBit.parseMicroblock(e);
                        break;

                    case "vtng_mb:miniblock":
                        cubes = blockBit.parseMiniblock(e);
                        break;
                }

                allCubes.push({
                    typeId: e.typeId,
                    variant: e.getProperty("vtng_mb:variant"),
                    cubes
                });
            }

            for (const entry of allCubes) {
                const miniCubes = entry.cubes.flatMap(c =>
                    blockBit.convertCube(c, c.gridSize, 2)
                );

                for (const cube of miniCubes) {
                    const dropPos = {
                        x: Math.floor(block.location.x) + cube.x + 0.25,
                        y: Math.floor(block.location.y) + cube.y + 0.25,
                        z: Math.floor(block.location.z) + cube.z + 0.25
                    };

                    spawnItems(
                        dimension,
                        block.center(),
                        dropPos,
                        entry.typeId,
                        entry.variant,
                        entitySource?.typeId == "minecraft:player"
                    );
                }
            }

            for (const e of entities) {
                e.remove();
            }
        }
    }
};
