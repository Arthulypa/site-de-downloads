import React from 'react';
import { IconWrench, IconServer, IconSliders, IconTerminal, IconActivity, IconUsers, IconCode, IconFolder, IconWorld, IconBackup, IconPuzzle, IconAlert, IconFlask } from './icons.jsx';

const NAV_ITEMS = [
  { id: 'server', label: 'Servidor', Icon: IconServer },
  { id: 'options', label: 'Opções', Icon: IconSliders },
  { id: 'console', label: 'Console', Icon: IconTerminal },
  { id: 'events', label: 'Log', Icon: IconActivity },
  { id: 'players', label: 'Jogadores', Icon: IconUsers },
  { id: 'software', label: 'Software', Icon: IconCode },
  { id: 'files', label: 'Arquivos', Icon: IconFolder },
  { id: 'generate', label: 'Mundos', Icon: IconWorld },
  { id: 'backups', label: 'Backups', Icon: IconBackup },
  { id: 'addons', label: 'Add-ons', Icon: IconPuzzle },
  { id: 'danger', label: 'Manutenção', Icon: IconAlert }
];

export default function Sidebar({ activeTab, setActiveTab, mobileOpen, setMobileOpen, showExperiments }) {
  const items = showExperiments
    ? [...NAV_ITEMS.slice(0, 7), { id: 'experiments', label: 'Experimentos', Icon: IconFlask }, ...NAV_ITEMS.slice(7)]
    : NAV_ITEMS;
  const handleSelect = (id) => { setActiveTab(id); setMobileOpen(false); };
  return (
    <>
      {mobileOpen && <div className="sidebar-overlay" onClick={() => setMobileOpen(false)} />}
      <nav className={`app-sidebar ${mobileOpen ? 'sidebar-open' : ''}`} aria-label="Navegação do servidor">
        <div className="sidebar-heading">Gerenciar servidor</div>
        {items.map(item => {
          const ItemIcon = item.Icon;
          const active = activeTab === item.id;
          return (
            <button key={item.id} onClick={() => handleSelect(item.id)} className={`sidebar-item btn-anim ${active ? 'is-active' : ''}`}>
              <span className="sidebar-icon"><ItemIcon width="17" height="17" /></span>
              <span>{item.label}</span>
              {active && <span className="sidebar-active-dot" />}
            </button>
          );
        })}
      </nav>
    </>
  );
}
