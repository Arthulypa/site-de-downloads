import React from 'react';
import { IconCheck, IconX } from './icons.jsx';

export default function Toggle({ checked, onChange, disabled }) {
  return (
    <button
      type="button"
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className="toggle-pill"
      style={{
        width: '52px',
        height: '28px',
        borderRadius: '999px',
        border: 'none',
        cursor: disabled ? 'not-allowed' : 'pointer',
        background: checked ? 'var(--panel-accent, #10b981)' : 'var(--theme-border, #3f4858)',
        position: 'relative',
        transition: 'background 0.25s ease',
        opacity: disabled ? 0.5 : 1,
        flexShrink: 0
      }}
    >
      <span
        style={{
          position: 'absolute',
          top: '3px',
          left: checked ? '27px' : '3px',
          width: '22px',
          height: '22px',
          borderRadius: '50%',
          background: 'var(--theme-text, #fff)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: checked ? 'var(--panel-accent, #10b981)' : 'var(--theme-muted, #94a3b8)',
          transition: 'left 0.25s cubic-bezier(0.34, 1.56, 0.64, 1)',
          boxShadow: '0 2px 6px rgba(0,0,0,0.35)'
        }}
      >
        {checked ? <IconCheck /> : <IconX />}
      </span>
    </button>
  );
}
