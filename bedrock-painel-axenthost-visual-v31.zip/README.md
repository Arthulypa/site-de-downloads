# Bedrock Xubuntu Panel v29

Addon compatibility update: 3-level archive analysis (basic, medium, advanced), including large archives, nested packs and embedded manifests. Compatibility warnings are deduplicated in the UI.
