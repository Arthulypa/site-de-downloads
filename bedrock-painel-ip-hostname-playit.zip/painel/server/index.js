import express from 'express';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import os from 'os';
import http from 'http';
import { WebSocketServer } from 'ws';
import { fileURLToPath } from 'url';
import { v4 as uuidv4 } from 'uuid';

import { readInstances, upsertInstance, removeInstance, getInstance } from './lib/store.js';
import { getFolderSizeBytes, formatBytes, sanitizeFolderName, MAX_WORLDS, TOTAL_POOL_BYTES, PER_WORLD_SOFT_CAP_BYTES, computeDynamicQuotaBytes } from './lib/fsUtils.js';
import { defaultServerProperties, readServerProperties, writeServerProperties } from './lib/serverProperties.js';
import { readExperiments, writeExperiments } from './lib/levelDat.js';
import JSZip from 'jszip';
import archiver from 'archiver';
import { installAddonBuffer, inspectAddonBuffer, listInstalledAddons, removeAddonFromWorld } from './lib/addonInstaller.js';
import {
  ensureInstanceFiles, startInstance, stopInstance, forceStopInstance, restartInstance, sendCommand, queryPlayerList, logToInstance,
  getStatus, attachSocket, isBdsBinaryAvailable, getLocalIp, BDS_BIN_DIR, listInstalledVersions, resolveVersion, LATEST_VERSION_ALIAS
} from './lib/bdsManager.js';
import { createBackup } from './lib/backupManager.js';
import { readSettings, writeSettings } from './lib/settingsStore.js';
import { activateRamCache, deactivateRamCache, isRamCacheActive, forceSyncNow, isRamAvailable, getAvailableRamBytes } from './lib/ramSync.js';
import { appendEvent, getEvents, deleteEvents } from './lib/eventLog.js';
import { listDir, getFileForDownload, resolveSafePath } from './lib/fileBrowser.js';
import { readAllowlist, addToAllowlist, removeFromAllowlist } from './lib/allowlistStore.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws/console' });

const PORT = process.env.PANEL_PORT || 3001;
const BASE_PORT = 19132;
const ALLOWED_PORTS = [19132, 19133, 19134, 19135];

// Porta real usada pelo BDS -> porta exibida ao usuário (ex.: encaminhamento externo).
const DISPLAY_PORTS = {
  19132: 42567,
  19133: 42576,
  19134: 42579,
  19135: 42822
};

const instancesRoot = path.join(__dirname, 'instances');
const backupsDir = path.join(__dirname, 'backups');
fs.mkdirSync(instancesRoot, { recursive: true });

app.use(cors());
app.use(express.json());
app.disable('x-powered-by');
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 200 * 1024 * 1024 } });

function instanceDirOf(folderName) {
  return path.join(instancesRoot, folderName);
}
function worldDirOf(folderName) {
  return path.join(instanceDirOf(folderName), 'worlds', folderName);
}
function nextFreePort() {
  const used = new Set(readInstances().map(i => Number(i.port)));
  return ALLOWED_PORTS.find(port => !used.has(port)) || null;
}
function effectiveIp() {
  const settings = readSettings();
  return settings.networkIp || getLocalIp();
}

// ---------- STATUS GERAL ----------
app.get('/api/system/resources', (req, res) => {
  const total = os.totalmem();
  const free = os.freemem();
  const used = Math.max(0, total - free);
  res.json({
    ram: { totalBytes: total, freeBytes: free, usedBytes: used, usedPercent: total ? Math.round((used / total) * 100) : 0 },
    cpu: { cores: os.cpus().length, load1: os.loadavg()[0] || 0 }
  });
});

app.get('/api/system/battery', (req, res) => {
  try {
    const root = '/sys/class/power_supply';
    const entries = fs.existsSync(root) ? fs.readdirSync(root) : [];
    const batteries = entries.filter(name => /^(BAT|battery)/i.test(name));
    if (!batteries.length) return res.json({ available: false });
    const name = batteries[0];
    const dir = path.join(root, name);
    const read = (file) => { try { return fs.readFileSync(path.join(dir, file), 'utf8').trim(); } catch { return null; } };
    const capacity = Number(read('capacity'));
    const status = String(read('status') || '').toLowerCase();
    const acNames = entries.filter(name => /^(AC|ADP|ACAD|charger)/i.test(name));
    let online = status === 'charging' || status === 'full';
    for (const name2 of acNames) {
      let value = null; try { value = fs.readFileSync(path.join(root, name2, 'online'), 'utf8').trim(); } catch {};
      if (value === '1') { online = true; break; }
    }
    return res.json({ available: Number.isFinite(capacity), level: Number.isFinite(capacity) ? Math.max(0, Math.min(100, capacity)) : null, charging: online });
  } catch (error) {
    return res.json({ available: false, error: error.message });
  }
});

app.get('/api/status', (req, res) => {
  const settings = readSettings();
  res.json({
    bdsBinaryAvailable: isBdsBinaryAvailable(),
    bdsBinDir: BDS_BIN_DIR,
    localIp: getLocalIp(),
    networkIp: settings.networkIp,
    theme: settings.theme || 'dark',
    accent: settings.accent || '#10b981',
    effectiveIp: effectiveIp(),
    suggestedPort: nextFreePort(),
    worldCount: readInstances().length,
    maxWorlds: MAX_WORLDS
  });
});

// ---------- VERSÕES DE SOFTWARE DISPONÍVEIS (pastas dentro de bds-bin/) ----------
// Usado tanto na tela de criação de mundo (agente escolhe a versão antes de criar)
// quanto na aba Software de um mundo existente (pra trocar/reinstalar).
app.get('/api/software/versions', (req, res) => {
  const versions = listInstalledVersions(); // já vem ordenado do mais novo pro mais antigo
  res.json({
    versions,
    latest: versions[0] || null,
    binDir: BDS_BIN_DIR
  });
});

// ---------- CONFIGURAÇÕES GLOBAIS DO PAINEL (IP de rede fixo, tipo ZeroTier) ----------
app.put('/api/settings', (req, res) => {
  const incoming = req.body || {};
  const current = readSettings();
  const allowedThemes = new Set(['light', 'dark', 'darkness']);
  const allowedAccents = new Set([
    '#10b981','#06b6d4','#0ea5e9','#3b82f6','#8b5cf6',
    '#d946ef','#ec4899','#ef4444','#f97316','#f59e0b'
  ]);

  const next = { ...current };
  if (incoming.theme !== undefined) {
    if (!allowedThemes.has(incoming.theme)) return res.status(400).json({ error: 'Tema inválido.' });
    next.theme = incoming.theme;
  }
  if (incoming.accent !== undefined) {
    if (!allowedAccents.has(incoming.accent)) return res.status(400).json({ error: 'Cor de destaque inválida.' });
    next.accent = incoming.accent;
  }
  if (Object.prototype.hasOwnProperty.call(incoming, 'networkIp')) {
    const MASTER_PASSWORD = process.env.PANEL_MASTER_PASSWORD || 'Lgzinn';
    if (String(incoming.password || '') !== MASTER_PASSWORD) {
      return res.status(401).json({ error: 'Senha mestre incorreta. A alteração do IP exige autorização.' });
    }
    const ip = String(incoming.networkIp || '').trim();
    if (ip && !/^[0-9a-fA-F:.]+$/.test(ip)) {
      return res.status(400).json({ error: 'IP de rede inválido.' });
    }
    next.networkIp = ip || null;
  }
  writeSettings(next);
  res.json({ ok: true, effectiveIp: effectiveIp(), theme: next.theme, accent: next.accent });
});


// ---------- LISTAR / CRIAR MUNDOS ----------
app.get('/api/worlds', (req, res) => {
  const instances = readInstances();

  // Primeiro calcula o uso real de todo mundo, porque a cota de cada um depende do uso dos outros.
  const usageByInstance = instances.map(inst => ({
    inst,
    usedBytes: getFolderSizeBytes(worldDirOf(inst.folderName))
  }));
  const totalUsedBytes = usageByInstance.reduce((sum, u) => sum + u.usedBytes, 0);

  const result = usageByInstance.map(({ inst, usedBytes }) => {
    const otherUsedBytes = totalUsedBytes - usedBytes;
    const quotaBytes = computeDynamicQuotaBytes(otherUsedBytes, instances.length);
    const wDir = worldDirOf(inst.folderName);
    return {
      id: inst.id,
      name: inst.name,
      folderName: inst.folderName,
      port: inst.port,
      displayPort: DISPLAY_PORTS[inst.port] || null,
      createdAt: inst.createdAt,
      status: getStatus(inst.id),
      diskUsedBytes: usedBytes,
      diskUsedLabel: formatBytes(usedBytes),
      diskQuotaBytes: quotaBytes,
      diskQuotaLabel: formatBytes(quotaBytes),
      diskPercent: quotaBytes > 0 ? Math.min(100, Math.round((usedBytes / quotaBytes) * 100)) : 100,
      addons: listInstalledAddons(wDir),
      seed: inst.seed || null,
      hasPendingExperiments: !!inst.pendingExperiments,
      ramCacheEnabled: !!inst.ramCacheEnabled,
      ramCacheActive: isRamCacheActive(inst.id),
      generated: fs.existsSync(path.join(wDir, 'level.dat'))
    };
  });

  res.json({
    worlds: result,
    maxWorlds: MAX_WORLDS,
    atLimit: result.length >= MAX_WORLDS,
    totalUsedBytes,
    totalUsedLabel: formatBytes(totalUsedBytes),
    totalPoolLabel: formatBytes(TOTAL_POOL_BYTES)
  });
});

app.post('/api/worlds', (req, res) => {
  const instances = readInstances();
  if (instances.length >= MAX_WORLDS) {
    return res.status(400).json({ error: `Limite de ${MAX_WORLDS} mundos atingido. Apague um mundo antes de criar outro.` });
  }
  const { name, description, seed, experiments, port: requestedPort, version: requestedVersion } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Nome do mundo é obrigatório.' });

  const resolvedVersion = resolveVersion(requestedVersion);
  if (!resolvedVersion) {
    return res.status(400).json({ error: `Nenhuma versão do Bedrock Dedicated Server encontrada em "${BDS_BIN_DIR}". Extraia ao menos uma versão (ex: "${BDS_BIN_DIR}/1.26.40") antes de criar um mundo.` });
  }

  const folderName = sanitizeFolderName(name);
  if (instances.some(i => i.folderName === folderName)) {
    return res.status(400).json({ error: 'Já existe um mundo com esse nome (ou um nome muito parecido).' });
  }

  let port = nextFreePort();
  if (!port) {
    return res.status(400).json({ error: 'Todas as 4 portas disponíveis (19132–19135) já estão em uso.' });
  }

  if (requestedPort !== undefined && requestedPort !== null && String(requestedPort).trim() !== '') {
    const parsedPort = Number(requestedPort);
    if (!ALLOWED_PORTS.includes(parsedPort)) {
      return res.status(400).json({ error: 'Porta inválida. Escolha somente entre 19132, 19133, 19134 e 19135.' });
    }
    if (instances.some(i => Number(i.port) === parsedPort)) {
      return res.status(400).json({ error: `Porta ${parsedPort} já está em uso por outro mundo.` });
    }
    port = parsedPort;
  }

  const id = uuidv4();
  const instDir = instanceDirOf(folderName);

  ensureInstanceFiles(instDir, resolvedVersion);

  // Migração: se já existir um mundo solto em server/worlds/<folderName> (setup antigo), move pra dentro da instância.
  const legacyWorldPath = path.join(__dirname, 'worlds', folderName);
  const newWorldPath = worldDirOf(folderName);
  if (fs.existsSync(legacyWorldPath) && !fs.existsSync(newWorldPath)) {
    fs.mkdirSync(path.dirname(newWorldPath), { recursive: true });
    fs.renameSync(legacyWorldPath, newWorldPath);
  } else {
    fs.mkdirSync(newWorldPath, { recursive: true });
  }

  const props = defaultServerProperties({ levelName: folderName, port, portv6: port + 1, serverName: name, description, seed });
  writeServerProperties(path.join(instDir, 'server.properties'), props);

  // Experiments não podem ser gravados agora — o level.dat só existe depois do
  // bedrock_server rodar pela 1ª vez. Guardamos a intenção e aplicamos sozinhos
  // assim que o servidor for desligado pela primeira vez (ver /stop e onExit em startInstance).
  const hasPendingExperiments = experiments && Object.values(experiments).some(Boolean);

  const instance = {
    id,
    name: name.trim(),
    folderName,
    port,
    createdAt: new Date().toISOString(),
    seed: seed || null,
    version: resolvedVersion,
    pendingExperiments: hasPendingExperiments ? experiments : null
  };
  upsertInstance(instance);
  appendEvent(id, `Mundo criado (Bedrock Dedicated Server ${resolvedVersion}).`);

  res.status(201).json({ ...instance, status: 'Offline' });
});

app.delete('/api/worlds/:id', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  if (getStatus(instance.id) !== 'Offline') {
    return res.status(400).json({ error: 'Pare o servidor antes de deletar o mundo.' });
  }
  const instDir = instanceDirOf(instance.folderName);
  fs.rmSync(instDir, { recursive: true, force: true });
  removeInstance(instance.id);
  deleteEvents(instance.id);
  res.json({ ok: true });
});

// ---------- LIGAR / DESLIGAR / REINICIAR (ações distintas de verdade) ----------
// Aplica experiments pendentes (definidos na criação) assim que o level.dat existir,
// no primeiro desligamento do mundo. Roda uma vez só — depois disso some do metadado.
async function applyPendingExperimentsIfAny(instanceId) {
  const inst = getInstance(instanceId);
  if (!inst || !inst.pendingExperiments) return;
  const levelDatPath = path.join(worldDirOf(inst.folderName), 'level.dat');
  if (!fs.existsSync(levelDatPath)) return; // servidor não gerou o mundo ainda, tenta de novo no próximo stop
  try {
    await writeExperiments(levelDatPath, inst.pendingExperiments);
    upsertInstance({ id: inst.id, pendingExperiments: null });
  } catch (err) {
    console.error(`[experiments pendentes] Falha ao aplicar em "${inst.folderName}":`, err.message);
  }
}

function onInstanceExit(instance) {
  return async () => {
    // Desativa o cache em RAM (sincroniza tudo de volta pro pendrive) ANTES
    // de mexer no level.dat, senão os experiments seriam aplicados na cópia errada.
    if (isRamCacheActive(instance.id)) {
      deactivateRamCache(instance.id, { onLog: (line) => logToInstance(instance.id, line) });
    }
    await applyPendingExperimentsIfAny(instance.id);
  };
}

app.post('/api/worlds/:id/start', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    // Reaplica os symlinks vanilla (repara instâncias antigas criadas antes
    // da correção do bug "Failed to load Vanilla Resource Pack"; é idempotente).
    ensureInstanceFiles(instanceDirOf(instance.folderName), instance.version);
    if (instance.ramCacheEnabled) {
      activateRamCache(instance.id, worldDirOf(instance.folderName), { onLog: (line) => logToInstance(instance.id, line) });
    }
    startInstance(instance.id, instanceDirOf(instance.folderName), { onExit: onInstanceExit(instance) });
    appendEvent(instance.id, 'Servidor ligado.');
    res.json({ ok: true, ip: effectiveIp(), port: instance.port });
  } catch (err) {
    // Se o processo não subiu (ex: binário ausente), desfaz a ativação da RAM
    // pra não deixar o mundo "preso" num symlink órfão sem processo rodando.
    if (instance.ramCacheEnabled && isRamCacheActive(instance.id)) {
      deactivateRamCache(instance.id, { onLog: (line) => logToInstance(instance.id, line) });
    }
    const msg = err.message === 'BINARY_NOT_FOUND'
      ? `Binário do bedrock_server não encontrado. Coloque a instalação extraída em "${BDS_BIN_DIR}".`
      : err.message;
    res.status(400).json({ error: msg });
  }
});

app.post('/api/worlds/:id/stop', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  stopInstance(instance.id); // o sync final acontece no onExit registrado no start
  appendEvent(instance.id, 'Servidor desligado.');
  res.json({ ok: true });
});

app.post('/api/worlds/:id/force-stop', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const status = getStatus(instance.id);
  if (status === 'Offline') return res.status(400).json({ error: 'Servidor já está parado.' });
  const stopped = forceStopInstance(instance.id);
  if (!stopped) return res.status(400).json({ error: 'O processo do servidor não está disponível para parada forçada.' });
  appendEvent(instance.id, 'Servidor parado à força (emergência).');
  res.json({ ok: true });
});

app.post('/api/worlds/:id/restart', async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    ensureInstanceFiles(instanceDirOf(instance.folderName), instance.version);
    await restartInstance(instance.id, instanceDirOf(instance.folderName), { onExit: onInstanceExit(instance) });
    if (instance.ramCacheEnabled) {
      activateRamCache(instance.id, worldDirOf(instance.folderName), { onLog: (line) => logToInstance(instance.id, line) });
    }
    appendEvent(instance.id, 'Servidor reiniciado.');
    res.json({ ok: true, ip: effectiveIp(), port: instance.port });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ---------- CACHE EM RAM: status, ativar/desativar, sincronizar agora ----------
app.get('/api/ram-status', (req, res) => {
  res.json({ available: isRamAvailable(), availableRamBytes: getAvailableRamBytes() });
});

app.put('/api/worlds/:id/ram-cache', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  if (getStatus(instance.id) !== 'Offline') {
    return res.status(400).json({ error: 'Pare o servidor antes de mudar o modo de cache em RAM.' });
  }
  const { enabled } = req.body;
  upsertInstance({ id: instance.id, ramCacheEnabled: !!enabled });
  res.json({ ok: true, ramCacheEnabled: !!enabled });
});

app.post('/api/worlds/:id/ram-sync-now', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    forceSyncNow(instance.id);
    res.json({ ok: true, message: 'Sincronizado com o pendrive agora.' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});


app.post('/api/worlds/:id/command', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const { command } = req.body;
  if (!command) return res.status(400).json({ error: 'Comando vazio.' });
  try {
    sendCommand(instance.id, command);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/worlds/:id/players', async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  if (getStatus(instance.id) !== 'Online') {
    return res.json({ online: 0, max: Number((readServerProperties(path.join(instanceDirOf(instance.folderName), 'server.properties')) || {})['max-players']) || 0, names: [], serverOffline: true });
  }
  try {
    const result = await queryPlayerList(instance.id);
    res.json(result);
  } catch (err) {
    res.status(504).json({ error: err.message });
  }
});

// ---------- MANUTENÇÃO (reinstalar / deletar com autenticação real no servidor) ----------
app.post('/api/worlds/:id/reinstall', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const { pin, version: requestedVersion } = req.body;
  const REAL_PIN = process.env.PANEL_MAINTENANCE_PIN || '1122';
  if (pin !== REAL_PIN) return res.status(403).json({ error: 'PIN incorreto.' });
  if (getStatus(instance.id) !== 'Offline') return res.status(400).json({ error: 'Pare o servidor antes de reinstalar.' });

  // Se veio uma versão junto (troca de software na aba Software), resolve pra
  // uma versão de fato instalada em bds-bin/<versao>/ antes de mexer em disco.
  let resolvedVersion = instance.version;
  if (requestedVersion) {
    resolvedVersion = resolveVersion(requestedVersion);
    if (!resolvedVersion) {
      return res.status(400).json({ error: `Nenhuma versão do Bedrock Dedicated Server encontrada em "${BDS_BIN_DIR}".` });
    }
  }

  const wDir = worldDirOf(instance.folderName);
  fs.rmSync(wDir, { recursive: true, force: true });
  fs.mkdirSync(wDir, { recursive: true });
  // Reaponta os symlinks de binário pra versão escolhida (ou mantém a mesma).
  // force:true pq os symlinks antigos (pra outra versão, ou quebrados se a
  // pasta da versão antiga sumiu) já existem em instanceDir e precisam ser
  // substituídos, não só criados quando ausentes.
  ensureInstanceFiles(instanceDirOf(instance.folderName), resolvedVersion, { force: true });
  if (resolvedVersion !== instance.version) {
    upsertInstance({ id: instance.id, version: resolvedVersion });
    appendEvent(instance.id, `Servidor reinstalado com troca de versão (${instance.version || '?'} → ${resolvedVersion}). Dados do mundo apagados.`);
  } else {
    appendEvent(instance.id, 'Servidor reinstalado (dados apagados, binários mantidos).');
  }
  res.json({ ok: true, version: resolvedVersion });
});

// ---------- ATUALIZAR SOFTWARE SEM REINSTALAR (mantém o mundo intacto) ----------
// Diferente do /reinstall: só troca os symlinks de binário pra outra versão do
// BDS. Recomendado pra upgrade (versão pra cima). Downgrade também é permitido
// aqui se o usuário escolher "atualizar mesmo assim", mas quem decide qual
// botão recomendar é o frontend — aqui só executa a troca.
app.post('/api/worlds/:id/update-software', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const { pin, version: requestedVersion } = req.body;
  const REAL_PIN = process.env.PANEL_MAINTENANCE_PIN || '1122';
  if (pin !== REAL_PIN) return res.status(403).json({ error: 'PIN incorreto.' });
  if (getStatus(instance.id) !== 'Offline') return res.status(400).json({ error: 'Pare o servidor antes de atualizar.' });

  const resolvedVersion = resolveVersion(requestedVersion);
  if (!resolvedVersion) {
    return res.status(400).json({ error: `Nenhuma versão do Bedrock Dedicated Server encontrada em "${BDS_BIN_DIR}".` });
  }

  ensureInstanceFiles(instanceDirOf(instance.folderName), resolvedVersion, { force: true });
  const previousVersion = instance.version;
  upsertInstance({ id: instance.id, version: resolvedVersion });
  appendEvent(instance.id, `Servidor atualizado de ${previousVersion || '?'} para ${resolvedVersion} (dados do mundo mantidos).`);
  res.json({ ok: true, version: resolvedVersion });
});

app.post('/api/worlds/:id/delete-master', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const { password } = req.body;
  const REAL_PASSWORD = process.env.PANEL_MASTER_PASSWORD || 'Lgzinn';
  if (!REAL_PASSWORD) return res.status(500).json({ error: 'Senha mestre não configurada no servidor (defina PANEL_MASTER_PASSWORD).' });
  if (password !== REAL_PASSWORD) return res.status(403).json({ error: 'Senha incorreta.' });
  if (getStatus(instance.id) !== 'Offline') return res.status(400).json({ error: 'Pare o servidor antes de deletar.' });

  fs.rmSync(instanceDirOf(instance.folderName), { recursive: true, force: true });
  removeInstance(instance.id);
  res.json({ ok: true });
});

// ---------- SERVER.PROPERTIES (interface simplificada) ----------
app.get('/api/worlds/:id/properties', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const props = readServerProperties(path.join(instanceDirOf(instance.folderName), 'server.properties'));
  if (!props) return res.status(404).json({ error: 'server.properties não encontrado.' });
  res.json({ properties: props });
});

app.put('/api/worlds/:id/properties', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const propsPath = path.join(instanceDirOf(instance.folderName), 'server.properties');
  const current = readServerProperties(propsPath) || {};
  const incoming = { ...req.body };

  // A porta do BDS é controlada pelo gerenciador e nunca pode sair do
  // intervalo reservado para os 4 mundos.
  if (Object.prototype.hasOwnProperty.call(incoming, 'server-port')) {
    const requested = Number(incoming['server-port']);
    if (!ALLOWED_PORTS.includes(requested)) {
      return res.status(400).json({ error: 'A porta do servidor é fixa ao conjunto 19132–19135 e não pode ser alterada para outro valor.' });
    }
    if (requested !== Number(instance.port)) {
      return res.status(400).json({ error: `Este mundo usa a porta interna ${instance.port}. A porta não pode ser trocada por outra porta.` });
    }
    incoming['server-port'] = String(requested);
  }

  const updated = { ...current, ...incoming };
  writeServerProperties(propsPath, updated);
  if (getStatus(instance.id) !== 'Offline') {
    return res.json({ ok: true, warning: 'Alterações só têm efeito após reiniciar o servidor.' });
  }
  res.json({ ok: true });
});

// ---------- EXPERIMENTS (level.dat real) ----------
app.get('/api/worlds/:id/experiments', async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const levelDatPath = path.join(worldDirOf(instance.folderName), 'level.dat');
  const experiments = await readExperiments(levelDatPath);
  if (experiments === null) {
    return res.json({ available: false, reason: 'Mundo ainda não foi gerado (inicie o servidor uma vez primeiro).' });
  }
  res.json({ available: true, experiments });
});

app.put('/api/worlds/:id/experiments', async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  if (getStatus(instance.id) !== 'Offline') {
    return res.status(400).json({ error: 'Pare o servidor antes de alterar experiments (o level.dat fica em uso).' });
  }
  const levelDatPath = path.join(worldDirOf(instance.folderName), 'level.dat');
  try {
    await writeExperiments(levelDatPath, req.body || {});
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ---------- ADDONS (.mcpack / .mcaddon reais, inclusive empilhados) ----------
app.post('/api/worlds/:id/addons/preview', upload.single('file'), async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  if (!req.file) return res.status(400).json({ error: 'Nenhum arquivo enviado.' });
  try {
    const info = await inspectAddonBuffer(req.file.buffer, req.file.originalname || 'addon');
    res.json({
      ok: true,
      stacked: info.packs.length > 1,
      packs: info.packs.map(p => ({
        id: p.id, name: p.identity.name, description: p.identity.description,
        kind: p.kind, type: p.kind === 'behavior' ? 'Behavior Pack (BP)' : 'Resource Pack (RP)',
        version: p.version.join('.'), source: p.sourceLabel, warnings: p.warnings || []
      })),
      warnings: info.warnings || []
    });
  } catch (err) {
    res.status(400).json({ error: 'Não foi possível analisar o addon: ' + err.message });
  }
});

app.post('/api/worlds/:id/addons', upload.single('file'), async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  if (!req.file) return res.status(400).json({ error: 'Nenhum arquivo enviado.' });

  const confirm = String(req.query.confirm || req.body?.confirm || '') === 'true';

  try {
    const info = await inspectAddonBuffer(req.file.buffer, req.file.originalname || 'addon');
    if (info.packs.length > 1 && !confirm) {
      return res.status(409).json({
        needsConfirm: true, stacked: true,
        packs: info.packs.map(p => ({ id:p.id, name:p.identity.name, description:p.identity.description, kind:p.kind, type:p.kind === 'behavior' ? 'Behavior Pack (BP)' : 'Resource Pack (RP)', version:p.version.join('.'), source:p.sourceLabel, warnings:p.warnings || [] })),
        warnings: info.warnings || [],
        error: `Este arquivo contém ${info.packs.length} packs. Confirme a instalação.`
      });
    }

    // Confere a cota dinâmica ANTES de instalar.
    const instances = readInstances();
    const otherUsedBytes = instances
      .filter(i => i.id !== instance.id)
      .reduce((sum, i) => sum + getFolderSizeBytes(worldDirOf(i.folderName)), 0);
    const quotaBytes = computeDynamicQuotaBytes(otherUsedBytes, instances.length);
    const currentUsedBytes = getFolderSizeBytes(worldDirOf(instance.folderName));
    if (currentUsedBytes + req.file.size > quotaBytes) {
      return res.status(400).json({
        error: `Addon estouraria a cota do mundo (usando ${formatBytes(currentUsedBytes)} de ${formatBytes(quotaBytes)} disponíveis agora — a cota varia conforme o uso do outro mundo).`
      });
    }

    const instDir = instanceDirOf(instance.folderName);
    const wDir = worldDirOf(instance.folderName);
    const result = await installAddonBuffer(req.file.buffer, instDir, wDir, { sourceName: req.file.originalname || 'addon' });
    res.json({ ok: true, installed: result.installed, warnings: result.warnings || [] });
  } catch (err) {
    res.status(400).json({ error: 'Erro ao processar addon: ' + err.message });
  }
});

app.put('/api/worlds/:id/addons/order', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const { kind, ids } = req.body || {};
  if (!['behavior', 'resource'].includes(kind) || !Array.isArray(ids)) {
    return res.status(400).json({ error: 'Ordem de add-ons inválida.' });
  }
  const registryFile = path.join(worldDirOf(instance.folderName), kind === 'behavior' ? 'world_behavior_packs.json' : 'world_resource_packs.json');
  let registry = [];
  try { registry = fs.existsSync(registryFile) ? JSON.parse(fs.readFileSync(registryFile, 'utf-8')) : []; } catch { registry = []; }
  const byId = new Map(registry.map(entry => [entry.pack_id, entry]));
  const ordered = ids.map(id => byId.get(id)).filter(Boolean);
  for (const entry of registry) if (!ids.includes(entry.pack_id)) ordered.push(entry);
  fs.writeFileSync(registryFile, JSON.stringify(ordered, null, 2));
  appendEvent(instance.id, `Ordem de ${kind === 'behavior' ? 'BP' : 'RP'} atualizada.`);
  res.json({ ok: true, addons: listInstalledAddons(worldDirOf(instance.folderName)) });
});

app.delete('/api/worlds/:id/addons/:addonId', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const wDir = worldDirOf(instance.folderName);
  const addons = listInstalledAddons(wDir);
  const addon = addons.find(a => a.id === req.params.addonId);
  if (!addon) return res.status(404).json({ error: 'Addon não encontrado.' });
  // precisamos do campo "folder" pra apagar do disco — refaz a busca com dados completos
  removeAddonFromWorld(wDir, instanceDirOf(instance.folderName), { ...addon, folder: addon.folder });
  res.json({ ok: true });
});

// ---------- GERAR MUNDO NOVO (aba "Gerar Mundo", estilo Exaroton) ----------
app.post('/api/worlds/:id/generate', async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  if (getStatus(instance.id) !== 'Offline') {
    return res.status(400).json({ error: 'Pare o servidor antes de gerar um mundo novo.' });
  }

  const { seed, experiments, confirm } = req.body;
  const wDir = worldDirOf(instance.folderName);
  const alreadyHasWorld = fs.existsSync(path.join(wDir, 'level.dat'));

  if (alreadyHasWorld && !confirm) {
    return res.status(409).json({
      needsConfirm: true,
      error: 'Já existe um mundo gerado aqui. Gerar um novo vai APAGAR o mundo atual permanentemente.'
    });
  }

  fs.rmSync(wDir, { recursive: true, force: true });
  fs.mkdirSync(wDir, { recursive: true });

  const propsPath = path.join(instanceDirOf(instance.folderName), 'server.properties');
  const props = readServerProperties(propsPath) || {};
  props['level-seed'] = seed ? String(seed) : '';
  writeServerProperties(propsPath, props);

  const hasPendingExperiments = experiments && Object.values(experiments).some(Boolean);
  upsertInstance({ id: instance.id, seed: seed || null, pendingExperiments: hasPendingExperiments ? experiments : null });

  appendEvent(instance.id, `Mundo regenerado (seed: ${seed || 'aleatória'}).`);
  res.json({ ok: true, message: 'Mundo apagado e pronto pra ser gerado. Ligue o servidor pra criar o novo mundo.' });
});

// ---------- IMPORTAR MUNDO (zip com level.dat + db/, também com confirmação) ----------
app.get('/api/worlds/:id/world/download', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const wDir = worldDirOf(instance.folderName);
    if (!fs.existsSync(path.join(wDir, 'level.dat'))) return res.status(400).json({ error: 'Este servidor ainda não possui um mundo gerado.' });
    const archive = archiver('zip', { zlib: { level: 6 } });
    res.attachment(`${instance.folderName}.zip`);
    archive.on('error', err => { if (!res.headersSent) res.status(500).json({ error: err.message }); });
    archive.pipe(res);
    archive.directory(wDir, instance.folderName);
    archive.finalize();
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.post('/api/worlds/:id/import', upload.single('file'), async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  if (getStatus(instance.id) !== 'Offline') {
    return res.status(400).json({ error: 'Pare o servidor antes de importar um mundo.' });
  }
  if (!req.file) return res.status(400).json({ error: 'Nenhum arquivo enviado (.zip do mundo).' });

  const wDir = worldDirOf(instance.folderName);
  const alreadyHasWorld = fs.existsSync(path.join(wDir, 'level.dat'));
  const confirm = req.body.confirm === 'true' || req.body.confirm === true;

  if (alreadyHasWorld && !confirm) {
    return res.status(409).json({
      needsConfirm: true,
      error: 'Já existe um mundo gerado aqui. Importar vai APAGAR o mundo atual permanentemente.'
    });
  }

  try {
    const zip = await JSZip.loadAsync(req.file.buffer);
    const entries = Object.keys(zip.files);
    if (!entries.some(n => n.endsWith('level.dat'))) {
      return res.status(400).json({ error: 'Zip inválido: não encontrei level.dat dentro dele. Exporte a pasta do mundo inteira (level.dat, levelname.txt, db/) zipada.' });
    }

    fs.rmSync(wDir, { recursive: true, force: true });
    fs.mkdirSync(wDir, { recursive: true });

    // Descobre o prefixo comum (se o zip tem uma pasta raiz tipo "MeuMundo/level.dat")
    const levelDatEntry = entries.find(n => n.endsWith('level.dat'));
    const prefix = levelDatEntry.includes('/') ? levelDatEntry.slice(0, levelDatEntry.lastIndexOf('/') + 1) : '';

    // Importação também respeita o limite fixo de 10GB por mundo.
    // O tamanho é calculado antes de apagar o mundo atual.
    const importedBytes = entries.reduce((sum, name) => {
      const entry = zip.files[name];
      if (!entry || entry.dir || !name.startsWith(prefix)) return sum;
      return sum + Number(entry._data?.uncompressedSize || 0);
    }, 0);
    if (importedBytes > PER_WORLD_SOFT_CAP_BYTES) {
      return res.status(400).json({
        error: `O mundo importado ocupa ${formatBytes(importedBytes)} e ultrapassa o limite de 10GB por mundo.`
      });
    }

    for (const name of entries) {
      const entry = zip.files[name];
      if (entry.dir || !name.startsWith(prefix)) continue;
      const relative = name.slice(prefix.length);
      if (!relative) continue;
      const dest = path.join(wDir, relative);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, await entry.async('nodebuffer'));
    }

    upsertInstance({ id: instance.id, pendingExperiments: null });
    appendEvent(instance.id, `Mundo importado de ${req.file.originalname}.`);
    res.json({ ok: true, message: 'Mundo importado com sucesso.' });
  } catch (err) {
    res.status(400).json({ error: 'Erro ao importar mundo: ' + err.message });
  }
});

// ---------- BACKUP MANUAL ----------
app.post('/api/worlds/:id/backup', async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const result = await createBackup(worldDirOf(instance.folderName), path.join(backupsDir, instance.folderName), false);
    appendEvent(instance.id, `Backup manual criado: ${result.fileName}`);
    res.json({ ok: true, ...result });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao criar backup: ' + err.message });
  }
});

// ---------- LISTA DE BACKUPS (com download real) ----------
app.get('/api/worlds/:id/backups', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const dir = path.join(backupsDir, instance.folderName);
  if (!fs.existsSync(dir)) return res.json({ backups: [] });
  const backups = fs.readdirSync(dir)
    .filter(f => f.endsWith('.zip'))
    .map(f => {
      const stat = fs.statSync(path.join(dir, f));
      return { fileName: f, sizeBytes: stat.size, sizeLabel: formatBytes(stat.size), createdAt: stat.mtime.toISOString() };
    })
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ backups });
});

app.get('/api/worlds/:id/backups/:fileName/download', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const filePath = path.join(backupsDir, instance.folderName, req.params.fileName);
  if (!filePath.startsWith(path.join(backupsDir, instance.folderName)) || !fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'Backup não encontrado.' });
  }
  res.download(filePath);
});

app.delete('/api/worlds/:id/backups/:fileName', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const fileName = path.basename(req.params.fileName);
  if (fileName !== req.params.fileName || !fileName.endsWith('.zip')) return res.status(400).json({ error: 'Backup inválido.' });
  const filePath = path.join(backupsDir, instance.folderName, fileName);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Backup não encontrado.' });
  try {
    fs.unlinkSync(filePath);
    appendEvent(instance.id, `Backup apagado: ${fileName}`);
    res.json({ ok: true, message: 'Backup apagado.' });
  } catch (err) { res.status(500).json({ error: 'Erro ao apagar backup: ' + err.message }); }
});

// ---------- REGISTRO DE EVENTOS ----------
app.post('/api/worlds/:id/backups/:fileName/restore', async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  if (getStatus(instance.id) !== 'Offline') return res.status(400).json({ error: 'Pare o servidor antes de restaurar um backup.' });
  const fileName = path.basename(req.params.fileName);
  if (fileName !== req.params.fileName || !fileName.endsWith('.zip')) return res.status(400).json({ error: 'Backup inválido.' });
  const confirm = req.body?.confirm === true;
  if (!confirm) return res.status(409).json({ needsConfirm: true, error: 'Restaurar substituirá o mundo atual. Confirme para continuar.' });
  const backupPath = path.join(backupsDir, instance.folderName, fileName);
  if (!fs.existsSync(backupPath)) return res.status(404).json({ error: 'Backup não encontrado.' });
  try {
    const zip = await JSZip.loadAsync(fs.readFileSync(backupPath));
    const temp = path.join(instanceDirOf(instance.folderName), `.restore-${Date.now()}`);
    fs.rmSync(temp, { recursive: true, force: true });
    fs.mkdirSync(temp, { recursive: true });
    const names = Object.keys(zip.files);
    for (const name of names) {
      const clean = name.replace(/\\/g, '/');
      if (!clean || clean.startsWith('/') || clean.split('/').includes('..')) continue;
      const target = path.join(temp, clean);
      if (zip.files[name].dir) fs.mkdirSync(target, { recursive: true });
      else { fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, await zip.files[name].async('nodebuffer')); }
    }
    const wDir = worldDirOf(instance.folderName);
    fs.rmSync(wDir, { recursive: true, force: true });
    fs.mkdirSync(wDir, { recursive: true });
    // Backups made by this panel contain the world directory contents directly.
    for (const item of fs.readdirSync(temp)) fs.renameSync(path.join(temp, item), path.join(wDir, item));
    fs.rmSync(temp, { recursive: true, force: true });
    upsertInstance({ id: instance.id, pendingExperiments: null });
    appendEvent(instance.id, `Backup restaurado: ${fileName}`);
    res.json({ ok: true, message: 'Backup restaurado com sucesso.' });
  } catch (err) { res.status(400).json({ error: 'Erro ao restaurar backup: ' + err.message }); }
});

app.get('/api/worlds/:id/events', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  res.json({ events: getEvents(instance.id).slice().reverse() }); // mais recente primeiro
});

// ---------- NAVEGADOR DE ARQUIVOS (somente leitura, restrito à pasta da instância) ----------
app.get('/api/worlds/:id/files', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const baseDir = instanceDirOf(instance.folderName);
    // Auto-repara symlinks quebrados do binário (ex: pasta de uma versão antiga
    // do BDS que foi renomeada/apagada) toda vez que a aba Arquivos é aberta,
    // sem precisar o usuário clicar em "Atualizar" manualmente. force:false
    // então isso NUNCA troca uma versão válida por outra, só conserta o que
    // já está quebrado.
    ensureInstanceFiles(baseDir, instance.version);
    const relPath = String(req.query.path || '');
    const target = resolveSafePath(baseDir, relPath);
    const stat = fs.statSync(target);
    const entries = stat.isDirectory() ? listDir(baseDir, relPath).map(entry => ({
      ...entry,
      path: relPath ? `${relPath}/${entry.name}` : entry.name
    })) : [];
    res.json({ entries, path: relPath, isDir: stat.isDirectory() });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/worlds/:id/files/download-selected', express.json(), async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const paths = Array.isArray(req.body?.paths) ? req.body.paths : [];
  if (!paths.length) return res.status(400).json({ error: 'Nenhum arquivo selecionado.' });
  const root = instanceDirOf(instance.folderName);
  const archive = archiver('zip', { zlib: { level: 6 } });
  res.attachment(`${instance.folderName}-selecionados.zip`);
  archive.pipe(res);
  try {
    for (const rel of paths.slice(0, 100)) {
      const safe = String(rel || '').replace(/\\/g, '/');
      if (!safe || safe.startsWith('/') || safe.split('/').includes('..')) continue;
      const full = resolveSafePath(root, safe);
      if (!full || !fs.existsSync(full)) continue;
      const stat = fs.statSync(full);
      if (stat.isFile()) archive.file(full, { name: safe });
      else if (stat.isDirectory()) archive.directory(full, safe);
    }
    await archive.finalize();
  } catch (err) {
    if (!res.headersSent) res.status(500).json({ error: 'Erro ao preparar download: ' + err.message });
    else archive.destroy();
  }
});

app.get('/api/worlds/:id/files/content', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const relPath = String(req.query.path || '');
    const file = getFileForDownload(instanceDirOf(instance.folderName), relPath);
    const baseName = path.basename(file).toLowerCase();
    const editable = ['.json','.json5','.jsonc','.txt','.log','.properties','.ini','.cfg','.conf','.yaml','.yml','.mcmeta','.lang','.csv','.xml','.js','.ts'].some(ext => baseName.endsWith(ext)) && !['bedrock_server','bedrock_server.exe','bedrock_server_x64','bedrock_server_x64.exe'].includes(baseName);
    if (!editable) return res.status(403).json({ error: 'Este arquivo é protegido ou não é um formato de texto editável pelo painel.' });
    const stat = fs.statSync(file);
    if (stat.size > 2 * 1024 * 1024) return res.status(400).json({ error: 'Arquivo grande demais para edição no navegador.' });
    const buf = fs.readFileSync(file);
    if (buf.includes(0)) return res.status(400).json({ error: 'Arquivo binário: edição de texto não disponível.' });
    res.json({ path: relPath, content: buf.toString('utf8') });
  } catch (err) {
    res.status(404).json({ error: err.message });
  }
});

// Serve o arquivo "inline" (sem Content-Disposition: attachment), pra imagens
// abrirem direto no navegador/numa tag <img> em vez de baixar. Só libera pra
// extensões de imagem conhecidas — pra qualquer outra coisa usa /download.
app.get('/api/worlds/:id/files/view', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const relPath = String(req.query.path || '');
    const file = getFileForDownload(instanceDirOf(instance.folderName), relPath);
    const ext = path.extname(file).toLowerCase();
    const mime = { '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.gif':'image/gif', '.webp':'image/webp', '.bmp':'image/bmp', '.svg':'image/svg+xml' }[ext];
    if (!mime) return res.status(415).json({ error: 'Este endpoint só serve imagens.' });
    // res.sendFile (em vez de criar o stream manualmente) já resolve
    // Content-Type, Content-Length, cache headers e, principalmente, chama o
    // callback de erro corretamente se o arquivo sumir/symlink quebrar no meio
    // do caminho — com fs.createReadStream(...).pipe(res) sem tratamento de
    // erro, uma falha aí deixava a requisição pendurada e a imagem "nunca
    // abria" sem nenhum erro visível.
    res.sendFile(file, { headers: { 'Content-Type': mime } }, (err) => {
      if (err && !res.headersSent) res.status(404).json({ error: 'Não foi possível ler esse arquivo (link quebrado ou removido).' });
    });
  } catch (err) {
    res.status(404).json({ error: err.message });
  }
});

app.put('/api/worlds/:id/files/content', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const relPath = String(req.body?.path || '');
    if (!relPath || typeof req.body?.content !== 'string') return res.status(400).json({ error: 'Caminho e conteúdo são obrigatórios.' });
    const file = getFileForDownload(instanceDirOf(instance.folderName), relPath);
    const baseName = path.basename(file).toLowerCase();
    const editable = ['.json','.json5','.jsonc','.txt','.log','.properties','.ini','.cfg','.conf','.yaml','.yml','.mcmeta','.lang','.csv','.xml','.js','.ts'].some(ext => baseName.endsWith(ext)) && !['bedrock_server','bedrock_server.exe','bedrock_server_x64','bedrock_server_x64.exe'].includes(baseName);
    if (!editable) return res.status(403).json({ error: 'Este arquivo é protegido ou não é um formato de texto editável pelo painel.' });
    fs.writeFileSync(file, req.body.content, 'utf8');
    appendEvent(instance.id, `Arquivo editado: ${relPath}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/worlds/:id/files/upload', upload.array('files', 50), (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const baseDir = instanceDirOf(instance.folderName);
    const targetRel = String(req.body?.path || '');
    const targetDir = resolveSafePath(baseDir, targetRel);
    fs.mkdirSync(targetDir, { recursive: true });
    for (const file of (req.files || [])) {
      const cleanName = path.basename(file.originalname || 'upload.bin');
      fs.writeFileSync(path.join(targetDir, cleanName), file.buffer);
    }
    appendEvent(instance.id, `Upload de ${req.files?.length || 0} arquivo(s) em ${targetRel || '/'}.`);
    res.json({ ok: true, count: req.files?.length || 0 });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/worlds/:id/files/folder', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const relDir = String(req.body?.path || '');
    const name = path.basename(String(req.body?.name || '')).trim();
    if (!name || name === '.' || name === '..') return res.status(400).json({ error: 'Nome de pasta inválido.' });
    const dir = resolveSafePath(instanceDirOf(instance.folderName), relDir ? `${relDir}/${name}` : name);
    fs.mkdirSync(dir, { recursive: false });
    appendEvent(instance.id, `Pasta criada: ${relDir ? `${relDir}/` : ''}${name}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.code === 'EEXIST' ? 'Essa pasta já existe.' : err.message });
  }
});

app.post('/api/worlds/:id/files/file', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const relDir = String(req.body?.path || '');
    const name = path.basename(String(req.body?.name || '')).trim();
    if (!name || name === '.' || name === '..') return res.status(400).json({ error: 'Nome de arquivo inválido.' });
    const target = resolveSafePath(instanceDirOf(instance.folderName), relDir ? `${relDir}/${name}` : name);
    if (fs.existsSync(target)) return res.status(400).json({ error: 'Esse arquivo já existe.' });
    fs.writeFileSync(target, '');
    appendEvent(instance.id, `Arquivo criado: ${relDir ? `${relDir}/` : ''}${name}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/worlds/:id/files/archive', async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const relPath = String(req.body?.path || '').replace(/\\/g, '/');
    if (!relPath || relPath.startsWith('/') || relPath.split('/').includes('..')) return res.status(400).json({ error:'Caminho inválido.' });
    const base = instanceDirOf(instance.folderName);
    const source = resolveSafePath(base, relPath);
    if (!fs.existsSync(source)) return res.status(404).json({ error:'Item não encontrado.' });
    const parent = path.dirname(source);
    const baseName = path.basename(source);
    let out = path.join(parent, `${baseName}.zip`);
    let n = 2;
    while (fs.existsSync(out)) out = path.join(parent, `${baseName} (${n++}).zip`);
    const archive = archiver('zip', { zlib: { level: 6 } });
    const stream = fs.createWriteStream(out);
    archive.pipe(stream);
    if (fs.statSync(source).isDirectory()) archive.directory(source, baseName);
    else archive.file(source, { name: baseName });
    await archive.finalize();
    await new Promise((resolve, reject) => { stream.on('close', resolve); stream.on('error', reject); });
    appendEvent(instance.id, `Item arquivado: ${relPath} -> ${path.relative(base, out)}`);
    res.json({ ok:true, archivePath:path.relative(base, out).replace(/\\/g,'/'), name:path.basename(out) });
  } catch (err) { res.status(500).json({ error:'Erro ao arquivar: ' + err.message }); }
});


app.post('/api/worlds/:id/files/archive-selected', async (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const paths = Array.isArray(req.body?.paths) ? req.body.paths : [];
    if (!paths.length) return res.status(400).json({ error: 'Nenhum item selecionado.' });
    const base = instanceDirOf(instance.folderName);
    const destination = String(req.body?.destination || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
    const outDir = resolveSafePath(base, destination);
    if (!fs.existsSync(outDir) || !fs.statSync(outDir).isDirectory()) return res.status(400).json({ error: 'Pasta de destino inválida.' });
    let out = path.join(outDir, 'archive.zip');
    let n = 2;
    while (fs.existsSync(out)) out = path.join(outDir, `archive (${n++}).zip`);
    const archive = archiver('zip', { zlib: { level: 6 } });
    const stream = fs.createWriteStream(out);
    archive.pipe(stream);
    let added = 0;
    for (const rel of paths.slice(0, 100)) {
      const safe = String(rel || '').replace(/\\/g, '/');
      if (!safe || safe.startsWith('/') || safe.split('/').includes('..')) continue;
      const full = resolveSafePath(base, safe);
      if (!fs.existsSync(full)) continue;
      const stat = fs.statSync(full);
      if (stat.isDirectory()) archive.directory(full, safe);
      else archive.file(full, { name: safe });
      added++;
    }
    if (!added) { stream.close(); return res.status(400).json({ error: 'Nenhum item válido para arquivar.' }); }
    await archive.finalize();
    await new Promise((resolve, reject) => { stream.on('close', resolve); stream.on('error', reject); });
    appendEvent(instance.id, `Itens arquivados: ${added} -> ${path.relative(base, out)}`);
    res.json({ ok: true, name: path.basename(out), archivePath: path.relative(base, out).replace(/\\/g, '/') });
  } catch (err) { res.status(500).json({ error: 'Erro ao arquivar seleção: ' + err.message }); }
});

app.put('/api/worlds/:id/files/move', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error:'Mundo não encontrado.' });
  try {
    const oldPath = String(req.body?.path || '').replace(/\\/g,'/');
    const destination = String(req.body?.destination || '').replace(/\\/g,'/');
    if (!oldPath || oldPath.startsWith('/') || oldPath.split('/').includes('..')) return res.status(400).json({ error:'Origem inválida.' });
    if (destination.startsWith('/') || destination.split('/').includes('..')) return res.status(400).json({ error:'Destino inválido.' });
    const base = instanceDirOf(instance.folderName);
    const src = resolveSafePath(base, oldPath);
    const dstDir = resolveSafePath(base, destination);
    if (!fs.existsSync(src) || !fs.existsSync(dstDir) || !fs.statSync(dstDir).isDirectory()) return res.status(400).json({ error:'Origem ou destino não existe.' });
    const dst = path.join(dstDir, path.basename(src));
    resolveSafePath(base, path.relative(base, dst));
    if (fs.existsSync(dst)) return res.status(409).json({ error:'Já existe um item com esse nome no destino.' });
    fs.renameSync(src, dst);
    appendEvent(instance.id, `Item movido: ${oldPath} -> ${path.relative(base, dst)}`);
    res.json({ ok:true, path:path.relative(base, dst).replace(/\\/g,'/') });
  } catch (err) { res.status(400).json({ error:err.message }); }
});

app.put('/api/worlds/:id/files/rename', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const oldPath = String(req.body?.path || '');
    const newName = path.basename(String(req.body?.name || '')).trim();
    if (!oldPath || !newName || newName === '.' || newName === '..') return res.status(400).json({ error: 'Caminho/nome inválido.' });
    const base = instanceDirOf(instance.folderName);
    const oldAbs = resolveSafePath(base, oldPath);
    const newAbs = path.join(path.dirname(oldAbs), newName);
    resolveSafePath(base, path.relative(base, newAbs));
    fs.renameSync(oldAbs, newAbs);
    appendEvent(instance.id, `Arquivo/pasta renomeado: ${oldPath} -> ${newName}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.code === 'EEXIST' ? 'Já existe um item com esse nome.' : err.message });
  }
});

app.delete('/api/worlds/:id/files', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const relPath = String(req.query.path || '');
    if (!relPath) return res.status(400).json({ error: 'Não é permitido apagar a raiz do servidor.' });
    const target = resolveSafePath(instanceDirOf(instance.folderName), relPath);
    fs.rmSync(target, { recursive: true, force: false });
    appendEvent(instance.id, `Arquivo/pasta excluído: ${relPath}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/worlds/:id/files/download', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  try {
    const relPath = String(req.query.path || '');
    const target = resolveSafePath(instanceDirOf(instance.folderName), relPath);
    if (fs.statSync(target).isDirectory()) {
      const archive = archiver('zip', { zlib: { level: 6 } });
      const name = path.basename(target) || instance.folderName;
      res.attachment(`${name}.zip`);
      archive.on('error', err => { if (!res.headersSent) res.status(500).json({ error: err.message }); });
      archive.pipe(res);
      archive.directory(target, name);
      archive.finalize();
    } else {
      res.download(target);
    }
  } catch (err) {
    res.status(404).json({ error: err.message });
  }
});

app.get('/api/worlds/:id/allowlist', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  res.json({ allowlist: readAllowlist(instanceDirOf(instance.folderName)) });
});

app.post('/api/worlds/:id/allowlist', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const { name } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Nome do jogador é obrigatório.' });
  try {
    const list = addToAllowlist(instanceDirOf(instance.folderName), name.trim());
    appendEvent(instance.id, `Jogador "${name.trim()}" adicionado à allowlist.`);
    res.json({ ok: true, allowlist: list });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/worlds/:id/allowlist/:name', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const list = removeFromAllowlist(instanceDirOf(instance.folderName), req.params.name);
  appendEvent(instance.id, `Jogador "${req.params.name}" removido da allowlist.`);
  res.json({ ok: true, allowlist: list });
});

// ---------- SOFTWARE (só Bedrock — reinstala pra evitar conflito) ----------
app.get('/api/worlds/:id/software', (req, res) => {
  const instance = getInstance(req.params.id);
  if (!instance) return res.status(404).json({ error: 'Mundo não encontrado.' });
  const versions = listInstalledVersions();
  res.json({
    software: 'Bedrock Dedicated Server',
    binaryAvailable: isBdsBinaryAvailable(instance.version),
    binDir: BDS_BIN_DIR,
    currentVersion: instance.version || null,
    versions,
    latest: versions[0] || null
  });
});

// ---------- WEBSOCKET DE CONSOLE EM TEMPO REAL ----------
wss.on('connection', (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const instanceId = url.searchParams.get('instanceId');
  const instance = instanceId && getInstance(instanceId);
  if (!instance) {
    ws.send(JSON.stringify({ type: 'log', line: '[ERROR] instanceId inválido.' }));
    ws.close();
    return;
  }
  attachSocket(instance.id, ws);

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === 'command' && msg.command) {
        sendCommand(instance.id, msg.command);
      }
    } catch { /* ignora mensagens malformadas */ }
  });
});

// ---------- handler de erro genérico (evita HTML feio do multer/express, sempre devolve JSON) ----------
app.use((err, req, res, next) => {
  if (err.name === 'MulterError') {
    const msg = err.code === 'LIMIT_FILE_SIZE' ? 'Arquivo maior que o limite de 200MB por upload.' : err.message;
    return res.status(400).json({ error: msg });
  }
  console.error('[erro não tratado]', err);
  res.status(500).json({ error: err.message || 'Erro interno.' });
});

server.listen(PORT, () => {
  console.log(`Backend rodando em http://0.0.0.0:${PORT}`);
  console.log(`WebSocket do console em ws://0.0.0.0:${PORT}/ws/console`);
  console.log(isBdsBinaryAvailable()
    ? `Binário do BDS encontrado em ${BDS_BIN_DIR}`
    : `⚠️  Binário do BDS NÃO encontrado em ${BDS_BIN_DIR} — start/stop vão falhar até você colocar o bedrock_server lá.`);
});
