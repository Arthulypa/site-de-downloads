export const IconPlay = (props) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M8 5v14l11-7z" />
  </svg>
);

export const IconStop = (props) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <rect x="6" y="6" width="12" height="12" rx="2" />
  </svg>
);

export const IconRestart = (props) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M21 12a9 9 0 1 1-3-6.7" />
    <polyline points="21 3 21 9 15 9" />
  </svg>
);

export const IconWrench = (props) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L2 19l3 3 7.3-7.3a4 4 0 0 0 5.4-5.4l-2.8 2.8-2-2z" />
  </svg>
);

export const IconBack = (props) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <polyline points="15 18 9 12 15 6" />
  </svg>
);

export const IconTrash = (props) => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <polyline points="3 6 5 6 21 6" />
    <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m5 0V4a2 2 0 0 1 2-2h0a2 2 0 0 1 2 2v2" />
  </svg>
);

export const IconCheck = (props) => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <polyline points="20 6 9 17 4 12" />
  </svg>
);

export const IconX = (props) => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

export const IconSettings = (props) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </svg>
);


const makeIcon = (path, extra='') => (props) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" {...props}>
    {path}{extra}
  </svg>
);

export const IconServer = makeIcon(<><rect x="3" y="4" width="18" height="6" rx="1.5"/><rect x="3" y="14" width="18" height="6" rx="1.5"/><path d="M7 7h.01M7 17h.01"/></>);
export const IconSliders = makeIcon(<><path d="M4 6h6M14 6h6M4 12h2M10 12h10M4 18h10M18 18h2"/><circle cx="12" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="16" cy="18" r="2"/></>);
export const IconTerminal = makeIcon(<><path d="m5 7 4 5-4 5"/><path d="M12 17h7"/></>);
export const IconActivity = makeIcon(<><path d="M3 12h4l2-6 4 12 2-6h6"/></>);
export const IconUsers = makeIcon(<><path d="M16 20v-1.5a4.5 4.5 0 0 0-9 0V20"/><circle cx="11.5" cy="8" r="3"/><path d="M18 11a2.8 2.8 0 0 1 0 5M18.5 20v-1a4 4 0 0 0-2-3.5"/></>);
export const IconCode = makeIcon(<><path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/></>);
export const IconFolder = makeIcon(<><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v7A2.5 2.5 0 0 1 18.5 19h-13A2.5 2.5 0 0 1 3 16.5z"/></>);
// Versão preenchida (flat), usada na lista de arquivos — combina com o visual
// de pasta dourada sólida do painel de referência, em vez do contorno fino.
export const IconFolderFilled = (props) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v7A2.5 2.5 0 0 1 18.5 19h-13A2.5 2.5 0 0 1 3 16.5z" />
  </svg>
);
export const IconWorld = makeIcon(<><circle cx="12" cy="12" r="8.5"/><path d="M3.8 9h16.4M3.8 15h16.4M12 3.5c2 2.3 3 5.2 3 8.5s-1 6.2-3 8.5c-2-2.3-3-5.2-3-8.5s1-6.2 3-8.5z"/></>);
export const IconBackup = makeIcon(<><path d="M4 7h16v13H4z"/><path d="M8 4h8l2 3H6zM8 12h8M8 16h5"/></>);
export const IconPuzzle = makeIcon(<><path d="M7 4h4v4h2V4h4v4h3v4h-3v4h-4v-3H9v3H5v-4H2V9h5z"/></>);
export const IconAlert = makeIcon(<><path d="M12 4 21 20H3z"/><path d="M12 9v5M12 17h.01"/></>);
export const IconMenu = makeIcon(<><path d="M4 7h16M4 12h16M4 17h16"/></>);
export const IconBolt = makeIcon(<><path d="m13 2-8 11h6l-1 9 8-12h-6z"/></>);
export const IconCopy = makeIcon(<><rect x="7" y="7" width="11" height="11" rx="1.5"/><path d="M5 17V5a1.5 1.5 0 0 1 1.5-1.5H17"/></>);
export const IconClose = makeIcon(<><path d="m6 6 12 12M18 6 6 18"/></>);
export const IconFlask = makeIcon(<><path d="M9 3h6M10 3v6l-5.5 9.5A2.3 2.3 0 0 0 6.5 22h11a2.3 2.3 0 0 0 2-3.5L14 9V3"/><path d="M7 16h10"/></>);

export const IconArrowUp = makeIcon(<><path d="m6 10 6-6 6 6"/><path d="M12 4v16"/></>);
export const IconArrowDown = makeIcon(<><path d="m6 14 6 6 6-6"/><path d="M12 4v16"/></>);
export const IconLayers = makeIcon(<><path d="m12 3 9 5-9 5-9-5 9-5z"/><path d="m3 12 9 5 9-5"/><path d="m3 16 9 5 9-5"/></>);


export const IconFile = makeIcon(<><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v5h5M9 13h6M9 17h5"/></>);
export const IconFilePlus = makeIcon(<><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v5h5"/><path d="M12 12v6M9 15h6"/></>);
export const IconJson = makeIcon(<><path d="M8 4H6a2 2 0 0 0-2 2v4a2 2 0 0 1-2 2 2 2 0 0 1 2 2v4a2 2 0 0 0 2 2h2M16 4h2a2 2 0 0 1 2 2v4a2 2 0 0 0 2 2 2 2 0 0 0-2 2v4a2 2 0 0 1-2 2h-2"/></>);
export const IconArchive = makeIcon(<><path d="M4 7h16v13H4z"/><path d="M3 4h18v3H3zM9 11h6M10 15h4"/></>);
export const IconLock = makeIcon(<><rect x="4" y="10" width="16" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>);
export const IconUpload = makeIcon(<><path d="M12 16V4M7 9l5-5 5 5"/><path d="M5 20h14"/></>);
export const IconFolderPlus = makeIcon(<><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v7A2.5 2.5 0 0 1 18.5 19h-13A2.5 2.5 0 0 1 3 16.5z"/><path d="M12 10v6M9 13h6"/></>);

export const IconSearch = makeIcon(<><circle cx="11" cy="11" r="6.5"/><path d="m16 16 5 5"/></>);
