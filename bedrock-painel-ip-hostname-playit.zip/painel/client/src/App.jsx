import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { api, connectConsole, API_BASE } from './api.js';
import { IconPlay, IconStop, IconRestart, IconWrench, IconBack, IconTrash, IconSettings, IconServer, IconSliders, IconTerminal, IconActivity, IconUsers, IconCode, IconFolderFilled, IconWorld, IconBackup, IconPuzzle, IconAlert, IconMenu, IconBolt, IconClose, IconArrowUp, IconArrowDown, IconLayers, IconFlask, IconCopy, IconSearch, IconFile, IconFilePlus, IconJson, IconArchive, IconLock, IconUpload, IconFolderPlus } from './icons.jsx';
import Toggle from './Toggle.jsx';
import Sidebar from './Sidebar.jsx';

// Linha estilo Exaroton: título + descrição opcional à esquerda, controle à direita,
// e a chave real do server.properties em monospace embaixo (pra quem entende, confere).
function PropertyRow({ title, hint, propKey, children }) {
  return (
    <div className="property-row" style={{ background: 'var(--theme-panel, #161e2e)', border: '1px solid var(--theme-border, #232f42)', borderRadius: '14px', padding: '14px 16px', marginBottom: '10px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '14px' }}>
        <div>
          <div style={{ fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)' }}>{title}</div>
          {hint && <div style={{ fontSize: '10px', color: 'var(--theme-dim)', marginTop: '2px' }}>{hint}</div>}
        </div>
        {children}
      </div>
      {propKey && <div style={{ fontSize: '10px', color: '#475569', fontFamily: 'monospace', marginTop: '10px' }}>{propKey}</div>}
    </div>
  );
}

const STATUS_COLORS = {
  Online: 'var(--panel-accent)',
  Offline: '#334155',
  Iniciando: '#fbbf24',
  Parando: '#fbbf24'
};

function FileTypeIcon({ entry }) {
  if (entry?.isDir || entry?.kind === 'folder') return <IconFolderFilled className="ft-icon ft-folder" width="19" height="19" />;
  if (entry?.kind === 'archive') return <IconArchive className="ft-icon ft-archive" width="17" height="17" />;
  if (entry?.kind === 'json') return <IconJson className="ft-icon ft-json" width="17" height="17" />;
  if (entry?.kind === 'text') return <IconFile className="ft-icon ft-text" width="17" height="17" />;
  return <IconFile className="ft-icon ft-file" width="17" height="17" />;
}

// Formata a data de modificação de um arquivo/pasta: relativo pra coisas
// recentes ("4 min atrás"), data e hora completas pra coisas mais antigas —
// igual ao padrão que a maioria dos gerenciadores de arquivo usa.
function formatFileDate(iso) {
  if (!iso) return '—';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '—';
  const diffMs = Date.now() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return 'agora mesmo';
  if (diffMin < 60) return `${diffMin} min atrás`;
  const diffH = Math.floor(diffMin / 60);
  if (diffH < 24) return `${diffH}h atrás`;
  return date.toLocaleString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function App() {
  // Porta interna do BDS -> porta pública mostrada ao usuário.
  // O BDS continua ouvindo em 19132–19135.
  const DISPLAY_PORTS = { 19132: 42567, 19133: 42576, 19134: 42579, 19135: 42822 };
  // Endereços públicos dos túneis, conforme a configuração do Playit.
  // O hostname é o endereço principal que deve ser mostrado aos jogadores;
  // o IP numérico também fica disponível como informação alternativa.
  const PUBLIC_CONNECTIONS = {
    42567: { host: 'laurel-adopt.tun.ply.gg', ip: '147.185.221.214', port: 42567 },
    42576: { host: 'laurel-katrina.tun.ply.gg', ip: '147.185.221.214', port: 42576 },
    42579: { host: 'laurel-seeds.tun.ply.gg', ip: '147.185.221.213', port: 42579 },
    42822: { host: 'laurel-norman.tun.ply.gg', ip: '147.185.221.213', port: 42822 }
  };
  const displayPort = (port) => DISPLAY_PORTS[Number(port)] ?? port;
  const getConnectionInfo = (port) => {
    const publicPort = Number(displayPort(port));
    return PUBLIC_CONNECTIONS[publicPort] || {
      host: serverStatus?.effectiveIp || 'localhost',
      ip: serverStatus?.effectiveIp || 'localhost',
      port: publicPort
    };
  };
  const [currentView, setCurrentView] = useState('list'); // list | create | dashboard
  const [activeTab, setActiveTab] = useState('server');

  const [worlds, setWorlds] = useState([]);
  const [maxWorlds, setMaxWorlds] = useState(2);
  const [poolInfo, setPoolInfo] = useState({ totalUsedLabel: '0 MB', totalPoolLabel: '40.00 GB' });
  const [serverStatus, setServerStatus] = useState(null); // /api/status
  const [selectedId, setSelectedId] = useState(null);
  const [banner, setBanner] = useState(null); // { type: 'error'|'info', text }

  const [newName, setNewName] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newPort, setNewPort] = useState('');
  const [showNetworkSettings, setShowNetworkSettings] = useState(false);
  const [settingsPassword, setSettingsPassword] = useState('');
  const [theme, setTheme] = useState(() => { try { return localStorage.getItem('bedrock-theme') || 'dark'; } catch { return 'dark'; } });
  const [accent, setAccent] = useState(() => { try { return localStorage.getItem('bedrock-accent') || 'var(--panel-accent)'; } catch { return 'var(--panel-accent)'; } });
  const [appearanceSaved, setAppearanceSaved] = useState(true);
  const [networkIpInput, setNetworkIpInput] = useState('');
  const [savedNetworkIp, setSavedNetworkIp] = useState('');
  const [newSeed, setNewSeed] = useState('');
  const [newVersion, setNewVersion] = useState('latest');
  const [versionsInfo, setVersionsInfo] = useState(null); // { versions: [], latest }
  const [creating, setCreating] = useState(false);

  const [properties, setProperties] = useState(null);
  const [propsSaving, setPropsSaving] = useState(false);
  const savedPropertiesRef = useRef(null);
  const [experiments, setExperiments] = useState(null); // { available, experiments|reason }
  const [expSaving, setExpSaving] = useState(false);

  const [logs, setLogs] = useState([]);
  const [commandInput, setCommandInput] = useState('');
  const [consoleResources, setConsoleResources] = useState(null);
  const [connIp, setConnIp] = useState(null);
  const consoleEndRef = useRef(null);
  const [consoleSearchOpen, setConsoleSearchOpen] = useState(false);
  const [consoleSearch, setConsoleSearch] = useState('');
  const wsRef = useRef(null);

  const [reinstallPin, setReinstallPin] = useState('');
  const [deletePass, setDeletePass] = useState('');
  const [addonUploading, setAddonUploading] = useState(false);
  const [addonReview, setAddonReview] = useState(null);
  const [addonPendingFile, setAddonPendingFile] = useState(null);
  const [addonPendingFiles, setAddonPendingFiles] = useState([]);
  const [addonReviewExpanded, setAddonReviewExpanded] = useState(false);
  const [addonReviewSelected, setAddonReviewSelected] = useState(null);
  const [addonProgress, setAddonProgress] = useState([]);
  const [addonWarnings, setAddonWarnings] = useState([]);
  const [dragActive, setDragActive] = useState(false);
  const [addonKindTab, setAddonKindTab] = useState('all');
  const [addonReorderMode, setAddonReorderMode] = useState('arrows');
  const [addonDraggingId, setAddonDraggingId] = useState(null);
  const [addonDragOverId, setAddonDragOverId] = useState(null);
  const addonPointerTimerRef = useRef(null);

  const [batteryInfo, setBatteryInfo] = useState(null);
  const lastBatteryAlertRef = useRef(null);

  const [players, setPlayers] = useState(null); // { online, max, names }
  const [ramStatus, setRamStatus] = useState(null);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [events, setEvents] = useState([]);
  const [allowlist, setAllowlist] = useState([]);
  const [newAllowlistName, setNewAllowlistName] = useState('');
  const [softwareInfo, setSoftwareInfo] = useState(null);
  const [swPin, setSwPin] = useState('');
  const [swVersion, setSwVersion] = useState('');
  const [filesPath, setFilesPath] = useState('');
  const [fileEntries, setFileEntries] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [fileMenuPath, setFileMenuPath] = useState(null);
  const [imagePreview, setImagePreview] = useState(null); // { name, url } | null
  const [imagePreviewError, setImagePreviewError] = useState(null);
  const [fileEditor, setFileEditor] = useState(null);
  const [fileEditorSaving, setFileEditorSaving] = useState(false);
  const [fileUploadBusy, setFileUploadBusy] = useState(false);
  const [backups, setBackups] = useState([]);
  const [genSeed, setGenSeed] = useState('');
  const [genExperiments, setGenExperiments] = useState({ upcomingCreatorFeatures: false, gametest: false, holidayCreatorFeatures: false });
  const [genConfirming, setGenConfirming] = useState(false); // aguardando o usuário confirmar apagar o mundo atual
  const [genWorking, setGenWorking] = useState(false);
  const [importFile, setImportFile] = useState(null);
  const [importConfirming, setImportConfirming] = useState(false);
  const [importWorking, setImportWorking] = useState(false);
  const [forceStopConfirming, setForceStopConfirming] = useState(false);
  const [forceStopping, setForceStopping] = useState(false);
  const [initialReveal, setInitialReveal] = useState(() => {
    try { return sessionStorage.getItem('bedrock-panel-reveal-v6') !== '1'; } catch { return true; }
  });
  const [initialDataReady, setInitialDataReady] = useState(false);

  const selected = useMemo(() => worlds.find(w => w.id === selectedId) || null, [worlds, selectedId]);

  const ACCENTS = useMemo(() => [
    ['Verde', 'var(--panel-accent)'], ['Ciano', '#06b6d4'], ['Azul céu', '#0ea5e9'], ['Azul', '#3b82f6'],
    ['Violeta', '#8b5cf6'], ['Fúcsia', '#d946ef'], ['Rosa', '#ec4899'], ['Vermelho', '#ef4444'],
    ['Laranja', '#f97316'], ['Âmbar', '#f59e0b']
  ], []);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.setProperty('--panel-accent', accent);
    document.documentElement.style.setProperty('--panel-accent-soft', `${accent}22`);
    try { localStorage.setItem('bedrock-theme', theme); localStorage.setItem('bedrock-accent', accent); } catch {}
  }, [theme, accent]);

  useEffect(() => {
    if (!serverStatus) return;
    const serverTheme = serverStatus.theme || 'dark';
    const serverAccent = serverStatus.accent || accent;
    setAppearanceSaved(theme === serverTheme && accent === serverAccent);
  }, [theme, accent, serverStatus]);

  const showError = (err) => setBanner({ type: 'error', text: err.message || String(err) });
  const showInfo = (text) => setBanner({ type: 'info', text });

  useEffect(() => {
    if (!banner) return undefined;
    const timer = window.setTimeout(() => setBanner(null), 5000);
    return () => window.clearTimeout(timer);
  }, [banner]);

  useEffect(() => {
    let battery = null;
    let disposed = false;
    const applyBattery = (level, charging) => {
      if (!Number.isFinite(level)) return;
      const rounded = Math.round(level);
      setBatteryInfo({ level: rounded, charging: !!charging });
      if (!charging && rounded <= 20) {
        const bucket = rounded <= 10 ? 'critical' : 'low';
        if (lastBatteryAlertRef.current !== bucket) {
          lastBatteryAlertRef.current = bucket;
          showInfo(bucket === 'critical' ? `Bateria crítica: ${rounded}%. Conecte o carregador.` : `Bateria baixa: ${rounded}%.`);
        }
      } else if (rounded > 20 || charging) {
        lastBatteryAlertRef.current = null;
      }
    };
    const updateBrowserBattery = () => {
      if (!battery || disposed) return;
      applyBattery((battery.level || 0) * 100, battery.charging);
    };
    const init = async () => {
      try {
        if (navigator.getBattery) {
          battery = await navigator.getBattery();
          updateBrowserBattery();
          battery.addEventListener('levelchange', updateBrowserBattery);
          battery.addEventListener('chargingchange', updateBrowserBattery);
        }
      } catch {}
      try {
        const readServerBattery = async () => {
          if (disposed) return;
          const r = await api.systemBattery();
          if (r?.available) applyBattery(r.level, r.charging);
        };
        await readServerBattery();
        const interval = setInterval(readServerBattery, 15000);
        return () => clearInterval(interval);
      } catch {}
      return undefined;
    };
    let cleanupPoll;
    init().then(c => { cleanupPoll = c; });
    return () => {
      disposed = true;
      if (cleanupPoll) cleanupPoll();
      if (battery) {
        battery.removeEventListener('levelchange', updateBrowserBattery);
        battery.removeEventListener('chargingchange', updateBrowserBattery);
      }
    };
  }, []);

  // ---------- carregar lista de mundos (com polling leve pra refletir status) ----------
  const refreshWorlds = useCallback(async () => {
    try {
      const data = await api.listWorlds();
      setWorlds(data.worlds);
      setMaxWorlds(data.maxWorlds);
      setPoolInfo({ totalUsedLabel: data.totalUsedLabel, totalPoolLabel: data.totalPoolLabel });
    } catch (err) {
      showError(err);
    }
  }, []);

  useEffect(() => {
    let alive = true;
    const loadInitial = async () => {
      try {
        const [statusData, worldsData] = await Promise.all([api.status(), api.listWorlds()]);
        if (!alive) return;
        setServerStatus(statusData);
        setNetworkIpInput(statusData.networkIp || '');
        setSavedNetworkIp(statusData.networkIp || '');
        setTheme(statusData.theme || 'dark');
        setAccent(statusData.accent || 'var(--panel-accent)');
        setAppearanceSaved(true);
        setWorlds(worldsData.worlds || []);
        setMaxWorlds(worldsData.maxWorlds ?? 2);
        setPoolInfo({ totalUsedLabel: worldsData.totalUsedLabel || '0 MB', totalPoolLabel: worldsData.totalPoolLabel || '4.00 GB' });
        setInitialDataReady(true);
      } catch (err) {
        if (alive) showError(err);
      }
    };
    loadInitial();
    const interval = setInterval(refreshWorlds, 4000);
    return () => { alive = false; clearInterval(interval); };
  }, [refreshWorlds]);

  useEffect(() => {
    if (!initialReveal) return;
    const started = performance.now();
    let timer;
    const finish = () => {
      const elapsed = performance.now() - started;
      const remaining = Math.max(0, 1450 - elapsed);
      timer = setTimeout(() => {
        setInitialReveal(false);
        try { sessionStorage.setItem('bedrock-panel-reveal-v6', '1'); } catch {}
      }, remaining);
    };
    if (initialDataReady) finish();
    else timer = setTimeout(finish, 2600);
    return () => clearTimeout(timer);
  }, [initialReveal, initialDataReady]);

  useEffect(() => {
    if (currentView === 'create' && serverStatus?.suggestedPort && !newPort) {
      setNewPort(String(serverStatus.suggestedPort));
    }
  }, [currentView, serverStatus]);

  const handleSaveAppearance = async () => {
    try {
      const r = await api.putSettings({ theme, accent });
      setServerStatus(prev => ({ ...prev, theme: r.theme, accent: r.accent }));
      setAppearanceSaved(true);
      showInfo('Aparência salva.');
    } catch (err) { showError(err); }
  };

  const handleSaveNetworkIp = async () => {
    try {
      const r = await api.putSettings({ networkIp: networkIpInput.trim() || null, password: settingsPassword });
      setServerStatus(prev => ({ ...prev, networkIp: networkIpInput.trim() || null, effectiveIp: r.effectiveIp }));
      setSettingsPassword('');
      setSavedNetworkIp(networkIpInput);
      showInfo('IP de rede atualizado.');
    } catch (err) { showError(err); }
  };

  // ---------- ao entrar no dashboard: carregar properties + experiments + conectar console ----------
  useEffect(() => {
    if (currentView !== 'dashboard' || !selectedId) return;
    setProperties(null);
    setExperiments(null);
    setLogs([]);
    setConnIp(null);

    api.getProperties(selectedId).then(r => {
      setProperties(r.properties);
      savedPropertiesRef.current = JSON.stringify(r.properties);
    }).catch(showError);

    const ws = connectConsole(selectedId, {
      onHistory: (h) => setLogs(h),
      onLog: (line) => setLogs(prev => [...prev.slice(-499), line]),
      onStatus: () => refreshWorlds()
    });
    wsRef.current = ws;
    return () => {
      ws.close();
      wsRef.current = null;
    };
  }, [currentView, selectedId, refreshWorlds]);

  useEffect(() => {
    if (currentView !== 'dashboard' || !selectedId) return;
    if (activeTab === 'experiments' && selected && !selected.generated) {
      setActiveTab('server');
      return;
    }
    if (activeTab !== 'experiments') return;
    let alive = true;
    setExperiments(null);
    // Mesmo sem level.dat, consultamos o backend para mostrar o estado real
    // em vez de deixar a aba presa no loading ou desmontar o dashboard.
    api.getExperiments(selectedId).then(data => { if (alive) setExperiments(data); }).catch(err => { if (alive) { setExperiments({ available: false, reason: 'Não foi possível carregar os experimentos.' }); showError(err); } });
    return () => { alive = false; };
  }, [currentView, activeTab, selectedId, selected?.generated]);

  useEffect(() => {
    if (activeTab === 'console') consoleEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs, activeTab]);

  useEffect(() => {
    if (activeTab !== 'console') return;
    let alive = true;
    const load = () => api.systemResources().then(r => { if (alive) setConsoleResources(r); }).catch(() => {});
    load();
    const interval = setInterval(load, 4000);
    return () => { alive = false; clearInterval(interval); };
  }, [activeTab]);


  // ---------- jogadores online (via comando "list" real, só quando faz sentido perguntar) ----------
  useEffect(() => {
    if (activeTab !== 'server' || !selected || selected.status !== 'Online') { setPlayers(null); return; }
    const fetchPlayers = () => api.getPlayers(selected.id).then(setPlayers).catch(() => {});
    fetchPlayers();
    const interval = setInterval(fetchPlayers, 8000);
    return () => clearInterval(interval);
  }, [activeTab, selected?.id, selected?.status]);

  useEffect(() => {
    if (activeTab === 'options') api.getRamStatus().then(setRamStatus).catch(() => {});
  }, [activeTab]);

  useEffect(() => {
    if (activeTab === 'events' && selectedId) api.getEvents(selectedId).then(r => setEvents(r.events)).catch(() => {});
  }, [activeTab, selectedId]);

  useEffect(() => {
    if (activeTab === 'players' && selectedId) api.getAllowlist(selectedId).then(r => setAllowlist(r.allowlist)).catch(() => {});
  }, [activeTab, selectedId]);

  useEffect(() => {
    if (activeTab === 'software' && selectedId) {
      api.getSoftware(selectedId).then(info => {
        setSoftwareInfo(info);
        setSwVersion(info.currentVersion || info.latest || '');
      }).catch(() => {});
    }
  }, [activeTab, selectedId]);

  // Ao abrir a tela de criação, carrega as versões do BDS disponíveis em bds-bin/
  // pra montar o seletor de versão (default: a mais recente).
  useEffect(() => {
    if (currentView === 'create') {
      api.getSoftwareVersions().then(info => {
        setVersionsInfo(info);
        setNewVersion('latest');
      }).catch(() => setVersionsInfo({ versions: [], latest: null }));
    }
  }, [currentView]);

  const navigateFiles = (newPath) => {
    setFilesPath(newPath);
    setSelectedFiles([]);
    setFileEditor(null);
    setImagePreview(null);
    api.listFiles(selectedId, newPath).then(r => setFileEntries(r.entries)).catch(showError);
  };
  useEffect(() => {
    if (activeTab === 'files' && selectedId) navigateFiles('');
  }, [activeTab, selectedId]);

  const refreshBackups = () => api.listBackups(selectedId).then(r => setBackups(r.backups)).catch(() => {});
  useEffect(() => {
    if (activeTab === 'backups' && selectedId) refreshBackups();
  }, [activeTab, selectedId]);

  const handleAddAllowlist = async () => {
    if (!newAllowlistName.trim()) return;
    try {
      const r = await api.addToAllowlist(selectedId, newAllowlistName.trim());
      setAllowlist(r.allowlist);
      setNewAllowlistName('');
    } catch (err) { showError(err); }
  };
  const handleRemoveAllowlist = async (name) => {
    try {
      const r = await api.removeFromAllowlist(selectedId, name);
      setAllowlist(r.allowlist);
    } catch (err) { showError(err); }
  };

  const handleSoftwareUpdate = async () => {
    try {
      const r = await api.updateSoftware(selectedId, swPin, swVersion);
      showInfo(`Servidor atualizado para a versão ${r.version} (mundo mantido).`);
      setSwPin('');
      setSoftwareInfo(prev => prev ? { ...prev, currentVersion: r.version } : prev);
      refreshWorlds();
    } catch (err) { showError(err); }
  };

  const handleSoftwareReinstall = async () => {
    try {
      const r = await api.reinstall(selectedId, swPin, swVersion);
      showInfo(swVersion && swVersion !== softwareInfo?.currentVersion
        ? `Servidor reinstalado na versão ${r.version}.`
        : 'Servidor reinstalado.');
      setSwPin('');
      setSoftwareInfo(prev => prev ? { ...prev, currentVersion: r.version } : prev);
      refreshWorlds();
    } catch (err) { showError(err); }
  };

  const handleToggleRamCache = async (enabled) => {
    try {
      await api.setRamCache(selectedId, enabled);
      showInfo(enabled ? 'Cache em RAM ativado — vale a partir do próximo Ligar.' : 'Cache em RAM desativado.');
      refreshWorlds();
    } catch (err) { showError(err); }
  };
  const handleRamSyncNow = async () => {
    try {
      const r = await api.ramSyncNow(selectedId);
      showInfo(r.message);
    } catch (err) { showError(err); }
  };

  // ---------- gerar mundo novo (com confirmação real, apaga o mundo atual) ----------
  const handleGenerateWorld = async (confirm = false) => {
    setGenWorking(true);
    try {
      const r = await api.generateWorld(selectedId, { seed: genSeed.trim(), experiments: genExperiments, confirm });
      if (r.needsConfirm) {
        setGenConfirming(true);
        showInfo(r.error);
        return;
      }
      setGenConfirming(false);
      showInfo(r.message);
      refreshWorlds();
    } catch (err) { showError(err); }
    finally { setGenWorking(false); }
  };

  // ---------- importar mundo (.zip com level.dat, com confirmação real) ----------
  const handleImportWorld = async (confirm = false) => {
    if (!importFile) return showError(new Error('Selecione o .zip do mundo primeiro.'));
    setImportWorking(true);
    try {
      const r = await api.importWorld(selectedId, importFile, confirm);
      if (r.needsConfirm) {
        setImportConfirming(true);
        showInfo(r.error);
        return;
      }
      setImportConfirming(false);
      setImportFile(null);
      showInfo(r.message);
      refreshWorlds();
    } catch (err) { showError(err); }
    finally { setImportWorking(false); }
  };


  const refreshFiles = useCallback((p = filesPath) => {
    if (!selectedId) return;
    return api.listFiles(selectedId, p).then(r => setFileEntries(r.entries)).catch(showError);
  }, [selectedId, filesPath]);

  // Menus de arquivos fecham ao clicar/toque fora. O listener em captura evita
  // que overlays, cards ou elementos com stacking context escondam o menu aberto.
  useEffect(() => {
    if (!fileMenuPath) return undefined;
    const closeOutside = (event) => {
      if (!(event.target instanceof Element)) return;
      if (!event.target.closest('.file-menu-root')) setFileMenuPath(null);
    };
    document.addEventListener('pointerdown', closeOutside, true);
    return () => document.removeEventListener('pointerdown', closeOutside, true);
  }, [fileMenuPath]);

  const handleArchiveSelectedFiles = async () => {
    if (!selectedFiles.length || !selectedId) return;
    try {
      const r = await api.archiveSelectedFiles(selectedId, selectedFiles, filesPath);
      const count = selectedFiles.length;
      setSelectedFiles([]);
      setFileMenuPath(null);
      await refreshFiles(filesPath);
      showInfo(`${count} item(ns) arquivado(s) em ${r.name}.`);
    } catch (err) { showError(err); }
  };

  const handleFileUpload = async (files) => {
    if (!files?.length) return;
    setFileUploadBusy(true);
    try { await api.uploadFiles(selectedId, filesPath, files); showInfo(`${files.length} arquivo(s) enviado(s).`); await refreshFiles(filesPath); }
    catch (err) { showError(err); } finally { setFileUploadBusy(false); }
  };
  const handleCreateFolder = async () => {
    const name = window.prompt('Nome da nova pasta:');
    if (!name) return;
    try { await api.createFolder(selectedId, filesPath, name); await refreshFiles(filesPath); } catch (err) { showError(err); }
  };
  const handleCreateFile = async () => {
    const name = window.prompt('Nome do novo arquivo:');
    if (!name) return;
    try { await api.createFile(selectedId, filesPath, name); await refreshFiles(filesPath); } catch (err) { showError(err); }
  };
  const handleRenameFile = async (entry) => {
    const name = window.prompt('Novo nome:', entry.name);
    if (!name || name === entry.name) return;
    try { await api.renameFile(selectedId, entry.path, name); await refreshFiles(filesPath); } catch (err) { showError(err); }
  };
  const handleArchiveFile = async (entry) => {
    if (!entry?.path || entry.isDir && !window.confirm(`Compactar a pasta ${entry.name} em um ZIP?`)) return;
    try {
      const r = await api.archiveFile(selectedId, entry.path);
      await refreshFiles(filesPath);
      showInfo(`Arquivado em ${r.name}.`);
    } catch (err) { showError(err); }
  };
  const handleMoveFile = async (entry) => {
    const destination = window.prompt('Mover para a pasta (deixe vazio para a raiz):', filesPath || '');
    if (destination === null) return;
    try {
      await api.moveFile(selectedId, entry.path, destination.trim().replace(/^\/+|\/+$/g,''));
      await refreshFiles(filesPath);
      showInfo(`${entry.name} movido.`);
    } catch (err) { showError(err); }
  };

  const handleDeleteFile = async (entry) => {
    if (!window.confirm(`Excluir ${entry.name}?`)) return;
    try { await api.deleteFile(selectedId, entry.path); await refreshFiles(filesPath); } catch (err) { showError(err); }
  };
  const handleDeleteSelectedFiles = async () => {
    if (!selectedFiles.length || !selectedId) return;
    if (!window.confirm(`Excluir ${selectedFiles.length} item(ns) permanentemente?`)) return;
    try {
      for (const filePath of selectedFiles) await api.deleteFile(selectedId, filePath);
      setSelectedFiles([]);
      setFileMenuPath(null);
      await refreshFiles(filesPath);
      showInfo('Itens selecionados apagados.');
    } catch (err) { showError(err); }
  };
  const handleEditFile = async (entry) => {
    if (entry.isDir) return;
    try { const r = await api.readFile(selectedId, entry.path); setFileEditor({ path: entry.path, content: r.content }); } catch (err) { showError(err); }
  };
  const handleSaveFile = async () => {
    if (!fileEditor) return;
    setFileEditorSaving(true);
    try { await api.writeFile(selectedId, fileEditor.path, fileEditor.content); showInfo('Arquivo salvo.'); setFileEditor(null); await refreshFiles(filesPath); } catch (err) { showError(err); } finally { setFileEditorSaving(false); }
  };
  // ---------- ações de criar ----------
  const handleCreateServer = async (e) => {
    e.preventDefault();
    if (!newName.trim()) return showError(new Error('Digite o nome do mundo.'));
    if (!versionsInfo?.latest) return showError(new Error(`Nenhuma versão do Bedrock Dedicated Server encontrada em "${versionsInfo?.binDir || 'bds-bin'}". Extraia uma versão antes de criar um mundo.`));
    setCreating(true);
    try {
      const created = await api.createWorld(newName.trim(), newDescription.trim(), newSeed.trim(), {}, newPort, newVersion);
      await refreshWorlds();
      setNewName('');
      setNewDescription('');
      setNewSeed('');
      setNewPort('');
      setNewVersion('latest');
      setSelectedId(created.id);
      setCurrentView('dashboard');
      setActiveTab('server');
    } catch (err) {
      showError(err);
    } finally {
      setCreating(false);
    }
  };

  // ---------- ligar / desligar / reiniciar (ações reais e distintas) ----------
  const startBusyRef = useRef(false);
  const handleStart = async (id) => {
    if (startBusyRef.current) return;
    startBusyRef.current = true;
    try {
      const r = await api.start(id);
      setConnIp(r);
      showInfo(`Iniciando... conecte em ${r.ip}:${displayPort(r.port)}`);
      await refreshWorlds();
    } catch (err) {
      if (String(err?.message || '').startsWith('SERVER_ALREADY_RUNNING:')) {
        showError(new Error('Já existe outro servidor em execução. O servidor que está rodando foi mantido.'));
        await refreshWorlds();
      } else {
        showError(err);
      }
    } finally {
      window.setTimeout(() => { startBusyRef.current = false; }, 250);
    }
  };
  const handleStop = async (id) => {
    try { await api.stop(id); refreshWorlds(); } catch (err) { showError(err); }
  };
  const handleForceStop = async (id) => {
    setForceStopping(true);
    try {
      await api.forceStop(id);
      setForceStopConfirming(false);
      showInfo('Parada de emergência executada. O processo foi encerrado à força.');
      await refreshWorlds();
    } catch (err) { showError(err); }
    finally { setForceStopping(false); }
  };
  const handleRestart = async (id) => {
    try {
      const r = await api.restart(id);
      setConnIp(r);
      refreshWorlds();
    } catch (err) { showError(err); }
  };

  const handleSendCommand = (e) => {
    e.preventDefault();
    if (!commandInput.trim() || !selectedId) return;
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'command', command: commandInput }));
    } else {
      api.sendCommand(selectedId, commandInput).catch(showError);
    }
    setCommandInput('');
  };

  // ---------- server.properties (form simplificado) ----------
  const updateProp = (key, value) => setProperties(prev => ({ ...prev, [key]: value }));
  const propertiesDirty = !!properties && savedPropertiesRef.current !== null && JSON.stringify(properties) !== savedPropertiesRef.current;
  const networkDirty = networkIpInput !== savedNetworkIp;
  const handleSaveProperties = async () => {
    setPropsSaving(true);
    try {
      const r = await api.putProperties(selectedId, properties);
      savedPropertiesRef.current = JSON.stringify(properties);
      showInfo(r.warning || 'Configurações salvas.');
    } catch (err) { showError(err); }
    finally { setPropsSaving(false); }
  };

  // ---------- experiments reais (level.dat) ----------
  const toggleExperiment = (key) => {
    if (!experiments?.available) return;
    setExperiments(prev => ({ ...prev, experiments: { ...prev.experiments, [key]: !prev.experiments[key] } }));
  };
  const handleSaveExperiments = async () => {
    setExpSaving(true);
    try {
      await api.putExperiments(selectedId, experiments.experiments);
      showInfo('Experiments salvos no level.dat.');
    } catch (err) { showError(err); }
    finally { setExpSaving(false); }
  };

  // ---------- addons reais ----------
  const normalizePreviewPack = (p, sourceIndex = 0, sourceName = '') => ({
    ...p,
    id: `${sourceIndex}:${p.id || p.source || p.name || Math.random().toString(36).slice(2)}`,
    sourceFile: sourceName,
  });

  const handleAddonFiles = async (inputFiles) => {
    const files = Array.from(inputFiles || []).filter(Boolean);
    if (!files.length || !selectedId) return;
    setAddonUploading(true);
    setAddonProgress([]);
    setAddonWarnings([]);
    setAddonReview(null);
    setAddonPendingFile(null);
    setAddonPendingFiles(files);
    setAddonReviewExpanded(false);
    setAddonReviewSelected(null);
    try {
      const previews = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        try {
          const preview = await api.previewAddon(selectedId, file);
          previews.push({ file, preview });
        } catch (err) {
          previews.push({ file, preview: { packs: [], warnings: [`${file.name}: ${err?.message || 'não foi possível analisar o arquivo.'}`] } });
        }
      }

      const packs = previews.flatMap(({ file, preview }, fileIndex) =>
        (preview.packs || []).map(p => normalizePreviewPack(p, fileIndex, file.name))
      );
      const warnings = [...new Set(previews.flatMap(({ file, preview }) => (preview.warnings || []).map(w => `${file.name}: ${w}`)))];
      const review = {
        stacked: files.length > 1 || packs.length > 1,
        installing: false,
        files: previews.map(({ file, preview }) => ({ name: file.name, packs: preview.packs?.length || 0 })),
        packs,
        warnings,
      };
      setAddonReview(review);
      setAddonWarnings([...new Set(warnings)]);
      setAddonProgress(packs.map(p => ({ ...p, progress: 0, state: 'ready' })));

      // Um único arquivo com exatamente um pack instala diretamente.
      if (files.length === 1 && packs.length === 1) {
        await handleConfirmAddonInstall([files[0]], review);
      }
    } catch (err) {
      showError(err);
    } finally {
      setAddonUploading(false);
    }
  };

  const handleAddonFile = (file) => handleAddonFiles(file ? [file] : []);

  const handleConfirmAddonInstall = async (files = addonPendingFiles.length ? addonPendingFiles : (addonPendingFile ? [addonPendingFile] : []), review = addonReview) => {
    if (!files.length || !selectedId) return;
    const packs = review?.packs || [];
    setAddonReview(prev => prev ? { ...prev, installing: true } : prev);
    setAddonUploading(true);
    setAddonProgress(packs.map(p => ({ ...p, progress: 4, state: 'uploading' })));
    const installed = [];
    const warnings = [...(review?.warnings || [])];
    let globalDone = 0;
    const totalUploads = Math.max(1, files.length);
    try {
      for (let fileIndex = 0; fileIndex < files.length; fileIndex++) {
        const file = files[fileIndex];
        const filePacks = packs.filter(p => p.sourceFile === file.name || packs.length === 1);
        try {
          const r = await api.uploadAddon(selectedId, file, {
            confirm: true,
            onProgress: (percent) => {
              const start = (fileIndex / totalUploads) * 100;
              const end = ((fileIndex + 1) / totalUploads) * 100;
              const overall = start + (percent / 100) * (end - start);
              const count = Math.max(1, filePacks.length);
              setAddonProgress(prev => prev.map(p => {
                if (!filePacks.some(fp => fp.id === p.id)) return p;
                const localStart = 0;
                const localEnd = 100;
                const local = Math.max(4, Math.min(96, ((overall - start) / Math.max(1, end - start)) * 100));
                return { ...p, progress: Math.round(local), state: 'uploading' };
              }));
            }
          });
          (r.installed || []).forEach(item => installed.push(item));
          (r.warnings || []).forEach(w => warnings.push(`${file.name}: ${w}`));
          globalDone++;
        } catch (err) {
          warnings.push(`${file.name}: ${err?.message || 'erro ao instalar o arquivo.'}`);
          setAddonProgress(prev => prev.map(p => filePacks.some(fp => fp.id === p.id) ? { ...p, state: 'error', progress: 100 } : p));
        }
        const completedFileCount = globalDone;
        setAddonProgress(prev => prev.map(p => {
          const sourceMatches = p.sourceFile === file.name;
          return sourceMatches && p.state !== 'error' && completedFileCount >= globalDone ? { ...p, progress: 100, state: 'done' } : p;
        }));
      }
      setAddonWarnings([...new Set(warnings)]);
      setAddonReview(null);
      setAddonPendingFile(null);
      setAddonPendingFiles([]);
      setAddonReviewExpanded(false);
      setAddonReviewSelected(null);
      showInfo(`Instalado: ${installed.map(i => `${i.name} (${i.type})`).join(', ') || 'nenhum pack válido.'}`);
      if (warnings.length) showInfo(`Instalação concluída com ${warnings.length} aviso(s).`);
      refreshWorlds();
    } catch (err) {
      setAddonProgress(prev => prev.map(p => ({ ...p, state: 'error' })));
      showError(err);
    } finally {
      setAddonUploading(false);
    }
  };
  const handleRemoveAddon = async (addonId) => {
    try { await api.removeAddon(selectedId, addonId); refreshWorlds(); } catch (err) { showError(err); }
  };
  const handleMoveAddon = async (kind, addonId, direction) => {
    const group = (selected?.addons || []).filter(a => a.kind === kind);
    const index = group.findIndex(a => a.id === addonId);
    const target = index + direction;
    if (index < 0 || target < 0 || target >= group.length) return;
    const ids = group.map(a => a.id);
    [ids[index], ids[target]] = [ids[target], ids[index]];
    try {
      await api.reorderAddons(selectedId, kind, ids);
      await refreshWorlds();
      showInfo(`${kind === 'behavior' ? 'BP' : 'RP'} reordenado.`);
    } catch (err) { showError(err); }
  };
  const commitAddonDrop = async (kind, draggedId, targetId) => {
    if (!draggedId || !targetId || draggedId === targetId) {
      setAddonDraggingId(null); setAddonDragOverId(null); return;
    }
    const group = (selected?.addons || []).filter(a => a.kind === kind);
    const from = group.findIndex(a => a.id === draggedId);
    const to = group.findIndex(a => a.id === targetId);
    if (from < 0 || to < 0 || from === to) {
      setAddonDraggingId(null); setAddonDragOverId(null); return;
    }
    const ids = group.map(a => a.id);
    const [moved] = ids.splice(from, 1);
    ids.splice(to, 0, moved);
    try {
      await api.reorderAddons(selectedId, kind, ids);
      await refreshWorlds();
      showInfo(`${kind === 'behavior' ? 'BP' : 'RP'} reordenado.`);
    } catch (err) { showError(err); }
    finally { setAddonDraggingId(null); setAddonDragOverId(null); }
  };

  const startAddonPointerMove = (kind, id, event) => {
    if (addonReorderMode !== 'drag') return;
    if (addonPointerTimerRef.current) window.clearTimeout(addonPointerTimerRef.current);
    const pointerId = event.pointerId;
    const startX = event.clientX;
    const startY = event.clientY;
    addonPointerTimerRef.current = window.setTimeout(() => {
      setAddonDraggingId(id);
      setAddonDragOverId(id);
      try { event.currentTarget.setPointerCapture(pointerId); } catch {}
    }, 280);
    event.currentTarget.dataset.startX = String(startX);
    event.currentTarget.dataset.startY = String(startY);
  };

  const moveAddonPointer = (event) => {
    if (addonReorderMode !== 'drag' || !addonDraggingId) {
      if (addonPointerTimerRef.current) {
        const sx = Number(event.currentTarget?.dataset?.startX || event.clientX);
        const sy = Number(event.currentTarget?.dataset?.startY || event.clientY);
        if (Math.hypot(event.clientX - sx, event.clientY - sy) > 10) {
          window.clearTimeout(addonPointerTimerRef.current);
          addonPointerTimerRef.current = null;
        }
      }
      return;
    }
    const hit = document.elementFromPoint(event.clientX, event.clientY)?.closest('[data-addon-id]');
    if (hit?.dataset?.addonId) setAddonDragOverId(hit.dataset.addonId);
  };

  const endAddonPointerMove = async (kind, event) => {
    if (addonPointerTimerRef.current) { window.clearTimeout(addonPointerTimerRef.current); addonPointerTimerRef.current = null; }
    if (!addonDraggingId) return;
    const hit = document.elementFromPoint(event.clientX, event.clientY)?.closest('[data-addon-id]');
    await commitAddonDrop(kind, addonDraggingId, hit?.dataset?.addonId || addonDragOverId);
  };

  const addonGroups = useMemo(() => {
    const all = selected?.addons || [];
    const behavior = all.filter(a => a.kind === 'behavior');
    const resource = all.filter(a => a.kind === 'resource');
    // Só transforma a lista em abas quando existe mais de um pack de algum tipo.
    // Assim, com um único BP/RP, a experiência continua compacta; com conflitos,
    // BP e RP ficam isolados para permitir a reordenação independente.
    return {
      all,
      behavior,
      resource,
      split: behavior.length > 1 || resource.length > 1,
      showBehaviorTab: behavior.length > 0,
      showResourceTab: resource.length > 0
    };
  }, [selected]);

  useEffect(() => {
    if (!addonGroups.split) return;
    if (addonKindTab === 'behavior' && addonGroups.behavior.length === 0) {
      setAddonKindTab(addonGroups.resource.length ? 'resource' : 'behavior');
    } else if (addonKindTab === 'resource' && addonGroups.resource.length === 0) {
      setAddonKindTab(addonGroups.behavior.length ? 'behavior' : 'resource');
    }
  }, [addonGroups.split, addonGroups.behavior.length, addonGroups.resource.length, addonKindTab]);

  // ---------- manutenção (validado no servidor, sem segredo no front) ----------
  const handleReinstall = async () => {
    try {
      await api.reinstall(selectedId, reinstallPin);
      showInfo('Mundo reinstalado (dados apagados, binários mantidos).');
      setReinstallPin('');
      refreshWorlds();
    } catch (err) { showError(err); }
  };
  const handleDeleteMaster = async () => {
    try {
      await api.deleteMaster(selectedId, deletePass);
      setDeletePass('');
      setSelectedId(null);
      setCurrentView('list');
      refreshWorlds();
    } catch (err) { showError(err); }
  };

  const styles = useMemo(() => ({
    container: { minHeight: '100vh', width: '100%', overflowX: 'hidden', backgroundColor: 'var(--theme-bg, #07090e)', color: 'var(--theme-text, #f8fafc)', fontFamily: 'Inter, system-ui, sans-serif', paddingBottom: '50px' },
    header: { position: 'sticky', top: 0, zIndex: 30, backgroundColor: 'color-mix(in srgb, var(--theme-surface, #0f172a) 88%, transparent)', backdropFilter: 'blur(12px)', borderBottom: '1px solid var(--theme-border, #1e293b)', padding: '16px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' },
    logoArea: { display: 'flex', alignItems: 'center', gap: '14px', cursor: 'pointer' },
    logoIcon: { width: '42px', height: '42px', borderRadius: '14px', background: 'linear-gradient(135deg, var(--panel-accent), #059669)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px' },
    navButtons: { display: 'flex', gap: '8px', background: '#1e293b', padding: '6px', borderRadius: '16px', border: '1px solid var(--theme-border, #334155)' },
    btnNav: (active) => ({ padding: '8px 18px', borderRadius: '12px', fontSize: '12px', fontWeight: '700', border: 'none', cursor: 'pointer', background: active ? 'var(--panel-accent)' : 'transparent', color: active ? '#020617' : '#94a3b8' }),
    main: { width: '100%', maxWidth: '1160px', margin: '28px auto', padding: '0 22px' },
    card: { backgroundColor: 'var(--theme-card, #1e293b)', border: '1px solid var(--theme-border, #334155)', borderRadius: '24px', padding: '28px', marginBottom: '24px', boxShadow: '0 12px 30px -10px rgba(0,0,0,0.5)' },
    grid: { width: '100%', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px', alignItems: 'stretch' },
    axentCard: { minWidth: 0, backgroundColor: 'var(--theme-panel, #161e2e)', border: '1px solid var(--theme-border, #2a374a)', borderRadius: '20px', overflow: 'hidden', display: 'flex', flexDirection: 'column', boxShadow: '0 10px 25px rgba(0,0,0,0.3)' },
    axentBanner: { minWidth: 0, height: '90px', background: 'linear-gradient(135deg, rgba(16,185,129,0.15), rgba(15,23,42,0.9))', padding: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' },
    axentBody: { padding: '18px', display: 'flex', flexDirection: 'column', gap: '14px', flex: 1 },
    axentInfoGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' },
    axentInfoBox: { minWidth: 0, background: 'var(--theme-panel, #101726)', border: '1px solid var(--theme-border, #232f42)', borderRadius: '12px', padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: '2px' },
    button: { backgroundColor: 'var(--panel-accent)', color: '#020617', border: 'none', padding: '12px 20px', borderRadius: '14px', fontWeight: '800', fontSize: '12px', cursor: 'pointer', textTransform: 'uppercase', letterSpacing: '0.5px' },
    input: { width: '100%', minWidth: 0, backgroundColor: 'var(--theme-panel, #101726)', border: '1px solid var(--theme-border, #334155)', borderRadius: '14px', padding: '14px', color: 'var(--theme-text)', fontSize: '12px', outline: 'none', boxSizing: 'border-box' },
    select: { width: '100%', minWidth: 0, backgroundColor: 'var(--theme-panel, #101726)', border: '1px solid var(--theme-border, #334155)', borderRadius: '14px', padding: '14px', color: 'var(--theme-text)', fontSize: '12px', outline: 'none', boxSizing: 'border-box' },
    label: { fontSize: '11px', fontWeight: '700', display: 'block', marginBottom: '6px', color: 'var(--theme-text, #cbd5e1)', textTransform: 'uppercase' },
    tabs: { display: 'flex', gap: '10px', borderBottom: '1px solid #334155', paddingBottom: '16px', marginBottom: '24px', overflowX: 'auto' },
    tabBtn: (active) => ({ padding: '10px 18px', borderRadius: '14px', fontSize: '12px', fontWeight: '700', border: '1px solid var(--theme-border, #334155)', cursor: 'pointer', background: active ? 'var(--theme-surface, #0f172a)' : 'var(--theme-card, #1e293b)', color: active ? 'var(--panel-accent, var(--panel-accent))' : 'var(--theme-muted, #94a3b8)', whiteSpace: 'nowrap' }),
    iosBackButton: { display: 'inline-flex', alignItems: 'center', gap: '6px', backgroundColor: 'var(--theme-surface, #0f172a)', color: '#38bdf8', border: '1px solid var(--theme-border, #334155)', padding: '8px 16px', borderRadius: '12px', fontSize: '12px', fontWeight: '700', cursor: 'pointer' },
    actionBtn: (bg, fg) => ({ backgroundColor: bg, color: fg, border: 'none', padding: '10px 16px', borderRadius: '12px', fontWeight: '800', fontSize: '11px', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '6px' }),
    iconBtn: (bg, fg, size) => ({ backgroundColor: bg, color: fg, border: 'none', width: size || '42px', height: size || '42px', borderRadius: '50%', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 4px 14px -2px ${bg}66` }),
    sectionCard: { background: 'var(--theme-surface, #0f172a)', padding: '22px', borderRadius: '16px', border: '1px solid var(--theme-border, #334155)' },
    sectionTitle: { margin: '0 0 4px 0', fontSize: '13px', fontWeight: '800', color: 'var(--theme-subtle)', textTransform: 'uppercase' }
  }), []);

  return (
    <>
      {initialReveal && (
        <div className="initial-reveal" aria-label="Carregando painel">
          <div className="initial-reveal-orb orb-a" />
          <div className="initial-reveal-orb orb-b" />
          <div className="initial-reveal-orb orb-c" />
          <div className="initial-reveal-glow" />
          <div className="initial-reveal-content">
            <div className="initial-reveal-logo"><IconServer width="26" height="26" /></div>
            <div className="initial-reveal-title">Bedrock Xubuntu</div>
            <div className="initial-reveal-subtitle">Preparando seus servidores</div>
            <div className="initial-reveal-progress"><span /></div>
          </div>
        </div>
      )}
      <div style={styles.container} className={initialReveal ? 'panel-under-reveal' : ''}>
      <header style={styles.header} className="app-header">
        <div style={styles.logoArea} onClick={() => setCurrentView('list')}>
          <div style={styles.logoIcon} className="float-logo">▦</div>
          <div>
            <h1 style={{ margin: 0, fontSize: '15px', fontWeight: '800', color: 'var(--theme-text)' }}>
              Bedrock Xubuntu <span style={{ fontSize: '10px', background: 'rgba(52, 211, 153, 0.1)', color: 'var(--panel-accent)', padding: '2px 8px', borderRadius: '6px' }}>Painel Real</span>
            </h1>
            <p style={{ margin: 0, fontSize: '11px', color: 'var(--theme-muted)' }}>
              {serverStatus
                ? (serverStatus.bdsBinaryAvailable
                  ? `Binário BDS ok • IP local ${serverStatus.localIp}`
                  : `⚠️ bedrock_server não encontrado em ${serverStatus.bdsBinDir}`)
                : 'Conectando ao backend...'}
            </p>
          </div>
        </div>

        {batteryInfo && (
          <div className="battery-indicator" title={batteryInfo.charging ? 'Conectado ao carregador' : `Bateria ${batteryInfo.level}%`}>
            <span className="battery-icon" style={{ '--battery-color': batteryInfo.charging ? 'var(--panel-accent)' : batteryInfo.level <= 10 ? '#ef4444' : batteryInfo.level <= 20 ? '#f97316' : batteryInfo.level <= 50 ? '#f59e0b' : '#f8fafc' }}><span style={{ width: `${Math.max(4, batteryInfo.level)}%` }} /></span>
            <span>{batteryInfo.level}%</span>
          </div>
        )}
        <div style={styles.navButtons} className="nav-buttons desktop-nav">
          <button style={styles.btnNav(currentView === 'list' || currentView === 'dashboard')} onClick={() => setCurrentView('list')} className="btn-anim">Mundos</button>
          <button style={styles.btnNav(currentView === 'create')} onClick={() => setCurrentView('create')} disabled={worlds.length >= maxWorlds} className="btn-anim">+ Criar Mundo</button>
          <button
            onClick={() => setCurrentView('settings')}
            className="btn-anim"
            style={{ background: 'transparent', border: 'none', color: 'var(--theme-muted)', cursor: 'pointer', padding: '8px 10px', borderRadius: '12px', display: 'flex', alignItems: 'center' }}
            title="Configurar IP de rede"
          >
            <IconSettings />
          </button>
        </div>

        <div className="mobile-header-actions">
          {batteryInfo && <div className="battery-indicator mobile-battery" title={batteryInfo.charging ? 'Conectado ao carregador' : `Bateria ${batteryInfo.level}%`}>
            <span className="battery-icon" style={{ '--battery-color': batteryInfo.charging ? 'var(--panel-accent)' : batteryInfo.level <= 10 ? '#ef4444' : batteryInfo.level <= 20 ? '#f97316' : batteryInfo.level <= 50 ? '#f59e0b' : '#f8fafc' }}><span style={{ width: `${Math.max(4, batteryInfo.level)}%` }} /></span>
            <span>{batteryInfo.level}%</span>
          </div>}
          <button
            className="mobile-header-btn btn-anim"
            onClick={() => setCurrentView('settings')}
            title="Configurar IP de rede"
            aria-label="Configurar IP de rede"
          >
            <IconSettings width="18" height="18" />
          </button>
          {currentView === 'dashboard' && (
            <button
              className="mobile-header-btn mobile-menu-btn btn-anim"
              onClick={() => setMobileNavOpen(true)}
              title="Abrir menu"
              aria-label="Abrir menu"
            >
              <IconMenu width="20" height="20" />
            </button>
          )}
        </div>
      </header>

      <main style={styles.main} className="app-main" aria-live="polite">
        {currentView === 'settings' && (
          <div className="settings-page axent-settings-page fade-in">
            <div className="settings-topbar">
              <div className="settings-title-wrap">
                <button className="settings-menu-button btn-anim" onClick={() => setCurrentView(selected ? 'dashboard' : 'list')} aria-label="Voltar"><IconBack width="17" height="17" /></button>
                <div>
                  <div className="settings-kicker">Painel</div>
                  <h2>Configurações</h2>
                </div>
              </div>
              <span className={`settings-status-dot ${appearanceSaved ? 'is-saved' : 'is-dirty'}`} title={appearanceSaved ? 'Tudo salvo' : 'Existem alterações não salvas'} style={{ '--settings-status': appearanceSaved ? (accent.toLowerCase() === '#ef4444' ? '#10b981' : accent) : '#ef4444' }} />
            </div>

            <div className="axent-settings-grid">
              <section className="axent-setting-card">
                <div className="axent-setting-head"><div><div className="axent-setting-title"><span className="setting-led"/>Tema</div><p>Escolha a aparência do painel.</p></div><span className={`config-save-dot ${appearanceSaved ? 'is-saved' : 'is-dirty'}`} title={appearanceSaved ? 'Salvo' : 'Alterações não salvas'} /></div>
                <div className="theme-options settings-control">
                  {[['light','Claro','Interface clara e limpa'],['dark','Escuro','Equilíbrio entre profundidade e contraste'],['darkness','Escuridão','Preto profundo com detalhes preservados']].map(([id,label,desc]) => (
                    <button key={id} className={`theme-choice ${theme === id ? 'selected' : ''}`} onClick={() => { setTheme(id); setAppearanceSaved(false); }}>
                      <span className={`theme-swatch theme-${id}`} />
                      <span><strong>{label}</strong><small>{desc}</small></span>
                    </button>
                  ))}
                </div>
              </section>

              <section className="axent-setting-card">
                <div className="axent-setting-head"><div><div className="axent-setting-title"><span className="setting-led"/>Cor de destaque</div><p>Usada em botões, indicadores e navegação.</p></div><span className={`config-save-dot ${appearanceSaved ? 'is-saved' : 'is-dirty'}`} title={appearanceSaved ? 'Salvo' : 'Alterações não salvas'} /></div>
                <div className="accent-grid settings-control">
                  {ACCENTS.map(([label,color]) => (
                    <button key={color} aria-label={label} title={label} className={`accent-choice ${accent === color ? 'selected' : ''}`} onClick={() => { setAccent(color); setAppearanceSaved(false); }} style={{ '--swatch': color }}>
                      <span />
                      <small>{label}</small>
                    </button>
                  ))}
                </div>
                <div className="setting-card-footer"><span>Cor atual: <strong style={{color:'var(--panel-accent)'}}>{ACCENTS.find(([,c])=>c===accent)?.[0] || accent}</strong></span><button className="settings-save btn-anim" onClick={handleSaveAppearance}>Salvar</button></div>
              </section>

              <section className="axent-setting-card axent-setting-wide">
                <div className="axent-setting-head"><div><div className="axent-setting-title"><span className="setting-led"/>IP de conexão</div><p>O endereço usado pelo painel para os servidores. Alterar exige a senha mestre.</p></div><span className={`config-save-dot ${networkDirty ? 'is-dirty' : 'is-saved'}`} title={networkDirty ? 'Alterações não salvas' : 'Salvo'} /></div>
                <div className="settings-field-grid">
                  <label><span>Endereço</span><input className="settings-input" placeholder="192.168.1.10" value={networkIpInput} onChange={e => setNetworkIpInput(e.target.value)} /></label>
                  <label><span>Senha mestre</span><input className="settings-input" type="password" placeholder="Senha mestre" value={settingsPassword} onChange={e => setSettingsPassword(e.target.value)} /></label>
                </div>
                <div className="setting-card-footer"><span>Atual: <strong>{serverStatus?.effectiveIp || 'detectando...'}</strong></span><button className="settings-save btn-anim" onClick={handleSaveNetworkIp} disabled={!settingsPassword}>Salvar IP</button></div>
              </section>
            </div>
          </div>
        )}
        {banner && (
          <div className={`panel-toast ${banner.type === 'error' ? 'is-error' : 'is-info'}`} role="status" aria-live="polite">
            <span>{banner.text}</span>
            <button onClick={() => setBanner(null)} aria-label="Fechar notificação"><IconClose width="14" height="14" /></button>
          </div>
        )}

        {currentView === 'list' && (
          <div>
            <div style={{ ...styles.card, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }} className="app-card fade-in">
              <div>
                <h2 style={{ margin: '0 0 6px 0', fontSize: '18px', fontWeight: '800', color: 'var(--theme-text)' }}>Gerenciador de Mundos</h2>
                <p style={{ margin: 0, fontSize: '12px', color: 'var(--theme-muted)' }}>
                  {worlds.length} de {maxWorlds} mundos usados • pool total: {poolInfo.totalUsedLabel} / {poolInfo.totalPoolLabel}
                </p>
              </div>
              <button style={{ ...styles.button, opacity: worlds.length >= maxWorlds ? 0.5 : 1 }} onClick={() => setCurrentView('create')} disabled={worlds.length >= maxWorlds}>
                + Criar Mundo
              </button>
            </div>

            {worlds.length >= maxWorlds && (
              <div style={{ ...styles.card, background: 'rgba(251,191,36,0.08)', border: '1px solid rgba(251,191,36,0.3)', color: '#fbbf24', fontSize: '12px' }}>
                Limite de {maxWorlds} mundos atingido. Apague um mundo pra criar outro.
              </div>
            )}

            {worlds.length === 0 ? (
              <div style={{ ...styles.card, textAlign: 'center', padding: '40px', color: 'var(--theme-dim)' }}>
                <p style={{ margin: 0, fontSize: '13px' }}>Nenhum mundo criado ainda. Clique em "+ Criar Mundo" para começar.</p>
              </div>
            ) : (
              <div style={styles.grid} className="world-grid">
                {worlds.map((w) => (
                  <div key={w.id} style={styles.axentCard} className="world-card fade-in">
                    <div style={styles.axentBanner} onClick={() => { setSelectedId(w.id); setCurrentView('dashboard'); setActiveTab('server'); }}>
                      <div style={{ cursor: 'pointer' }}>
                        <h3 style={{ margin: 0, fontSize: '15px', fontWeight: '800', color: 'var(--theme-text)' }}>{w.name}</h3>
                        <span style={{ fontSize: '10px', color: 'var(--theme-muted)' }}>Porta {displayPort(w.port)}{w.hasPendingExperiments ? ' • experiments pendentes' : ''}{w.ramCacheActive ? ' • ⚡ RAM' : ''}</span>
                        <span style={{ marginTop:'3px', display:'flex', alignItems:'center', gap:'6px', fontSize:'10px', color:'var(--theme-dim)', fontFamily:'monospace' }}>
                          {getConnectionInfo(w.port).host}:{getConnectionInfo(w.port).port}
                          <button type="button" className="connection-copy compact btn-anim" style={{ padding:'2px 6px', minHeight:'22px' }} onClick={(e) => { e.stopPropagation(); navigator.clipboard?.writeText(`${getConnectionInfo(w.port).host}:${getConnectionInfo(w.port).port}`).then(() => showInfo('Endereço copiado.')).catch(()=>{}); }} aria-label="Copiar endereço do servidor">
                            <IconCopy width="12" height="12" />
                          </button>
                        </span>
                      </div>
                      <span style={{ background: STATUS_COLORS[w.status] || '#334155', color: w.status === 'Online' ? '#020617' : '#fff', fontSize: '10px', fontWeight: 'bold', padding: '4px 10px', borderRadius: '8px' }} className={w.status === 'Online' ? 'btn-online-pulse' : ''}>
                        {w.status}
                      </span>
                    </div>

                    <div style={styles.axentBody}>
                      <div style={styles.axentInfoGrid}>
                        <div style={styles.axentInfoBox}>
                          <span style={{ fontSize: '9px', color: 'var(--theme-muted)', textTransform: 'uppercase', fontWeight: '700' }}>Disco</span>
                          <span style={{ fontSize: '12px', fontWeight: 'bold', color: 'var(--theme-text)' }}>{w.diskUsedLabel} / {w.diskQuotaLabel}</span>
                        </div>
                        <div style={styles.axentInfoBox}>
                          <span style={{ fontSize: '9px', color: 'var(--theme-muted)', textTransform: 'uppercase', fontWeight: '700' }}>Add-ons</span>
                          <span style={{ fontSize: '12px', fontWeight: 'bold', color: 'var(--theme-text)' }}>{w.addons.length}</span>
                        </div>
                      </div>
                      <div style={{ height: '6px', background: '#0f172a', borderRadius: '4px', overflow: 'hidden' }}>
                        <div style={{ height: '100%', width: `${w.diskPercent}%`, background: w.diskPercent > 90 ? '#f43f5e' : 'var(--panel-accent)' }} />
                      </div>

                      <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }} className="world-card-actions">
                        <button title="Ligar" onClick={() => handleStart(w.id)} disabled={w.status !== 'Offline'} style={{ ...styles.iconBtn('var(--panel-accent)', '#020617'), opacity: w.status !== 'Offline' ? 0.35 : 1 }} className="btn-anim">
                          <IconPlay />
                        </button>
                        <button title="Parar" onClick={() => handleStop(w.id)} disabled={w.status !== 'Online'} style={{ ...styles.iconBtn('#ef4444', '#fff'), opacity: w.status !== 'Online' ? 0.35 : 1 }} className="btn-anim">
                          <IconStop />
                        </button>
                        <button title="Reiniciar" onClick={() => handleRestart(w.id)} disabled={w.status !== 'Online'} style={{ ...styles.iconBtn('#f59e0b', '#020617'), opacity: w.status !== 'Online' ? 0.35 : 1 }} className="btn-anim">
                          <IconRestart />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {currentView === 'create' && (
          <div style={{ ...styles.card, maxWidth: '520px', margin: '0 auto' }} className="app-card fade-in">
            <h2 style={{ margin: '0 0 6px 0', fontSize: '18px', fontWeight: '800' }}>Criar Novo Mundo</h2>
            <p style={{ margin: '0 0 24px 0', fontSize: '12px', color: 'var(--theme-muted)' }}>
              Pool de {poolInfo.totalPoolLabel} dividido entre até {maxWorlds} mundos — cada mundo tem limite fixo de 10GB (40GB no total).
            </p>
            <form onSubmit={handleCreateServer} style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
              <div>
                <label style={styles.label}>Nome do Mundo</label>
                <input type="text" placeholder="Ex: Survival Principal" value={newName} onChange={e => setNewName(e.target.value)} style={styles.input} />
              </div>
              <div>
                <label style={styles.label}>Descrição (opcional)</label>
                <input type="text" placeholder="Ex: Mundo da família, só amigos" value={newDescription} onChange={e => setNewDescription(e.target.value)} style={styles.input} />
              </div>
              <div>
                <label style={styles.label}>Seed (opcional)</label>
                <input type="text" placeholder="Deixe em branco para seed aleatória" value={newSeed} onChange={e => setNewSeed(e.target.value)} style={styles.input} />
              </div>
              <div>
                <label style={styles.label}>Porta</label>
                <select value={newPort} onChange={e => setNewPort(e.target.value)} style={styles.input}>
                  <option value="">Automática (próxima disponível)</option>
                  {[19132, 19133, 19134, 19135].map(port => (
                    <option key={port} value={port} disabled={worlds.some(w => Number(w.port) === port)}>
                      {displayPort(port)}
                    </option>
                  ))}
                </select>
                <p style={{ margin: '6px 0 0 0', fontSize: '10px', color: 'var(--theme-dim)' }}>
                  Portas internas permitidas: 19132–19135. No painel/conexão, elas aparecem como 42567, 42576, 42579 e 42822.
                </p>
              </div>
              <div>
                <label style={styles.label}>Software</label>
                {versionsInfo && versionsInfo.versions.length === 0 ? (
                  <p style={{ margin: 0, fontSize: '11px', color: '#fbbf24' }}>
                    ⚠ Nenhuma versão do Bedrock Dedicated Server encontrada em "{versionsInfo.binDir}". Extraia uma versão (ex: "{versionsInfo.binDir}/1.26.40") antes de criar o mundo.
                  </p>
                ) : (
                  <>
                    <select value={newVersion} onChange={e => setNewVersion(e.target.value)} style={styles.input}>
                      <option value="latest">Mais recente {versionsInfo?.latest ? `(${versionsInfo.latest})` : ''}</option>
                      {versionsInfo?.versions.map(v => (
                        <option key={v} value={v}>{v}</option>
                      ))}
                    </select>
                    <p style={{ margin: '6px 0 0 0', fontSize: '10px', color: 'var(--theme-dim)' }}>
                      Bedrock Dedicated Server. "Mais recente" sempre aponta pra maior versão disponível em "{versionsInfo?.binDir}".
                    </p>
                  </>
                )}
              </div>
              <div style={{ padding: '12px 14px', borderRadius: '12px', background: 'rgba(148,163,184,.05)', border: '1px solid #1e293b' }}>
                <div style={{ fontSize: '11px', color: 'var(--theme-muted)', lineHeight: 1.55 }}>Experimentos aparecem na aba <strong style={{ color: '#d1fae5' }}>Experimentos</strong> somente depois que o mundo for gerado.</div>
              </div>
                            <div style={{ display: 'flex', gap: '12px', marginTop: '12px' }}>
                <button type="button" onClick={() => setCurrentView('list')} style={{ ...styles.button, background: '#334155', color: 'var(--theme-text)', flex: 1 }}>Cancelar</button>
                <button type="submit" disabled={creating || !versionsInfo?.latest} style={{ ...styles.button, flex: 2, opacity: (creating || !versionsInfo?.latest) ? 0.6 : 1 }}>{creating ? 'Criando...' : 'Criar Mundo'}</button>
              </div>
            </form>
          </div>
        )}

        {currentView === 'dashboard' && selected && (
          <div>
            <div style={{ ...styles.card, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }} className="app-card fade-in dashboard-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                <button style={styles.iosBackButton} onClick={() => setCurrentView('list')}><IconBack /> Voltar</button>
                <div>
                  <span style={{ fontSize: '10px', color: 'var(--panel-accent)', fontWeight: '800', textTransform: 'uppercase' }}>
                    /server/instances/{selected.folderName} • {selected.diskUsedLabel} / {selected.diskQuotaLabel}
                  </span>
                  <h2 style={{ margin: 0, fontSize: '18px', fontWeight: '800', color: 'var(--theme-text)' }}>{selected.name}</h2>
                  {selected.status === 'Online' && serverStatus && (
                    <span style={{ fontSize: '11px', color: '#38bdf8', fontFamily: 'monospace' }}>
                      Conectar em: {getConnectionInfo(selected.port).host}:{getConnectionInfo(selected.port).port}
                    </span>
                  )}
                </div>
              </div>

              <div style={{ display: 'flex', gap: '14px', alignItems: 'center' }} className="dashboard-actions dashboard-icon-actions">
                <button title="Ligar" onClick={() => handleStart(selected.id)} disabled={selected.status !== 'Offline'} style={{ ...styles.iconBtn('var(--panel-accent)', '#020617', '48px'), opacity: selected.status !== 'Offline' ? 0.35 : 1 }} className="btn-anim">
                  <IconPlay width="18" height="18" />
                </button>
                <button title="Parar" onClick={() => handleStop(selected.id)} disabled={selected.status !== 'Online'} style={{ ...styles.iconBtn('#ef4444', '#fff', '48px'), opacity: selected.status !== 'Online' ? 0.35 : 1 }} className="btn-anim">
                  <IconStop width="18" height="18" />
                </button>
                <button title="Parar à força" onClick={() => setForceStopConfirming(true)} disabled={!['Online','Iniciando','Parando'].includes(selected.status)} style={{ ...styles.iconBtn('#7f1d1d', '#fff', '48px'), opacity: !['Online','Iniciando','Parando'].includes(selected.status) ? 0.35 : 1 }} className="btn-anim emergency-btn">
                  <IconBolt width="18" height="18" />
                </button>
                <button title="Reiniciar" onClick={() => handleRestart(selected.id)} disabled={selected.status !== 'Online'} style={{ ...styles.iconBtn('#f59e0b', '#020617', '48px'), opacity: selected.status !== 'Online' ? 0.35 : 1 }} className="btn-anim">
                  <IconRestart width="18" height="18" />
                </button>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '20px', alignItems: 'flex-start' }} className="dashboard-layout">
              <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} mobileOpen={mobileNavOpen} setMobileOpen={setMobileNavOpen} showExperiments={!!selected?.generated} />

              <div className={`dashboard-content tab-page-shell ${activeTab}-tab`} key={activeTab}>

              {activeTab === 'server' && properties && (
                <div style={{ display:'flex', flexDirection:'column', gap:'20px' }}>
                  <div style={{ ...styles.sectionCard, background:'#111827', borderColor:selected.status === 'Online' ? 'rgba(23,184,20,.45)' : '#334155' }}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', gap:'18px', flexWrap:'wrap' }}>
                      <div>
                        <div style={{ fontSize:'10px', color:'var(--theme-muted)', textTransform:'uppercase', fontWeight:'800', letterSpacing:'.12em' }}>Status do servidor</div>
                        <div style={{ marginTop:'4px', display:'flex', alignItems:'center', gap:'8px', fontSize:'20px', fontWeight:'900' }}>
                          <span style={{ width:'9px', height:'9px', borderRadius:'50%', background:selected.status === 'Online' ? 'var(--panel-accent)' : selected.status === 'Iniciando' || selected.status === 'Parando' ? '#f59e0b' : '#64748b', boxShadow:selected.status === 'Online' ? '0 0 0 5px rgba(23,184,20,.12)' : 'none' }} />
                          {selected.status}
                        </div>
                        <div style={{ marginTop:'6px', fontSize:'11px', color:'var(--theme-muted)', fontFamily:'monospace' }}>{getConnectionInfo(selected.port).host}:{getConnectionInfo(selected.port).port}</div>
                      </div>
                      <div style={{ display:'flex', gap:'8px' }} className="server-action-buttons">
                        <button onClick={() => handleStart(selected.id)} disabled={selected.status !== 'Offline'} style={{ ...styles.button, background:'var(--panel-accent)', color:'#061006', opacity:selected.status !== 'Offline' ? .45 : 1 }} className="btn-anim">Ligar</button>
                        <button onClick={() => handleStop(selected.id)} disabled={selected.status !== 'Online'} style={{ ...styles.button, background:'#ef4444', color:'var(--theme-text)', opacity:selected.status !== 'Online' ? .45 : 1 }} className="btn-anim">Parar</button>
                        <button onClick={() => setForceStopConfirming(true)} disabled={!['Online','Iniciando','Parando'].includes(selected.status)} style={{ ...styles.button, background:'#7f1d1d', color:'var(--theme-text)', opacity:!['Online','Iniciando','Parando'].includes(selected.status) ? .45 : 1 }} className="btn-anim"><IconBolt width="14" height="14" /> Parar à força</button>
                        <button onClick={() => handleRestart(selected.id)} disabled={selected.status !== 'Online'} style={{ ...styles.button, background:'#f59e0b', color:'#111827', opacity:selected.status !== 'Online' ? .45 : 1 }} className="btn-anim">Reiniciar</button>
                      </div>
                    </div>
                  </div>
                  <div style={{ ...styles.sectionCard, display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))', gap:'10px' }}>
                    <div style={styles.axentInfoBox}><span style={{ fontSize:'9px', color:'var(--theme-muted)', textTransform:'uppercase' }}>Jogadores</span><strong style={{ fontSize:'18px' }}>{selected.status === 'Online' && players ? `${players.online}/${players.max}` : '—'}</strong></div>
                    <div style={styles.axentInfoBox}><span style={{ fontSize:'9px', color:'var(--theme-muted)', textTransform:'uppercase' }}>Armazenamento</span><strong style={{ fontSize:'18px' }}>{selected.diskUsedLabel}</strong><span style={{ fontSize:'10px', color:'var(--theme-dim)' }}>de {selected.diskQuotaLabel}</span></div>
                    <div style={styles.axentInfoBox}><span style={{ fontSize:'9px', color:'var(--theme-muted)', textTransform:'uppercase' }}>Software</span><strong style={{ fontSize:'13px' }}>Bedrock Vanilla</strong></div>
                    <div style={styles.axentInfoBox}><span style={{ fontSize:'9px', color:'var(--theme-muted)', textTransform:'uppercase' }}>Mundo gerado</span><strong style={{ fontSize:'13px', color:selected.generated ? 'var(--panel-accent)' : '#fbbf24' }}>{selected.generated ? 'Sim' : 'Ainda não'}</strong></div>
                  </div>
                  <div style={styles.sectionCard} className="connection-section">
                    <h3 style={styles.sectionTitle}>Conexão</h3>
                    <p style={{ margin:'5px 0 14px', fontSize:'11px', color:'var(--theme-muted)' }}>Use o endereço com letras como principal. O IP numérico também é mostrado como alternativa. A porta pode ser copiada separadamente.</p>
                    <div className="connection-grid">
                      <div className="connection-card">
                        <div className="connection-card-label">ENDEREÇO DO SERVIDOR</div>
                        <div className="connection-card-value">{getConnectionInfo(selected.port).host}</div>
                        <button className="connection-copy btn-anim" onClick={() => navigator.clipboard?.writeText(getConnectionInfo(selected.port).host).then(() => showInfo('Endereço copiado.')).catch(()=>{})} aria-label="Copiar endereço do servidor">
                          <IconCopy width="14" height="14" /> Copiar endereço
                        </button>
                      </div>
                      <div className="connection-card">
                        <div className="connection-card-label">PORTA PÚBLICA</div>
                        <div className="connection-card-value">{getConnectionInfo(selected.port).port}</div>
                        <button className="connection-copy btn-anim" onClick={() => navigator.clipboard?.writeText(String(getConnectionInfo(selected.port).port)).then(() => showInfo('Porta copiada.')).catch(()=>{})} aria-label="Copiar porta">
                          <IconCopy width="14" height="14" /> Copiar porta
                        </button>
                      </div>
                      <div className="connection-card">
                        <div className="connection-card-label">IP NUMÉRICO</div>
                        <div className="connection-card-value">{getConnectionInfo(selected.port).ip}</div>
                        <button className="connection-copy btn-anim" onClick={() => navigator.clipboard?.writeText(getConnectionInfo(selected.port).ip).then(() => showInfo('IP numérico copiado.')).catch(()=>{})} aria-label="Copiar IP numérico">
                          <IconCopy width="14" height="14" /> Copiar IP
                        </button>
                      </div>
                    </div>
                    <div className="connection-full-address">
                      <span><strong>Endereço completo</strong> <code>{getConnectionInfo(selected.port).host}:{getConnectionInfo(selected.port).port}</code></span>
                      <button className="connection-copy compact btn-anim" onClick={() => navigator.clipboard?.writeText(`${getConnectionInfo(selected.port).host}:${getConnectionInfo(selected.port).port}`).then(() => showInfo('Endereço completo copiado.')).catch(()=>{})} aria-label="Copiar endereço completo">
                        <IconCopy width="14" height="14" /> Copiar tudo
                      </button>
                    </div>
                    <div className="connection-full-address" style={{ marginTop:'8px' }}>
                      <span><strong>IP numérico + porta</strong> <code>{getConnectionInfo(selected.port).ip}:{getConnectionInfo(selected.port).port}</code></span>
                      <button className="connection-copy compact btn-anim" onClick={() => navigator.clipboard?.writeText(`${getConnectionInfo(selected.port).ip}:${getConnectionInfo(selected.port).port}`).then(() => showInfo('IP numérico completo copiado.')).catch(()=>{})} aria-label="Copiar IP numérico completo">
                        <IconCopy width="14" height="14" /> Copiar tudo
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'options' && properties && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                  <div style={{ ...styles.sectionCard, display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '14px' }} className="props-grid">
                    <div style={styles.axentInfoBox}>
                      <span style={{ fontSize: '9px', color: 'var(--theme-muted)', textTransform: 'uppercase', fontWeight: '700' }}>Jogadores Online</span>
                      <span style={{ fontSize: '16px', fontWeight: 'bold', color: 'var(--theme-text)' }}>
                        {selected.status !== 'Online' ? '— (offline)' : players ? `${players.online} / ${players.max}` : 'consultando...'}
                      </span>
                      {players?.names?.length > 0 && <span style={{ fontSize: '10px', color: 'var(--theme-dim)' }}>{players.names.join(', ')}</span>}
                    </div>
                    <div style={styles.axentInfoBox}>
                      <span style={{ fontSize: '9px', color: 'var(--theme-muted)', textTransform: 'uppercase', fontWeight: '700' }}>Gamemode Padrão</span>
                      <span style={{ fontSize: '16px', fontWeight: 'bold', color: 'var(--theme-text)', textTransform: 'capitalize' }}>{properties['gamemode']}</span>
                    </div>
                    <div style={styles.axentInfoBox}>
                      <span style={{ fontSize: '9px', color: 'var(--theme-muted)', textTransform: 'uppercase', fontWeight: '700' }}>Porta</span>
                      <span style={{ fontSize: '16px', fontWeight: 'bold', color: 'var(--theme-text)' }}>{displayPort(selected.port)}</span>
                    </div>
                    <div style={styles.axentInfoBox}>
                      <span style={{ fontSize: '9px', color: 'var(--theme-muted)', textTransform: 'uppercase', fontWeight: '700' }}>Dificuldade</span>
                      <span style={{ fontSize: '16px', fontWeight: 'bold', color: 'var(--theme-text)', textTransform: 'capitalize' }}>{properties['difficulty']}</span>
                    </div>
                  </div>

                  <div style={styles.sectionCard} className="axent-reference-config-card">
                    <div className="axent-reference-config-head">
                      <div>
                        <h3 style={styles.sectionTitle}>Configurações do Mundo</h3>
                        <p style={{ margin: '6px 0 16px 0', fontSize: '11px', color: 'var(--theme-muted)' }}>Editor simplificado de server.properties. Aplica após reiniciar.</p>
                      </div>
                      <span className={`config-save-dot ${propertiesDirty ? 'is-dirty' : 'is-saved'}`} title={propertiesDirty ? 'Alterações não salvas' : 'Configurações salvas'} />
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }} className="props-grid ax-options-form-grid">
                      <div className="ax-option-field">
                        <label style={styles.label}>Nome do Servidor (MOTD)</label>
                        <small className="ax-option-description">Nome exibido aos jogadores na lista do servidor.</small>
                        <input style={styles.input} value={properties['server-name'] || ''} onChange={e => updateProp('server-name', e.target.value)} />
                      </div>
                      <div className="ax-option-field">
                        <label style={styles.label}>Nome do Mundo (pasta)</label>
                        <small className="ax-option-description">Pasta interna do mundo; usada pelo Bedrock Dedicated Server.</small>
                        <input style={{ ...styles.input, opacity: 0.6 }} value={properties['level-name'] || ''} disabled />
                      </div>
                      <div className="ax-option-field">
                        <label style={styles.label}>Descrição</label>
                        <small className="ax-option-description">Texto descritivo usado pelo painel para identificar este mundo.</small>
                        <input style={styles.input} value={properties['_panel-description'] || ''} onChange={e => updateProp('_panel-description', e.target.value)} />
                      </div>
                      <div className="ax-option-field">
                        <label style={styles.label}>Modo de Jogo</label>
                        <small className="ax-option-description">Modo padrão aplicado aos jogadores que entram no mundo.</small>
                        <select style={styles.select} value={properties['gamemode'] || 'survival'} onChange={e => updateProp('gamemode', e.target.value)}>
                          <option value="survival">Survival</option>
                          <option value="creative">Creative</option>
                          <option value="adventure">Adventure</option>
                        </select>
                      </div>
                      <div className="ax-option-field">
                        <label style={styles.label}>Dificuldade</label>
                        <small className="ax-option-description">Define o nível de dificuldade padrão do mundo.</small>
                        <select style={styles.select} value={properties['difficulty'] || 'easy'} onChange={e => updateProp('difficulty', e.target.value)}>
                          <option value="peaceful">Peaceful</option>
                          <option value="easy">Easy</option>
                          <option value="normal">Normal</option>
                          <option value="hard">Hard</option>
                        </select>
                      </div>
                      <div className="ax-option-field">
                        <label style={styles.label}>Máx. Jogadores</label>
                        <small className="ax-option-description">Quantidade máxima de jogadores conectados ao mesmo tempo.</small>
                        <input type="number" style={styles.input} value={properties['max-players'] || 10} onChange={e => updateProp('max-players', e.target.value)} />
                      </div>
                      <div style={{ gridColumn: '1 / -1' }}>
                        <PropertyRow title="Permitir Cheats / Blocos de Comando" propKey="allow-cheats">
                          <Toggle checked={properties['allow-cheats'] === 'true'} onChange={v => updateProp('allow-cheats', v ? 'true' : 'false')} />
                        </PropertyRow>
                        <PropertyRow title="Forçar Gamemode" hint="Todo jogador entra no modo padrão, ignora o modo salvo dele" propKey="force-gamemode">
                          <Toggle checked={properties['force-gamemode'] === 'true'} onChange={v => updateProp('force-gamemode', v ? 'true' : 'false')} />
                        </PropertyRow>
                      </div>
                    </div>
                    <button onClick={handleSaveProperties} disabled={propsSaving} style={{ ...styles.button, marginTop: '18px' }} className="btn-anim">
                      {propsSaving ? 'Salvando...' : 'Salvar Configurações'}
                    </button>
                  </div>

                  <div style={styles.sectionCard}>
                    <h3 style={styles.sectionTitle}>Cache em RAM</h3>
                    <p style={{ margin: '0 0 16px 0', fontSize: '11px', color: 'var(--theme-muted)' }}>
                      Roda o mundo direto na memória RAM enquanto o servidor tá ligado — sincroniza pro disco a cada 15 minutos e sempre que desliga. Reduz o desgaste de escrita no armazenamento.
                      {!ramStatus?.available && <span style={{ color: '#fbbf24' }}> /dev/shm não disponível nesse sistema, recurso desativado.</span>}
                    </p>
                    <PropertyRow title="Ativar Cache em RAM" hint={selected.status !== 'Offline' ? 'Pare o servidor pra mudar isso' : `RAM livre no sistema: ${ramStatus ? (ramStatus.availableRamBytes / 1024 / 1024 / 1024).toFixed(1) + ' GB' : '...'}`}>
                      <Toggle
                        checked={selected.ramCacheEnabled}
                        disabled={selected.status !== 'Offline' || !ramStatus?.available}
                        onChange={handleToggleRamCache}
                      />
                    </PropertyRow>
                    {selected.ramCacheActive && (
                      <div style={{ marginTop: '10px', display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <span style={{ fontSize: '10px', color: 'var(--panel-accent)', fontWeight: '700' }}>● Rodando na RAM agora</span>
                        <button onClick={handleRamSyncNow} style={{ ...styles.button, padding: '8px 14px', fontSize: '10px' }} className="btn-anim">
                          Sincronizar Agora
                        </button>
                      </div>
                    )}
                  </div>

                  <div style={styles.sectionCard}>
                    <h3 style={styles.sectionTitle}>Opções Avançadas</h3>
                    <p style={{ margin: '0 0 16px 0', fontSize: '11px', color: 'var(--theme-muted)' }}>O resto do server.properties, igual o painel mostra a chave real embaixo de cada opção.</p>

                    <PropertyRow title="Lista de Permissão (Allowlist)" propKey="allow-list">
                      <Toggle checked={properties['allow-list'] === 'true'} onChange={v => updateProp('allow-list', v ? 'true' : 'false')} />
                    </PropertyRow>
                    <PropertyRow title="Modo Online (verifica conta Xbox Live)" propKey="online-mode">
                      <Toggle checked={properties['online-mode'] === 'true'} onChange={v => updateProp('online-mode', v ? 'true' : 'false')} />
                    </PropertyRow>
                    <PropertyRow title="Pacote de Recursos Obrigatório" propKey="texturepack-required">
                      <Toggle checked={properties['texturepack-required'] === 'true'} onChange={v => updateProp('texturepack-required', v ? 'true' : 'false')} />
                    </PropertyRow>
                    <PropertyRow title="Quebra de Bloco Autoritativa (servidor)" propKey="server-authoritative-block-breaking">
                      <Toggle checked={properties['server-authoritative-block-breaking'] === 'true'} onChange={v => updateProp('server-authoritative-block-breaking', v ? 'true' : 'false')} />
                    </PropertyRow>
                    <PropertyRow title="Corrigir Movimento do Jogador" propKey="correct-player-movement">
                      <Toggle checked={properties['correct-player-movement'] === 'true'} onChange={v => updateProp('correct-player-movement', v ? 'true' : 'false')} />
                    </PropertyRow>
                    <PropertyRow title="Interação do Jogador" propKey="disable-player-interaction">
                      <Toggle checked={properties['disable-player-interaction'] !== 'true'} onChange={v => updateProp('disable-player-interaction', v ? 'false' : 'true')} />
                    </PropertyRow>
                    <PropertyRow title="Geração de Chunk do Lado do Cliente" propKey="client-side-chunk-generation-enabled">
                      <Toggle checked={properties['client-side-chunk-generation-enabled'] !== 'false'} onChange={v => updateProp('client-side-chunk-generation-enabled', v ? 'true' : 'false')} />
                    </PropertyRow>
                    <PropertyRow title="Log de Conteúdo (arquivo)" propKey="content-log-file-enabled">
                      <Toggle checked={properties['content-log-file-enabled'] === 'true'} onChange={v => updateProp('content-log-file-enabled', v ? 'true' : 'false')} />
                    </PropertyRow>
                    <PropertyRow title="Restrição de Bate-papo" propKey="chat-restriction">
                      <select style={{ ...styles.select, width: 'auto' }} value={properties['chat-restriction'] || 'None'} onChange={e => updateProp('chat-restriction', e.target.value)}>
                        <option value="None">Nenhum</option>
                        <option value="Dropped">Bloqueado (silencioso)</option>
                        <option value="Disabled">Desativado</option>
                      </select>
                    </PropertyRow>
                    <PropertyRow title="Permissão Padrão do Jogador" propKey="default-player-permission-level">
                      <select style={{ ...styles.select, width: 'auto' }} value={properties['default-player-permission-level'] || 'member'} onChange={e => updateProp('default-player-permission-level', e.target.value)}>
                        <option value="visitor">Visitante</option>
                        <option value="member">Membro</option>
                        <option value="operator">Operador</option>
                      </select>
                    </PropertyRow>
                    <PropertyRow title="Distância de Visualização" propKey="view-distance">
                      <input type="number" style={{ ...styles.input, width: '90px' }} value={properties['view-distance'] || 32} onChange={e => updateProp('view-distance', e.target.value)} />
                    </PropertyRow>
                    <PropertyRow title="Distância de Tick" propKey="tick-distance">
                      <input type="number" style={{ ...styles.input, width: '90px' }} value={properties['tick-distance'] || 4} onChange={e => updateProp('tick-distance', e.target.value)} />
                    </PropertyRow>
                    <PropertyRow title="Tempo Limite de Inatividade (min)" propKey="player-idle-timeout">
                      <input type="number" style={{ ...styles.input, width: '90px' }} value={properties['player-idle-timeout'] || 30} onChange={e => updateProp('player-idle-timeout', e.target.value)} />
                    </PropertyRow>

                    <button onClick={handleSaveProperties} disabled={propsSaving} style={{ ...styles.button, marginTop: '14px' }} className="btn-anim">
                      {propsSaving ? 'Salvando...' : 'Salvar Opções Avançadas'}
                    </button>
                  </div>

                </div>
              )}

              {activeTab === 'generate' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                  <div style={styles.sectionCard}>
                    <h3 style={styles.sectionTitle}>Gerar Mundo Novo</h3>
                    <p style={{ margin: '0 0 16px 0', fontSize: '11px', color: 'var(--theme-muted)' }}>
                      Cria um mundo do zero com a seed e experiments que você escolher.
                      {selected.diskUsedBytes > 0 && <strong style={{ color: '#fbbf24' }}> Já existe um mundo aqui — gerar um novo vai apagá-lo.</strong>}
                    </p>
                    <div className="props-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                      <div>
                        <label style={styles.label}>Seed (opcional)</label>
                        <input style={styles.input} placeholder="Deixe em branco para aleatória" value={genSeed} onChange={e => setGenSeed(e.target.value)} />
                      </div>
                      <div>
                        <label style={styles.label}>Experimentos a ativar</label>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginTop: '6px' }}>
                          {[
                            ['upcomingCreatorFeatures', 'Próximos Recursos do Criador'],
                            ['gametest', 'GameTest Framework'],
                            ['holidayCreatorFeatures', 'Recursos de Criador de Feriados']
                          ].map(([key, label]) => (
                            <PropertyRow key={key} title={label}>
                              <Toggle checked={genExperiments[key]} onChange={() => setGenExperiments(prev => ({ ...prev, [key]: !prev[key] }))} />
                            </PropertyRow>
                          ))}
                        </div>
                      </div>
                    </div>

                    {!genConfirming ? (
                      <button onClick={() => handleGenerateWorld(false)} disabled={genWorking} style={{ ...styles.button, marginTop: '18px', opacity: genWorking ? 0.6 : 1 }} className="btn-anim">
                        {genWorking ? 'Processando...' : 'Gerar Mundo Novo'}
                      </button>
                    ) : (
                      <div style={{ marginTop: '18px', background: 'rgba(244,63,94,0.08)', border: '1px solid rgba(244,63,94,0.35)', padding: '16px', borderRadius: '14px' }}>
                        <p style={{ margin: '0 0 12px 0', fontSize: '12px', color: '#fb7185', fontWeight: '700' }}>
                          Tem certeza? O mundo atual desse servidor será apagado PRA SEMPRE.
                        </p>
                        <div style={{ display: 'flex', gap: '10px' }}>
                          <button onClick={() => handleGenerateWorld(true)} disabled={genWorking} style={{ ...styles.button, background: '#f43f5e', color: 'var(--theme-text)' }} className="btn-anim">
                            Sim, apagar e gerar novo
                          </button>
                          <button onClick={() => setGenConfirming(false)} style={{ ...styles.button, background: '#334155', color: 'var(--theme-text)' }} className="btn-anim">
                            Cancelar
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  <div style={styles.sectionCard}>
                    <h3 style={styles.sectionTitle}>Importar Mundo (.zip)</h3>
                    <p style={{ margin: '0 0 16px 0', fontSize: '11px', color: 'var(--theme-muted)' }}>
                      Envie um .zip com a pasta do mundo (level.dat, levelname.txt, pasta db/).
                      {selected.diskUsedBytes > 0 && <strong style={{ color: '#fbbf24' }}> Isso também apaga o mundo atual.</strong>}
                    </p>
                    <input type="file" accept=".zip" onChange={e => setImportFile(e.target.files?.[0] || null)} style={{ ...styles.input, padding: '10px' }} />

                    {!importConfirming ? (
                      <button onClick={() => handleImportWorld(false)} disabled={importWorking || !importFile} style={{ ...styles.button, marginTop: '14px', background: '#0d9488', color: 'var(--theme-text)', opacity: (importWorking || !importFile) ? 0.5 : 1 }} className="btn-anim">
                        {importWorking ? 'Importando...' : 'Importar Mundo'}
                      </button>
                    ) : (
                      <div style={{ marginTop: '14px', background: 'rgba(244,63,94,0.08)', border: '1px solid rgba(244,63,94,0.35)', padding: '16px', borderRadius: '14px' }}>
                        <p style={{ margin: '0 0 12px 0', fontSize: '12px', color: '#fb7185', fontWeight: '700' }}>
                          Tem certeza? O mundo atual será substituído pelo importado.
                        </p>
                        <div style={{ display: 'flex', gap: '10px' }}>
                          <button onClick={() => handleImportWorld(true)} disabled={importWorking} style={{ ...styles.button, background: '#f43f5e', color: 'var(--theme-text)' }} className="btn-anim">
                            Sim, substituir
                          </button>
                          <button onClick={() => setImportConfirming(false)} style={{ ...styles.button, background: '#334155', color: 'var(--theme-text)' }} className="btn-anim">
                            Cancelar
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {activeTab === 'addons' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                  <div style={styles.sectionCard} className="tab-enter">
                    <div style={{ display:'flex', alignItems:'center', gap:'10px', marginBottom:'6px' }}>
                      <div style={{ width:'34px', height:'34px', borderRadius:'10px', background:'linear-gradient(135deg, rgba(52,211,153,.18), rgba(14,165,233,.14))', display:'flex', alignItems:'center', justifyContent:'center', color:'#67e8f9' }}><IconPuzzle width={17} height={17}/></div>
                      <h3 style={{ ...styles.sectionTitle, margin:0 }}>Add-ons</h3>
                    </div>
                    <p style={{ margin:'0 0 16px', fontSize:'11px', color:'var(--theme-muted)', lineHeight:1.6 }}>Instale <b>BP (Behavior Pack)</b> e <b>RP (Resource Pack)</b>. Quando houver vários do mesmo tipo, eles ficam em abas próprias para você alterar a ordem e isolar conflitos.</p>
                    {(addonReview?.warnings?.length || addonWarnings.length) > 0 && (
                      <div className="addon-warning-box persistent"><IconAlert width={15} height={15}/><div><strong>Avisos de compatibilidade</strong>{[...new Set([...(addonReview?.warnings || []), ...addonWarnings])].map((w,i)=><div key={i}>{w}</div>)}</div></div>
                    )}
                    <div style={{ border: `2px dashed ${dragActive ? 'var(--panel-accent)' : '#334155'}`, borderRadius:'14px', padding:'24px', textAlign:'center', background:dragActive?'rgba(52,211,153,0.06)':'transparent' }} onDragOver={(e)=>{e.preventDefault();setDragActive(true)}} onDragLeave={()=>setDragActive(false)} onDrop={(e)=>{e.preventDefault();setDragActive(false);handleAddonFiles(e.dataTransfer.files)}}>
                      <p style={{margin:'0 0 12px',fontSize:'12px',color:'var(--theme-muted)'}}>Arraste um .mcpack/.mcaddon aqui, ou</p>
                      <label style={{...styles.button,display:'inline-flex',alignItems:'center',gap:'8px',cursor:'pointer'}}><IconLayers width={15} height={15}/> {addonUploading ? 'Analisando...' : 'Selecionar arquivo'}<input type="file" multiple accept=".mcpack,.mcaddon,.zip" style={{display:'none'}} disabled={addonUploading} onChange={e=>{handleAddonFiles(e.target.files);e.target.value='';}}/></label>
                    </div>
                    {addonProgress.length > 0 && (
                      <div className="addon-progress-list">
                        {addonProgress.map((p) => (
                          <div className="addon-progress-row" key={p.id || p.source}>
                            <div className="addon-progress-head"><span>{p.name}</span><span>{p.progress}%</span></div>
                            <div className="addon-progress-track"><span style={{width:`${p.progress}%`}} /></div>
                            <small>{p.type} • {p.version}{p.state === 'error' ? ' • erro' : p.state === 'done' ? ' • concluído' : ''}</small>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div style={styles.sectionCard} className="tab-enter">
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:'12px',flexWrap:'wrap',marginBottom:'14px'}}>
                      <div>
                        <h3 style={{...styles.sectionTitle,margin:'0 0 4px'}}>Packs instalados</h3>
                        <div style={{fontSize:'10px',color:'var(--theme-dim)'}}>{addonGroups.all.length} pack(s) • a ordem é aplicada ao mundo</div>
                      </div>
                      <div className="addon-tools">
                        {addonGroups.split && <div className="addon-kind-tabs" style={{display:'flex',gap:'6px',padding:'4px',background:'#0f172a',border:'1px solid #273449',borderRadius:'12px'}}>
                          {addonGroups.showBehaviorTab && <button className="btn-anim addon-kind-tab" onClick={()=>setAddonKindTab('behavior')} style={{...styles.actionBtn(addonKindTab==='behavior'?'rgba(52,211,153,.16)':'transparent',addonKindTab==='behavior'?'#6ee7b7':'#94a3b8'),border:addonKindTab==='behavior'?'1px solid rgba(52,211,153,.35)':'1px solid transparent'}}>BP <span>({addonGroups.behavior.length})</span></button>}
                          {addonGroups.showResourceTab && <button className="btn-anim addon-kind-tab" onClick={()=>setAddonKindTab('resource')} style={{...styles.actionBtn(addonKindTab==='resource'?'rgba(56,189,248,.16)':'transparent',addonKindTab==='resource'?'#7dd3fc':'#94a3b8'),border:addonKindTab==='resource'?'1px solid rgba(56,189,248,.35)':'1px solid transparent'}}>RP <span>({addonGroups.resource.length})</span></button>}
                        </div>}
                        {addonGroups.all.length > 1 && <div className="addon-reorder-mode" aria-label="Modo de organização dos add-ons">
                          <button type="button" className={`btn-anim ${addonReorderMode==='arrows'?'is-active':''}`} onClick={()=>{setAddonReorderMode('arrows');setAddonDraggingId(null);setAddonDragOverId(null)}} title="Organizar com setas"><IconArrowUp width="13" height="13"/><IconArrowDown width="13" height="13"/><span>Setas</span></button>
                          <button type="button" className={`btn-anim ${addonReorderMode==='drag'?'is-active':''}`} onClick={()=>{setAddonReorderMode('drag');setAddonDraggingId(null);setAddonDragOverId(null)}} title="Segurar e mover"><IconLayers width="13" height="13"/><span>Mover</span></button>
                        </div>}
                      </div>
                    </div>
                    {addonGroups.all.length===0 ? <p style={{margin:0,fontSize:'12px',color:'var(--theme-dim)'}}>Nenhum add-on instalado ainda.</p> : (addonGroups.split ? (addonKindTab === 'behavior' ? addonGroups.behavior : addonGroups.resource) : addonGroups.all).map((item,index,visibleGroup)=>{
                      const dragIndex = visibleGroup.findIndex(x => x.id === addonDraggingId);
                      const overIndex = visibleGroup.findIndex(x => x.id === addonDragOverId);
                      const previewShift = addonReorderMode === 'drag' && addonDraggingId && addonDragOverId && dragIndex !== -1 && overIndex !== -1
                        ? (dragIndex < overIndex && index > dragIndex && index <= overIndex ? 'shift-up' : dragIndex > overIndex && index >= overIndex && index < dragIndex ? 'shift-down' : '') : '';
                      return (
                      <div key={item.id} data-addon-id={item.id} draggable={addonReorderMode==='drag'}
                        onDragStart={(e)=>{setAddonDraggingId(item.id);setAddonDragOverId(item.id);e.dataTransfer.effectAllowed='move';}}
                        onDragOver={(e)=>{if(addonReorderMode==='drag'){e.preventDefault();setAddonDragOverId(item.id);}}}
                        onDrop={(e)=>{e.preventDefault();commitAddonDrop(item.kind,addonDraggingId,item.id)}}
                        onDragEnd={()=>{setAddonDraggingId(null);setAddonDragOverId(null)}}
                        onPointerDown={(e)=>startAddonPointerMove(item.kind,item.id,e)} onPointerMove={moveAddonPointer} onPointerUp={(e)=>endAddonPointerMove(item.kind,e)}
                        className={`addon-installed-row ${addonDraggingId===item.id?'is-dragging':''} ${addonDragOverId===item.id&&addonDraggingId!==item.id?'drop-target':''} ${previewShift}`}
                        style={{background:'linear-gradient(180deg,#182235,#141c2b)',border:'1px solid #2b3950',padding:'15px 16px',borderRadius:'14px',display:'flex',justifyContent:'space-between',alignItems:'center',gap:'14px',marginBottom:'9px',boxShadow:'0 10px 25px rgba(0,0,0,.12)'}}>
                        <div style={{minWidth:0,flex:1}}>
                          <div style={{display:'flex',alignItems:'center',gap:'8px',flexWrap:'wrap'}}>
                            <span style={{fontSize:'10px',fontWeight:900,color:item.kind==='behavior'?'#a7f3d0':'#bae6fd',letterSpacing:'.08em',padding:'3px 7px',borderRadius:'7px',background:item.kind==='behavior'?'rgba(52,211,153,.10)':'rgba(56,189,248,.10)',border:item.kind==='behavior'?'1px solid rgba(52,211,153,.18)':'1px solid rgba(56,189,248,.18)'}}>{item.kind==='behavior'?'BP':'RP'}</span>
                            <span style={{fontSize:'13px',fontWeight:800,color:'var(--theme-text)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{item.name || 'Pack sem nome'}</span>
                            <span style={{fontSize:'9px',color:'var(--theme-dim)',padding:'3px 7px',borderRadius:'999px',background:'#0f172a'}}>v{item.version}</span><span className="addon-size-badge">{item.sizeLabel || 'tamanho desconhecido'}</span>
                          </div>
                          <div style={{fontSize:'10px',color:'var(--theme-muted)',lineHeight:1.5,marginTop:'5px'}}>{item.description || 'Sem descrição fornecida pelo manifest.json.'}</div>
                          <div style={{fontSize:'9px',color:'#475569',fontFamily:'monospace',marginTop:'5px',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{item.id}</div>
                        </div>
                        <div style={{display:'flex',alignItems:'center',gap:'6px',flexShrink:0}}>
                          {addonReorderMode==='arrows' && <>
                            <button className="btn-anim" title="Mover para cima" disabled={index===0} onClick={()=>handleMoveAddon(item.kind,item.id,-1)} style={{...styles.actionBtn('#0f172a','#94a3b8'),padding:'7px',opacity:index===0?.35:1}}><IconArrowUp width={14} height={14}/></button>
                            <button className="btn-anim" title="Mover para baixo" disabled={index===visibleGroup.length-1} onClick={()=>handleMoveAddon(item.kind,item.id,1)} style={{...styles.actionBtn('#0f172a','#94a3b8'),padding:'7px',opacity:index===visibleGroup.length-1?.35:1}}><IconArrowDown width={14} height={14}/></button>
                          </>}
                          {addonReorderMode==='drag' && <span className="addon-drag-handle" title="Segure e arraste"><IconLayers width={16} height={16}/></span>}
                          <button className="btn-anim" title="Remover pack" onClick={(e)=>{e.stopPropagation();handleRemoveAddon(item.id)}} style={{...styles.actionBtn('rgba(244,63,94,.14)','#fb7185'),padding:'7px'}}><IconTrash width={14} height={14}/></button>
                        </div>
                      </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {activeTab === 'console' && (
                <div className="axent-console-page">
                  <div className="console-toolbar-card">
                    <div className="console-toolbar-title"><div className="console-shell-icon"><IconTerminal width="17" height="17" /></div><div><strong>Console</strong><span>Console ao vivo e comandos do servidor</span></div></div>
                    <div className="console-resource-group">
                      <div className="console-resource-chip"><span>RAM</span><strong>{consoleResources ? `${consoleResources.ram.usedPercent}%` : '—'}</strong></div>
                      <div className="console-resource-chip"><span>RAM livre</span><strong>{consoleResources ? `${(consoleResources.ram.freeBytes/1024/1024/1024).toFixed(1)} GB` : '—'}</strong></div>
                      <div className="console-resource-chip"><span>CPU load</span><strong>{consoleResources ? consoleResources.cpu.load1.toFixed(2) : '—'}</strong></div>
                    </div>
                    <div className="console-toolbar-actions">
                      <button type="button" className="console-tool-btn btn-anim" title="Copiar console" aria-label="Copiar console" onClick={() => navigator.clipboard?.writeText(logs.join('\n')).then(()=>showInfo('Console copiado.')).catch(()=>{})}><IconCopy width="15" height="15" /></button>
                      <button type="button" className="console-tool-btn btn-anim" title="Limpar visualização" aria-label="Limpar visualização" onClick={() => setLogs([])}><IconTrash width="15" height="15" /></button>
                      <button type="button" className={`console-tool-btn btn-anim ${consoleSearchOpen ? 'is-active' : ''}`} title="Pesquisar no console" aria-label="Pesquisar no console" onClick={() => setConsoleSearchOpen(v => !v)}><IconSearch width="15" height="15" /></button>
                    </div>
                    {consoleSearchOpen && (
                      <div className="console-search-popover">
                        <IconSearch width="14" height="14" />
                        <input autoFocus value={consoleSearch} onChange={e => setConsoleSearch(e.target.value)} placeholder="Pesquisar no console..." aria-label="Pesquisar no console" />
                        {consoleSearch && <span className="console-search-count">{logs.filter(l => l.toLowerCase().includes(consoleSearch.toLowerCase())).length}</span>}
                      </div>
                    )}
                  </div>
                  <div className="console-window">
                    <div className="console-window-top"><span className="console-prompt">&gt;_</span><span>server@bedrock</span><span className="console-top-status">{selected.status}</span></div>
                    <div className="console-log-area" ref={consoleEndRef}>
                      {logs.length === 0 && <div className="console-empty">{selected.status === 'Online' ? 'Aguardando saída do servidor…' : 'Servidor está offline…'}</div>}
                      {logs.map((log, i) => {
                        const q = consoleSearch.trim().toLowerCase();
                        const match = q && log.toLowerCase().includes(q);
                        return <div key={i} className={`console-line ${match ? 'console-line-match' : ''}`}><span className="console-caret">›</span>{log}</div>;
                      })}
                    </div>
                  </div>
                  <form className="console-command-bar" onSubmit={handleSendCommand}>
                    <span className="console-command-prefix">&gt;</span>
                    <input type="text" placeholder="Digite um comando..." value={commandInput} onChange={e => setCommandInput(e.target.value)} disabled={selected.status !== 'Online'} />
                    <button type="submit" disabled={selected.status !== 'Online'} className="console-send btn-anim">Enviar</button>
                  </form>
                </div>
              )}

              {activeTab === 'events' && (
                <div>
                  <h3 style={styles.sectionTitle}>Registro de Eventos</h3>
                  <p style={{ margin: '0 0 16px 0', fontSize: '11px', color: 'var(--theme-muted)' }}>Histórico real de ações desse mundo — ligar, desligar, criar, importar, addons, backups.</p>
                  {events.length === 0 ? (
                    <p style={{ fontSize: '12px', color: 'var(--theme-dim)' }}>Nenhum evento registrado ainda.</p>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                      {events.map((ev, i) => (
                        <div key={i} style={{ background: '#161e2e', border: '1px solid #232f42', borderRadius: '10px', padding: '10px 14px', fontSize: '12px', display: 'flex', justifyContent: 'space-between', gap: '10px' }}>
                          <span>{ev.message}</span>
                          <span style={{ color: 'var(--theme-dim)', fontSize: '10px', whiteSpace: 'nowrap' }}>{new Date(ev.time).toLocaleString('pt-BR')}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'players' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                  <div className="props-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '14px' }}>
                    <div style={styles.axentInfoBox}>
                      <span style={{ fontSize: '9px', color: 'var(--theme-muted)', textTransform: 'uppercase', fontWeight: '700' }}>Jogadores Online</span>
                      <span style={{ fontSize: '16px', fontWeight: 'bold', color: 'var(--theme-text)' }}>
                        {selected.status !== 'Online' ? '— (offline)' : players ? `${players.online} / ${players.max}` : 'consultando...'}
                      </span>
                      {players?.names?.length > 0 && <span style={{ fontSize: '10px', color: 'var(--theme-dim)' }}>{players.names.join(', ')}</span>}
                    </div>
                  </div>

                  <div style={styles.sectionCard}>
                    <h3 style={styles.sectionTitle}>Lista de Permissão (Allowlist)</h3>
                    <p style={{ margin: '0 0 16px 0', fontSize: '11px', color: 'var(--theme-muted)' }}>Grava direto no allowlist.json real do servidor.</p>
                    <div style={{ display: 'flex', gap: '10px', marginBottom: '16px' }}>
                      <input style={styles.input} placeholder="Nome do jogador" value={newAllowlistName} onChange={e => setNewAllowlistName(e.target.value)} />
                      <button onClick={handleAddAllowlist} style={{ ...styles.button, whiteSpace: 'nowrap' }} className="btn-anim">Adicionar</button>
                    </div>
                    {allowlist.length === 0 ? (
                      <p style={{ fontSize: '12px', color: 'var(--theme-dim)' }}>Allowlist vazia — qualquer jogador pode entrar (se online-mode permitir).</p>
                    ) : (
                      allowlist.map(p => (
                        <div key={p.name} style={{ background: '#161e2e', border: '1px solid #232f42', borderRadius: '10px', padding: '10px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                          <span style={{ fontSize: '12px', fontWeight: '700' }}>{p.name}</span>
                          <button onClick={() => handleRemoveAllowlist(p.name)} style={{ background: 'rgba(244,63,94,0.2)', border: 'none', padding: '8px', borderRadius: '8px', color: '#f43f5e', cursor: 'pointer' }}><IconTrash /></button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {activeTab === 'experiments' && (
                <section className="experiments-panel section-card" aria-labelledby="experiments-title">
                  <div className="experiments-heading">
                    <div className="experiments-heading-copy">
                      <span className="settings-kicker">BEDROCK • WORLD DATA</span>
                      <h3 id="experiments-title">Jogabilidade Experimental</h3>
                      <p>Recursos gravados diretamente no <code>level.dat</code> deste mundo.</p>
                    </div>
                    <div className="experiments-icon" aria-hidden="true"><IconFlask width="18" height="18" /></div>
                  </div>

                  <div className="experiment-warning">
                    <span className="experiment-warning-icon"><IconAlert width="15" height="15" /></span>
                    <p>Depois de ativado, um experimento não pode ser desativado no mesmo mundo. Isso é uma limitação do Bedrock.</p>
                  </div>

                  {!experiments ? (
                    <div className="experiment-state loading" aria-live="polite"><span className="loading-orb" />Carregando experimentos...</div>
                  ) : !experiments.available ? (
                    <div className="experiment-state empty"><div className="experiment-empty-icon"><IconFlask width="17" height="17" /></div><strong>Mundo ainda não gerado</strong><span>{experiments.reason}</span></div>
                  ) : (
                    <>
                      <div className="experiment-meta">
                        <span>Configurações disponíveis</span>
                        <strong>{Object.values(experiments.experiments || {}).filter(Boolean).length}/3 ativas</strong>
                      </div>
                      <div className="experiment-list">
                        {[
                          ['upcomingCreatorFeatures', 'Próximos Recursos do Criador'],
                          ['gametest', 'GameTest Framework'],
                          ['holidayCreatorFeatures', 'Recursos de Criador de Feriados']
                        ].map(([key, label]) => (
                          <div className={`experiment-row ${experiments.experiments[key] ? 'is-on' : ''}`} key={key}>
                            <div className="experiment-row-copy"><strong>{label}</strong><span>{experiments.experiments[key] ? 'Ativo • não reversível' : 'Disponível para este mundo'}</span></div>
                            <Toggle checked={!!experiments.experiments[key]} onChange={() => toggleExperiment(key)} disabled={selected.status !== 'Offline' || experiments.experiments[key]} />
                          </div>
                        ))}
                      </div>
                      <div className="experiment-footer">
                        <span>{selected.status === 'Offline' ? 'O mundo está pronto para receber alterações.' : 'Pare o servidor para alterar os experimentos.'}</span>
                        <button onClick={handleSaveExperiments} disabled={expSaving || selected.status !== 'Offline'} className="btn-anim experiment-save">
                          {expSaving ? 'Salvando...' : 'Salvar experimentos'}
                        </button>
                      </div>
                    </>
                  )}
                </section>
              )}

              {activeTab === 'software' && (() => {
                const versions = softwareInfo?.versions || [];
                const currentVersion = softwareInfo?.currentVersion || null;
                const selectedVersion = swVersion === 'latest' ? (softwareInfo?.latest || null) : swVersion;
                const currentIndex = currentVersion ? versions.indexOf(currentVersion) : -1;
                const selectedIndex = selectedVersion ? versions.indexOf(selectedVersion) : -1;
                // Lista vem do mais novo pro mais antigo, então índice MENOR = versão mais nova.
                const isSame = !!selectedVersion && selectedVersion === currentVersion;
                const isUpgrade = !isSame && currentIndex !== -1 && selectedIndex !== -1 && selectedIndex < currentIndex;
                const isDowngrade = !isSame && currentIndex !== -1 && selectedIndex !== -1 && selectedIndex > currentIndex;
                const isChanging = !!selectedVersion && !isSame;

                return (
                  <div style={styles.sectionCard}>
                    <h3 style={styles.sectionTitle}>Software</h3>
                    <p style={{ margin: '0 0 16px 0', fontSize: '11px', color: 'var(--theme-muted)' }}>Só Bedrock Dedicated Server (sem Java). Atualizar pra uma versão mais nova mantém o mundo intacto — só downgrade recomenda reinstalar.</p>
                    <div style={{ background: '#161e2e', border: '1px solid #232f42', borderRadius: '14px', padding: '18px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: '800', color: 'var(--theme-text)' }}>{softwareInfo?.software || 'Bedrock Dedicated Server'}{currentVersion ? ` ${currentVersion}` : ''}</div>
                        <div style={{ fontSize: '10px', color: softwareInfo?.binaryAvailable ? 'var(--panel-accent)' : '#fbbf24', marginTop: '4px' }}>
                          {softwareInfo?.binaryAvailable ? '● Binário instalado' : `⚠ Binário não encontrado em ${softwareInfo?.binDir || ''}`}
                        </div>
                      </div>
                    </div>

                    <div style={{ marginTop: '16px' }}>
                      <label style={styles.label}>Trocar versão</label>
                      <select value={swVersion} onChange={e => setSwVersion(e.target.value)} style={styles.input}>
                        {softwareInfo?.latest && <option value="latest">Mais recente ({softwareInfo.latest})</option>}
                        {versions.map(v => (
                          <option key={v} value={v}>{v}{v === currentVersion ? ' (atual)' : ''}</option>
                        ))}
                      </select>
                    </div>

                    {isChanging && isUpgrade && (
                      <div style={{ marginTop: '12px', background: 'rgba(52,211,153,0.08)', border: '1px solid rgba(52,211,153,0.3)', borderRadius: '12px', padding: '12px 14px', fontSize: '11px', color: '#6ee7b7', lineHeight: 1.5 }}>
                        ✓ {selectedVersion} é mais nova que a atual ({currentVersion}). <strong>Atualizar</strong> só troca os binários e mantém o mundo — é a opção recomendada. Reinstalar também funciona, mas apaga os dados do mundo.
                      </div>
                    )}
                    {isChanging && isDowngrade && (
                      <div style={{ marginTop: '12px', background: 'rgba(217,119,6,0.1)', border: '1px solid rgba(217,119,6,0.35)', borderRadius: '12px', padding: '12px 14px', fontSize: '11px', color: '#fbbf24', lineHeight: 1.5 }}>
                        ⚠ {selectedVersion} é mais antiga que a atual ({currentVersion}). Downgrade pode corromper o save do mundo — <strong>Reinstalar</strong> (apaga os dados) é a opção recomendada. "Atualizar mesmo assim" mantém os dados, mas é por sua conta e risco.
                      </div>
                    )}

                    <div style={{ marginTop: '16px', background: '#0f172a', padding: '16px', borderRadius: '14px', border: '1px solid rgba(148,163,184,0.15)', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      <input type="password" placeholder="PIN de Confirmação" value={swPin} onChange={e => setSwPin(e.target.value)} style={styles.input} />
                      <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                        <button
                          onClick={handleSoftwareUpdate}
                          disabled={!isChanging}
                          style={{ ...styles.button, flex: 1, minWidth: '160px', opacity: !isChanging ? 0.4 : 1, background: isUpgrade || !isDowngrade ? 'var(--panel-accent)' : '#334155', color: isUpgrade || !isDowngrade ? '#020617' : 'var(--theme-text)' }}
                          className="btn-anim"
                        >
                          {isDowngrade ? 'Atualizar mesmo assim' : 'Atualizar'}
                        </button>
                        <button
                          onClick={handleSoftwareReinstall}
                          style={{ ...styles.button, flex: 1, minWidth: '160px', background: isDowngrade ? '#d97706' : '#334155', color: isDowngrade ? '#020617' : 'var(--theme-text)', whiteSpace: 'nowrap' }}
                          className="btn-anim"
                        >
                          Reinstalar{isDowngrade ? ' (recomendado)' : ''}
                        </button>
                      </div>
                      <p style={{ margin: 0, fontSize: '10px', color: 'var(--theme-dim)' }}>Atualizar troca só os binários (mundo intacto). Reinstalar apaga os dados do mundo. Ambos exigem o servidor desligado.</p>
                    </div>
                  </div>
                );
              })()}

              {activeTab === 'files' && (() => {
                if (fileEditor) {
                  return (
                    <div className="files-panel files-frame" style={{ ...styles.sectionCard, padding:0, display:'flex', flexDirection:'column', minHeight:'520px', height:'calc(100vh - 320px)' }}>
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:'10px',padding:'14px 18px',borderBottom:'1px solid var(--theme-border)'}}>
                        <button onClick={()=>setFileEditor(null)} className="btn-anim" style={{...styles.actionBtn('#161e2e','#cbd5e1'),padding:'8px 14px'}}>‹ Voltar</button>
                        <div style={{fontSize:'11px',color:'var(--theme-muted)',fontFamily:'monospace',flex:1,textAlign:'center',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{fileEditor.path}</div>
                        <button onClick={handleSaveFile} disabled={fileEditorSaving} style={styles.button} className="btn-anim">{fileEditorSaving?'Salvando…':'Salvar'}</button>
                      </div>
                      <textarea value={fileEditor.content} onChange={e=>setFileEditor({...fileEditor,content:e.target.value})} spellCheck="false" style={{...styles.input,flex:1,minHeight:0,resize:'none',border:'none',borderRadius:0,fontFamily:'ui-monospace, SFMono-Regular, Menlo, monospace',lineHeight:1.5}} />
                    </div>
                  );
                }
                if (imagePreview) {
                  return (
                    <div className="files-panel files-frame" style={{ ...styles.sectionCard, padding:0, display:'flex', flexDirection:'column', minHeight:'520px', height:'calc(100vh - 320px)' }}>
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:'10px',padding:'14px 18px',borderBottom:'1px solid var(--theme-border)'}}>
                        <button onClick={()=>setImagePreview(null)} className="btn-anim" style={{...styles.actionBtn('#161e2e','#cbd5e1'),padding:'8px 14px'}}>‹ Voltar</button>
                        <div style={{fontSize:'11px',color:'var(--theme-muted)',fontFamily:'monospace',flex:1,textAlign:'center',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{imagePreview.name}</div>
                        <a href={imagePreview.url} download={imagePreview.name} className="btn-anim" style={{...styles.actionBtn('var(--panel-accent)','#04140d'),padding:'8px 14px',textDecoration:'none'}}>Baixar</a>
                      </div>
                      <div style={{flex:1,minHeight:0,display:'flex',alignItems:'center',justifyContent:'center',overflow:'auto',padding:'20px',background:'#05070b'}}>
                        {imagePreviewError ? (
                          <div style={{textAlign:'center',color:'#fbbf24',fontSize:'12px',maxWidth:'420px'}}>⚠ {imagePreviewError}</div>
                        ) : (
                          <img src={imagePreview.url} alt={imagePreview.name} style={{maxWidth:'100%',maxHeight:'100%',borderRadius:'8px'}}
                            onError={async () => {
                              try {
                                const r = await fetch(imagePreview.url);
                                const data = await r.json().catch(() => null);
                                setImagePreviewError(data?.error || `Não foi possível carregar a imagem (HTTP ${r.status}).`);
                              } catch {
                                setImagePreviewError('Não foi possível carregar a imagem. Verifique a conexão com o servidor.');
                              }
                            }}
                          />
                        )}
                      </div>
                    </div>
                  );
                }
                return (
                <div className="files-panel" style={{ display:'flex', flexDirection:'column', gap:'14px' }}>
                  <div className="files-toolbar-card" style={{ ...styles.sectionCard }}>
                    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:'10px', flexWrap:'wrap' }}>
                      <div style={{ display:'flex', gap:'10px', alignItems:'center', flexWrap:'wrap', minWidth:0 }}>
                        <input
                          type="checkbox"
                          title="Selecionar tudo"
                          aria-label="Selecionar tudo"
                          checked={fileEntries.length>0 && selectedFiles.length===fileEntries.length}
                          ref={el=>{ if(el) el.indeterminate = selectedFiles.length>0 && selectedFiles.length<fileEntries.length; }}
                          onChange={e=>setSelectedFiles(e.target.checked?fileEntries.map(x=>x.path):[])}
                        />
                        <div className="files-breadcrumbs">
                          <button onClick={() => navigateFiles('')} className="files-breadcrumb-root" title="Raiz" aria-label="Raiz">/ {selected?.folderName || 'servidor'}</button>
                          {filesPath.split('/').filter(Boolean).map((part, i, arr) => { const pathPart=arr.slice(0,i+1).join('/'); return <span key={pathPart} className="files-breadcrumb-sep"><span aria-hidden="true">/</span><button onClick={()=>navigateFiles(pathPart)}>{part}</button></span>; })}
                        </div>
                      </div>
                      <div style={{ display:'flex', gap:'8px', flexWrap:'wrap', alignItems:'center' }}>
                        <button onClick={handleCreateFile} className="file-toolbar-btn btn-anim" title="Criar arquivo"><IconFilePlus width="15" height="15" /><span>Novo arquivo</span></button>
                        <button onClick={handleCreateFolder} className="file-toolbar-btn btn-anim" title="Criar pasta"><IconFolderPlus width="15" height="15" /><span>Nova pasta</span></button>
                        <label className="file-toolbar-btn file-toolbar-btn-accent btn-anim" title="Enviar arquivos"><IconUpload width="15" height="15" /><span>Upload</span><input type="file" multiple style={{display:'none'}} onChange={e=>{handleFileUpload(e.target.files);e.target.value='';}} disabled={fileUploadBusy}/></label>
                        {selectedFiles.length > 0 && <div className="file-selection-tools file-menu-root">
                          <span>{selectedFiles.length} selecionado(s)</span>
                          <button type="button" className="file-selection-kebab btn-anim" title="Ações da seleção" onClick={()=>setFileMenuPath(fileMenuPath==='__selection__'?null:'__selection__')}>⋮</button>
                          {fileMenuPath==='__selection__' && <div className="file-context-menu file-selection-menu" role="menu">
                            <button type="button" onClick={()=>{setFileMenuPath(null);handleArchiveSelectedFiles();}}><IconArchive width="14" height="14"/> Arquivar</button>
                            <button type="button" className="is-danger" onClick={()=>{setFileMenuPath(null);handleDeleteSelectedFiles();}}><IconTrash width="14" height="14"/> Excluir</button>
                          </div>}
                        </div>}
                      </div>
                    </div>
                  </div>
                  <div className="files-list-card" style={{ ...styles.sectionCard, padding:0, overflow:'visible' }}>
                    {filesPath && <div className="file-grid" onClick={() => navigateFiles(filesPath.split('/').slice(0,-1).join('/'))} style={{ display:'grid', gridTemplateColumns:'minmax(220px,1fr) 100px 190px', cursor:'pointer', color:'var(--theme-muted)' }}><span>↩ ..</span><span></span><span></span></div>}
                    {fileEntries.length===0 ? <div style={{padding:'40px',textAlign:'center',color:'var(--theme-dim)',fontSize:'12px'}}>Pasta vazia.</div> : fileEntries.map(entry => {
                      const selected = selectedFiles.includes(entry.path);
                      const closeMenu = () => setFileMenuPath(null);
                      return <div key={entry.path} className={`file-grid file-entry-row ${selected?'is-selected':''} ${fileMenuPath===entry.path?'is-menu-open':''}`} style={{ display:'grid', gridTemplateColumns:'minmax(220px,1fr) 100px 190px', alignItems:'center', background:selected?'var(--panel-accent-soft)':'transparent' }}>
                        <div style={{ display:'flex', alignItems:'center', gap:'12px', minWidth:0 }}>
                          <input type="checkbox" checked={selected} aria-label={`Selecionar ${entry.name}`} onChange={e=>{setSelectedFiles(prev=>e.target.checked?[...new Set([...prev,entry.path])]:prev.filter(x=>x!==entry.path));setFileMenuPath(null);}}/>
                          <span onClick={()=>{
                            if (entry.isDir) return navigateFiles(entry.path);
                            if (entry.editable) return handleEditFile(entry);
                            if (entry.kind === 'image') { setImagePreviewError(null); return setImagePreview({ name: entry.name, url: api.viewFileUrl(selectedId, entry.path) }); }
                            if (entry.isZip) { window.location.href = api.downloadFileUrl(selectedId, entry.path); }
                            // Qualquer outro tipo (binário, protegido etc.): sem ação no clique —
                            // baixar é só pelo menu "⋮ → Baixar".
                          }} title={entry.isDir?'Abrir pasta':entry.editable?'Abrir no editor':entry.kind==='image'?'Ver imagem':entry.isZip?'Baixar arquivo':'Use o menu (⋮) pra baixar'} className={`file-name ${entry.isDir?'is-folder':''} ${entry.protected?'is-protected':''}`}>
                            <span className="file-type-icon"><FileTypeIcon entry={entry}/></span><span className="file-name-text">{entry.name}</span>{entry.protected&&<span className="file-lock-badge"><IconLock width="11" height="11" /></span>}
                          </span>
                        </div>
                        <span style={{color:'var(--theme-dim)'}}>{entry.isDir||entry.size==null?'—':entry.size<1024?`${entry.size} B`:entry.size<1024*1024?`${(entry.size/1024).toFixed(1)} KB`:`${(entry.size/1024/1024).toFixed(1)} MB`}</span>
                        <div style={{display:'flex',alignItems:'center',justifyContent:'flex-end',gap:'14px',minWidth:0}}>
                          <span style={{color:'var(--theme-dim)',whiteSpace:'nowrap'}}>{formatFileDate(entry.modifiedAt)}</span>
                          <div className="file-menu-root" style={{position:'relative',flex:'0 0 auto'}}>
                            <button type="button" className="file-kebab" title="Mais ações" aria-label={`Mais ações para ${entry.name}`} onClick={(e)=>{e.stopPropagation();setFileMenuPath(fileMenuPath===entry.path?null:entry.path);}}><span aria-hidden="true">⋮</span></button>
                            {fileMenuPath===entry.path && (
                              <div className="file-context-menu" role="menu">
                                {entry.protected && <div className="file-context-note"><IconLock width="13" height="13"/> Arquivo protegido</div>}
                                {!entry.isDir && <button type="button" onClick={()=>{closeMenu();window.location.href = api.downloadFileUrl(selectedId, entry.path);}}><IconArrowDown width="14" height="14"/> Baixar</button>}
                                {entry.isDir && <button type="button" onClick={()=>{closeMenu();window.location.href = api.downloadFileUrl(selectedId, entry.path);}}><IconArrowDown width="14" height="14"/> Baixar como ZIP</button>}
                                {/* Arquivo protegido (bedrock_server): nunca oferece compactar,
                                    renomear, mover ou excluir — só baixar. */}
                                {!entry.protected && <>
                                  <button type="button" onClick={()=>{closeMenu();handleArchiveFile(entry);}}><IconBackup width="14" height="14"/> Arquivar em ZIP</button>
                                  <button type="button" onClick={()=>{closeMenu();handleRenameFile(entry);}}><IconWrench width="14" height="14"/> Renomear</button>
                                  <button type="button" onClick={()=>{closeMenu();handleMoveFile(entry);}}><IconLayers width="14" height="14"/> Mover</button>
                                  <button type="button" className="is-danger" onClick={()=>{closeMenu();handleDeleteFile(entry);}}><IconTrash width="14" height="14"/> Excluir</button>
                                </>}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>;
                    })}
                  </div>
                </div>
                );
              })()}

              {activeTab === 'backups' && (
                <div style={styles.sectionCard}>
                  <h3 style={styles.sectionTitle}>Cópias de Segurança</h3>
                  <button onClick={() => api.backup(selected.id).then(() => { showInfo('Backup criado.'); refreshBackups(); }).catch(showError)} style={{ ...styles.button, marginBottom: '16px', background:'var(--panel-accent)', color:'#03120d' }} className="btn-anim">
                    Fazer Backup Manual Agora
                  </button>
                  <a href={api.downloadWorldUrl(selected.id)} style={{ ...styles.actionBtn('#334155','#fff'), textDecoration:'none', marginBottom:'16px', width:'fit-content' }} className="btn-anim">↓ Baixar mundo atual</a>
                  {backups.length === 0 ? (
                    <p style={{ fontSize: '12px', color: 'var(--theme-dim)' }}>Nenhum backup ainda.</p>
                  ) : (
                    backups.map(b => (
                      <div key={b.fileName} className="backup-row" style={{ background: 'var(--theme-panel)', border: '1px solid var(--theme-border)', borderRadius: '14px', padding: '10px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px', flexWrap: 'wrap', gap: '8px' }}>
                        <div>
                          <div style={{ fontSize: '11px', fontWeight: '700' }}>{b.fileName}</div>
                          <div style={{ fontSize: '10px', color: 'var(--theme-dim)' }}>{b.sizeLabel} • {new Date(b.createdAt).toLocaleString('pt-BR')}</div>
                        </div>
                        <div style={{display:'flex',gap:'8px',alignItems:'center'}}>
                          <a href={`${API_BASE}/api/worlds/${selected.id}/backups/${encodeURIComponent(b.fileName)}/download`} style={{ fontSize: '10px', color: 'var(--panel-accent)', fontWeight: '700' }}>Baixar</a>
                          <button onClick={async()=>{ if(selected.status!=='Offline') return showError(new Error('Pare o servidor antes de restaurar.')); if(!window.confirm(`Restaurar ${b.fileName}? O mundo atual será substituído.`)) return; try { const r=await api.restoreBackup(selected.id,b.fileName,true); showInfo(r.message); await refreshWorlds(); } catch(err){ showError(err); } }} style={{...styles.actionBtn('var(--theme-surface)','#fff'),padding:'5px 8px'}}>Restaurar</button>
                          <button onClick={async()=>{ if(!window.confirm(`Apagar permanentemente ${b.fileName}?`)) return; try { const r=await api.deleteBackup(selected.id,b.fileName); showInfo(r.message || 'Backup apagado.'); await refreshBackups(); } catch(err){ showError(err); } }} style={{...styles.actionBtn('rgba(244,63,94,.14)','#fb7185'),padding:'5px 8px'}}>Apagar</button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {activeTab === 'danger' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', background: 'rgba(244, 63, 94, 0.04)', border: '1px solid rgba(244, 63, 94, 0.2)', padding: '22px', borderRadius: '18px' }}>
                  <p style={{ margin: 0, fontSize: '11px', color: 'var(--theme-muted)' }}>PIN e senha são validados no backend — nada fica exposto no código do navegador.</p>
                  <div style={{ background: '#0f172a', padding: '16px', borderRadius: '14px', border: '1px solid rgba(244, 63, 94, 0.2)', display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
                    <input type="password" placeholder="PIN de Reinstalação" value={reinstallPin} onChange={e => setReinstallPin(e.target.value)} style={{ ...styles.input, flex: 1, minWidth: '160px' }} />
                    <button onClick={handleReinstall} style={{ ...styles.button, background: '#d97706', color: 'var(--theme-text)', whiteSpace: 'nowrap' }}>Reinstalar Mundo</button>
                  </div>
                  <div style={{ background: '#0f172a', padding: '16px', borderRadius: '14px', border: '1px solid rgba(244, 63, 94, 0.2)', display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
                    <input type="password" placeholder="Senha Mestre" value={deletePass} onChange={e => setDeletePass(e.target.value)} style={{ ...styles.input, flex: 1, minWidth: '160px' }} />
                    <button onClick={handleDeleteMaster} style={{ ...styles.button, background: '#f43f5e', color: 'var(--theme-text)', whiteSpace: 'nowrap' }}>Deletar Mundo</button>
                  </div>
                </div>
              )}
              </div>
            </div>
          </div>
        )}
      </main>

      {addonReview?.stacked && !addonReview?.installing && (
        <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="addon-review-title" onMouseDown={(e)=>{ if(e.target===e.currentTarget){ setAddonReview(null); setAddonPendingFile(null); setAddonPendingFiles([]); setAddonProgress([]); setAddonWarnings([]); setAddonReviewExpanded(false); setAddonReviewSelected(null); } }}>
          <div className="addon-review-modal">
            <div className="addon-review-header">
              <div className="modal-icon"><IconLayers width="22" height="22" /></div>
              <div style={{minWidth:0,flex:1}}>
                <div id="addon-review-title" className="modal-title">Packs encontrados</div>
                <p>{addonReview.files?.length || 1} arquivo(s) selecionado(s) • {addonReview.packs.length} pack(s) detectado(s). Você pode conferir tudo ou instalar direto.</p>
              </div>
            </div>
            <div className="addon-review-summary">
              <div><strong>{addonReview.packs.length}</strong><span>packs</span></div>
              <div><strong>{addonReview.files?.length || 1}</strong><span>arquivos</span></div>
              <div><strong>{addonReview.packs.filter(p=>p.kind==='behavior').length}</strong><span>BP</span></div>
              <div><strong>{addonReview.packs.filter(p=>p.kind!=='behavior').length}</strong><span>RP</span></div>
            </div>
            <div className="modal-actions compact">
              <button className="modal-secondary btn-anim" type="button" onClick={()=>setAddonReviewExpanded(v=>!v)}>
                {addonReviewExpanded ? 'Ocultar detalhes' : 'Ver todos'}
              </button>
            </div>
            {addonReviewExpanded && (
              <div className="addon-review-explorer">
                <div className="addon-review-list">
                  {addonReview.packs.map((p) => (
                    <button type="button" className={`addon-review-item addon-review-selectable ${addonReviewSelected?.id===p.id?'selected':''}`} key={p.id} onClick={()=>setAddonReviewSelected(p)}>
                      <div><strong>{p.name}</strong><small>{p.type} • v{p.version} • {p.sourceFile || 'arquivo enviado'}</small><span>{p.description || 'Sem descrição fornecida pelo manifest.json.'}</span></div>
                      <span className={p.kind === 'behavior' ? 'pack-chip bp' : 'pack-chip rp'}>{p.kind === 'behavior' ? 'BP' : 'RP'}</span>
                    </button>
                  ))}
                </div>
                <div className="addon-review-detail">
                  {addonReviewSelected ? (
                    <>
                      <span className={addonReviewSelected.kind === 'behavior' ? 'pack-chip bp' : 'pack-chip rp'}>{addonReviewSelected.kind === 'behavior' ? 'Behavior Pack' : 'Resource Pack'}</span>
                      <h4>{addonReviewSelected.name}</h4>
                      <p>{addonReviewSelected.description || 'Sem descrição informada.'}</p>
                      <dl><dt>Versão</dt><dd>{addonReviewSelected.version}</dd><dt>Tipo</dt><dd>{addonReviewSelected.type}</dd><dt>Arquivo</dt><dd>{addonReviewSelected.sourceFile}</dd></dl>
                    </>
                  ) : <div className="addon-review-detail-empty">Selecione um pack para ver os detalhes.</div>}
                </div>
              </div>
            )}
            {addonReview.warnings?.length > 0 && <div className="addon-warning-box"><IconAlert width={15} height={15}/><div><strong>Existem avisos</strong><span>Alguns arquivos opcionais ou informações não foram encontrados. Os packs válidos continuarão normalmente.</span></div></div>}
            <div className="modal-actions">
              <button className="modal-secondary btn-anim" type="button" onClick={()=>{setAddonReview(null);setAddonPendingFile(null);setAddonPendingFiles([]);setAddonProgress([]);setAddonWarnings([]);setAddonReviewExpanded(false);setAddonReviewSelected(null)}}>Cancelar</button>
              <button className="modal-primary btn-anim" type="button" onClick={()=>handleConfirmAddonInstall()}><IconLayers width="15" height="15"/> Confirmar instalação</button>
            </div>
          </div>
        </div>
      )}

      {forceStopConfirming && (
        <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="force-stop-title" onMouseDown={(e)=>{ if(e.target===e.currentTarget && !forceStopping) setForceStopConfirming(false); }}>
          <div className="confirm-modal">
            <div className="modal-icon danger"><IconBolt width="22" height="22" /></div>
            <div className="modal-copy">
              <div id="force-stop-title" className="modal-title">Parar servidor à força?</div>
              <p>Use isto só quando o servidor travou ou não respeita o botão Parar. O processo será encerrado imediatamente, sem esperar o desligamento normal.</p>
            </div>
            <div className="modal-actions">
              <button onClick={() => setForceStopConfirming(false)} disabled={forceStopping} className="modal-secondary btn-anim">Cancelar</button>
              <button onClick={() => handleForceStop(selected.id)} disabled={forceStopping} className="modal-danger btn-anim"><IconBolt width="15" height="15" />{forceStopping ? 'Parando…' : 'Sim, parar agora'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
    </>
  );
}