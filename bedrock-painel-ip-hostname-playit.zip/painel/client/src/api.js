// Ajusta automaticamente a URL base conforme o ambiente (Local ou Cloudflare Worker)
const DEFAULT_API_BASE = typeof window !== 'undefined'
  ? window.location.origin
  : '';

export const API_BASE = (import.meta.env.VITE_API_URL || DEFAULT_API_BASE).replace(/\/$/, '');

// Se estiver em HTTPS (Cloudflare), usa wss://. Se estiver em HTTP local, usa ws://
const WS_BASE = API_BASE.replace(/^http/, 'ws');

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' },
    ...options
  });
  let data = null;
  try { data = await res.json(); } catch { /* resposta sem corpo */ }
  if (!res.ok) {
    throw new Error(data?.error || `Erro ${res.status}`);
  }
  return data;
}

export const api = {
  status: () => request('/api/status'),
  putSettings: (settings) => request('/api/settings', { method: 'PUT', body: JSON.stringify(settings) }),
  listWorlds: () => request('/api/worlds'),
  createWorld: (name, description, seed, experiments, port, version) => request('/api/worlds', { method: 'POST', body: JSON.stringify({ name, description, seed, experiments, port, version }) }),
  deleteWorldFolder: (id) => request(`/api/worlds/${id}`, { method: 'DELETE' }),
  getSoftwareVersions: () => request('/api/software/versions'),

  start: (id) => request(`/api/worlds/${id}/start`, { method: 'POST' }),
  stop: (id) => request(`/api/worlds/${id}/stop`, { method: 'POST' }),
  forceStop: (id) => request(`/api/worlds/${id}/force-stop`, { method: 'POST' }),
  restart: (id) => request(`/api/worlds/${id}/restart`, { method: 'POST' }),
  sendCommand: (id, command) => request(`/api/worlds/${id}/command`, { method: 'POST', body: JSON.stringify({ command }) }),

  reinstall: (id, pin, version) => request(`/api/worlds/${id}/reinstall`, { method: 'POST', body: JSON.stringify({ pin, version }) }),
  updateSoftware: (id, pin, version) => request(`/api/worlds/${id}/update-software`, { method: 'POST', body: JSON.stringify({ pin, version }) }),
  deleteMaster: (id, password) => request(`/api/worlds/${id}/delete-master`, { method: 'POST', body: JSON.stringify({ password }) }),

  getProperties: (id) => request(`/api/worlds/${id}/properties`),
  putProperties: (id, props) => request(`/api/worlds/${id}/properties`, { method: 'PUT', body: JSON.stringify(props) }),

  getExperiments: (id) => request(`/api/worlds/${id}/experiments`),
  putExperiments: (id, experiments) => request(`/api/worlds/${id}/experiments`, { method: 'PUT', body: JSON.stringify(experiments) }),

  getPlayers: (id) => request(`/api/worlds/${id}/players`),
  getRamStatus: () => request('/api/ram-status'),
  systemResources: () => request('/api/system/resources'),
  systemBattery: () => request('/api/system/battery'),
  setRamCache: (id, enabled) => request(`/api/worlds/${id}/ram-cache`, { method: 'PUT', body: JSON.stringify({ enabled }) }),
  ramSyncNow: (id) => request(`/api/worlds/${id}/ram-sync-now`, { method: 'POST' }),

  generateWorld: async (id, { seed, experiments, confirm }) => {
    const res = await fetch(`${API_BASE}/api/worlds/${id}/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ seed, experiments, confirm })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok && !data.needsConfirm) throw new Error(data.error || `Erro ${res.status}`);
    return data;
  },
  importWorld: async (id, file, confirm) => {
    const form = new FormData();
    form.append('file', file);
    form.append('confirm', confirm ? 'true' : 'false');
    const res = await fetch(`${API_BASE}/api/worlds/${id}/import`, { method: 'POST', body: form });
    const data = await res.json().catch(() => ({}));
    if (!res.ok && !data.needsConfirm) throw new Error(data.error || `Erro ${res.status}`);
    return data;
  },

  previewAddon: (id, file) => {
    const form = new FormData();
    form.append('file', file);
    return request(`/api/worlds/${id}/addons/preview`, { method: 'POST', body: form });
  },
  uploadAddon: (id, file, { confirm = false, onProgress } = {}) => new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${API_BASE}/api/worlds/${id}/addons?confirm=${confirm ? 'true' : 'false'}`);
    xhr.upload.onprogress = (evt) => {
      if (evt.lengthComputable) onProgress?.(Math.round((evt.loaded / evt.total) * 100));
    };
    xhr.onerror = () => reject(new Error('Falha de rede ao enviar o addon.'));
    xhr.onload = () => {
      let data = null;
      try { data = JSON.parse(xhr.responseText || '{}'); } catch { data = {}; }
      if (xhr.status >= 200 && xhr.status < 300) return resolve(data);
      const err = new Error(data?.error || `Erro ${xhr.status}`);
      Object.assign(err, data || {});
      reject(err);
    };
    const form = new FormData();
    form.append('file', file);
    xhr.send(form);
  }),
  removeAddon: (id, addonId) => request(`/api/worlds/${id}/addons/${addonId}`, { method: 'DELETE' }),
  reorderAddons: (id, kind, ids) => request(`/api/worlds/${id}/addons/order`, { method: 'PUT', body: JSON.stringify({ kind, ids }) }),

  backup: (id) => request(`/api/worlds/${id}/backup`, { method: 'POST' }),
  listBackups: (id) => request(`/api/worlds/${id}/backups`),
  deleteBackup: (id, fileName) => request(`/api/worlds/${id}/backups/${encodeURIComponent(fileName)}`, { method:'DELETE' }),
  restoreBackup: async (id, fileName, confirm) => request(`/api/worlds/${id}/backups/${encodeURIComponent(fileName)}/restore`, { method:'POST', body: JSON.stringify({ confirm }) }),

  getEvents: (id) => request(`/api/worlds/${id}/events`),

  listFiles: (id, path) => request(`/api/worlds/${id}/files?path=${encodeURIComponent(path || '')}`),
  readFile: (id, path) => request(`/api/worlds/${id}/files/content?path=${encodeURIComponent(path)}`),
  writeFile: (id, path, content) => request(`/api/worlds/${id}/files/content`, { method: 'PUT', body: JSON.stringify({ path, content }) }),
  uploadFiles: (id, path, files) => { const form = new FormData(); form.append('path', path || ''); [...files].forEach(f => form.append('files', f)); return request(`/api/worlds/${id}/files/upload`, { method: 'POST', body: form }); },
  createFolder: (id, path, name) => request(`/api/worlds/${id}/files/folder`, { method: 'POST', body: JSON.stringify({ path, name }) }),
  createFile: (id, path, name) => request(`/api/worlds/${id}/files/file`, { method: 'POST', body: JSON.stringify({ path, name }) }),
  renameFile: (id, path, name) => request(`/api/worlds/${id}/files/rename`, { method: 'PUT', body: JSON.stringify({ path, name }) }),
  archiveFile: (id, path) => request(`/api/worlds/${id}/files/archive`, { method:'POST', body: JSON.stringify({ path }) }),
  archiveSelectedFiles: (id, paths, destination) => request(`/api/worlds/${id}/files/archive-selected`, { method:'POST', body: JSON.stringify({ paths, destination }) }),
  moveFile: (id, path, destination) => request(`/api/worlds/${id}/files/move`, { method:'PUT', body:JSON.stringify({ path, destination }) }),
  deleteFile: (id, path) => request(`/api/worlds/${id}/files?path=${encodeURIComponent(path)}`, { method: 'DELETE' }),
  downloadSelectedFiles: (id, paths) => fetch(`${API_BASE}/api/worlds/${id}/files/download-selected`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({paths}) }),

  getAllowlist: (id) => request(`/api/worlds/${id}/allowlist`),
  addToAllowlist: (id, name) => request(`/api/worlds/${id}/allowlist`, { method: 'POST', body: JSON.stringify({ name }) }),
  removeFromAllowlist: (id, name) => request(`/api/worlds/${id}/allowlist/${encodeURIComponent(name)}`, { method: 'DELETE' }),

  getSoftware: (id) => request(`/api/worlds/${id}/software`),
  downloadWorldUrl: (id) => `${API_BASE}/api/worlds/${id}/world/download`,
  downloadFileUrl: (id, path) => `${API_BASE}/api/worlds/${id}/files/download?path=${encodeURIComponent(path)}`,
  viewFileUrl: (id, path) => `${API_BASE}/api/worlds/${id}/files/view?path=${encodeURIComponent(path)}`
};

export function connectConsole(instanceId, { onLog, onHistory, onStatus }) {
  const ws = new WebSocket(`${WS_BASE}/ws/console?instanceId=${instanceId}`);
  ws.onmessage = (evt) => {
    try {
      const msg = JSON.parse(evt.data);
      if (msg.type === 'log') onLog?.(msg.line);
      if (msg.type === 'history') onHistory?.(msg.logs);
      if (msg.type === 'status') onStatus?.(msg.status);
    } catch { /* mensagem malformada, ignora */ }
  };
  return ws;
}
